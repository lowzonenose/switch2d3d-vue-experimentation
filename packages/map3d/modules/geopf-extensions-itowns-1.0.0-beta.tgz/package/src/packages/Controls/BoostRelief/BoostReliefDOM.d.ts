export default BoostReliefDOM;
declare namespace BoostReliefDOM {
    function _addUID(id: string): string;
    function _createMainContainerElement(): DOMElement;
    function _createMainBoostReliefShowElement(collapsed: boolean): DOMElement;
    function _createAdvancedToolElement(brOptions: any): DOMElement;
    function _createAdvancedToolReliefElement(scale: any, defaultBoost: number): DOMElement[];
    let _createMainBoostReliefListContainer: () => HTMLElement;
    function _createMainPictoElement(): DOMElement;
}
//# sourceMappingURL=BoostReliefDOM.d.ts.map