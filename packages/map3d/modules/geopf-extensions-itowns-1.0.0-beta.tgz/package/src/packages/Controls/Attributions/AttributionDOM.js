import { createWidgetToggle } from "../Utils/WidgetToggle";

/**
 * Événements interceptés sur le widget DSFR pour ne pas déclencher les
 * contrôles du globe (glisser, zoom molette, menu contextuel, flèches du clavier
 * écoutées sur window par iTowns). Le clic n'est pas intercepté : il doit
 * rester disponible pour les liens des attributions.
 */
var DSFR_STOPPED_EVENTS = [
    "pointerdown", "mousedown", "touchstart", "wheel",
    "dblclick", "contextmenu", "keydown", "keyup"
];

var AttributionDOM = {

    // ################################################################### //
    // ######################### Main container ########################## //
    // ################################################################### //

    /**
    * Add uuid to the tag ID
    * @param {String} id - id selector
    * @returns {String} uid - id selector with an unique id
    */
    _addUID : function (id) {
        var uid = (this._uid) ? id + "-" + this._uid : id;
        return uid;
    },

    /**
     * Creation du container principal (DOM)
     *
     * @returns {DOMElement} div DOM
     */
    _createMainContainerElement : function () {
        var container = document.createElement("div");
        container.id = this._addUID("GPAttribution");
        container.className = "GPwidget";
        if (this._dsfr) {
            var self = this;
            container.classList.add("gpf-widget", "gpf-widget-button", "gpf-attributions-dsfr");
            // fermeture par Echap depuis le bouton ou un lien, avec retour du focus
            container.addEventListener("keydown", function (event) {
                if (event.key === "Escape" && !self._collapsed) {
                    event.preventDefault();
                    self.setCollapsed(true);
                    self._attributionsButton.focus();
                }
            });
            DSFR_STOPPED_EVENTS.forEach(function (eventName) {
                container.addEventListener(eventName, function (event) {
                    event.stopPropagation();
                });
            });
        }

        return container;
    },

    /**
     * Creation du selecteur (caché) pour l'affichage/masquage des attributions (DOM)
     *
     * @returns {DOMElement} checkbox DOM
     */
    _createMainAttributionsShowElement : function () {
        var input = document.createElement("input");
        input.id = this._addUID("GPshowAttributionsList");
        input.type = "checkbox";
        return input;
    },

    /**
     * Création de l'élément liste des attributions (DOM)
     *
     * @returns {DOMElement} liste DOM
     */
    _createAttributionsList : function () {
        var ul = document.createElement("ul");
        ul.id = this._addUID("GPAttributionsList");
        if (this._dsfr) {
            ul.className = "gpf-attributions__list";
        }
        return ul;
    },

    /**
     * Création d'un élément de la liste des attributions pour le rendu DSFR (DOM)
     *
     * Le nom est inséré comme texte ; une source sans URL est affichée sans lien.
     *
     * @param {Object} attribution - attribution (name, url)
     * @returns {DOMElement} li DOM
     */
    _createAttributionItemElement : function (attribution) {
        var li = document.createElement("li");
        li.className = "gpf-attributions__item";

        if (attribution.url) {
            var link = document.createElement("a");
            link.className = "gpf-attributions__link fr-link fr-link--sm";
            link.href = attribution.url;
            link.target = "_blank";
            link.rel = "noopener";
            link.title = attribution.name + " - nouvelle fenêtre";
            link.textContent = attribution.name;
            li.appendChild(link);
        } else {
            var span = document.createElement("span");
            span.className = "gpf-attributions__text fr-text--sm";
            span.textContent = attribution.name;
            li.appendChild(span);
        }

        return li;
    },

    /**
     * Création du conteneur principal des attributions (DOM)
     *
     * @returns {DOMElement} div DOM
     */
    _createMainAttributionsListContainer : function () {
        var div = document.createElement("div");
        div.id = this._addUID("GPAttributionsListContainer");
        if (this._dsfr) {
            // zone non modale, ouverte et fermée par le bouton du widget
            div.className = "gpf-attributions__content";
            div.hidden = this._collapsed;
            div.setAttribute("role", "region");
            div.setAttribute("aria-label", "Attributions des données affichées");
        }

        return div;
    },

    /**
     * Création du container du picto du controle (DOM)
     * @param {Boolean} collapsed - collapsed
     * @returns {DOMElement} label DOM
     */
    _createMainPictoElement : function (collapsed) {
        var self = this;

        if (this._dsfr) {
            // bouton équivalent au bouton « i » du contrôle d'attribution OpenLayers
            var button = createWidgetToggle({
                id : this._addUID("GPshowAttributionsListPicto"),
                className : "gpf-btn gpf-btn--tertiary gpf-btn-icon gpf-btn-icon-attributions fr-btn fr-btn--tertiary",
                label : "Afficher ou masquer les attributions",
                title : "Attributions",
                controls : this._addUID("GPAttributionsListContainer"),
                expanded : !this._collapsed,
                onClick : function () {
                    self.setCollapsed(!self._collapsed);
                }
            });
            button.firstElementChild.className = "fr-icon-information-line";
            button.firstElementChild.setAttribute("aria-hidden", "true");
            return button;
        }

        var label = document.createElement("label");
        label.id = this._addUID("GPshowAttributionsListPicto");
        label.className = "GPshowAdvancedToolPicto";
        label.htmlFor = this._addUID("GPshowAttributionsList");
        label.title = "Afficher/masquer les attributions";

        var spanOpen = document.createElement("span");
        spanOpen.id = this._addUID("GPshowAttributionsListOpenClose");
        spanOpen.className = "GPshowAdvancedToolOpen";
        spanOpen.innerHTML = collapsed ? "i" : "»";
        /** Evenement de type 'click' sur le picto du controle */
        spanOpen.addEventListener("click", function () {
            spanOpen.innerHTML = (document.getElementById(self._addUID("GPshowAttributionsList")).checked) ? "i" : "»";
        });

        label.appendChild(spanOpen);

        return label;
    }

};

export default AttributionDOM;
