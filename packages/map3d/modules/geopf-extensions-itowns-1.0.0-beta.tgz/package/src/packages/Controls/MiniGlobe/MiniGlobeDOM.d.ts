export default MiniGlobeDOM;
declare namespace MiniGlobeDOM {
    function _addUID(id: string): string;
    function _createMainContainerElement(): DOMElement;
    function _createMiniGlobeButtonElement(): HTMLButtonElement;
    function _createMiniGlobeViewportElement(): HTMLDivElement;
}
//# sourceMappingURL=MiniGlobeDOM.d.ts.map