export function createWidgetToggle (options) {
    var button = document.createElement("button");
    button.type = "button";
    button.id = options.id;
    button.className = options.className;
    button.classList.add("GPshowAdvancedToolPicto");
    button.title = options.title || options.label;
    button.setAttribute("aria-label", options.label);
    button.setAttribute("aria-controls", options.controls);
    updateWidgetToggle(button, options.expanded);
    button.appendChild(document.createElement("span"));
    button.addEventListener("click", options.onClick);
    return button;
}

export function updateWidgetToggle (button, expanded) {
    button.setAttribute("aria-expanded", String(expanded));
    button.setAttribute("aria-pressed", String(expanded));
}