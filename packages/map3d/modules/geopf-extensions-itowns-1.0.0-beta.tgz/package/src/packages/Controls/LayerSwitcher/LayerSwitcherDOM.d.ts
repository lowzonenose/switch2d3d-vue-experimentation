export default LayerSwitcherDOM;
declare namespace LayerSwitcherDOM {
    function _createDraggableElement(elementDraggable: any, context: any): void;
    function _addUID(id: string): string;
    function _createMainContainerElement(): DOMElement;
    function _createMainLayersShowElement(): DOMElement;
    function _createMainLayersElement(): DOMElement;
    function _createMainLayersHeaderElement(): DOMElement;
    function _createMainLayersDivElement(): DOMElement;
    function _createMainLayerListElement(): DOMElement;
    function _createMainStatusElement(): DOMElement;
    function _createDsfrPanelHeaderElement(options: {
        title: string;
        titleId: string;
        closeId: string;
        onClose: Function;
    }): DOMElement;
    function _createMainPictoElement(): DOMElement;
    let _createMainInfoElement: () => HTMLElement;
    function _createContainerLayerElement(obj: {
        layer: any;
        id: string;
        title: string;
        description: string;
        visibility: boolean;
        opacity: Float;
    }): DOMElement;
    function _createBasicToolElement(obj: any): DOMElement;
    function _createDsfrLayerButton(options: {
        id?: string | undefined;
        className: string;
        label: string;
        layerId: string;
    }): DOMElement;
    function _createDragNDropElement(obj: any): DOMElement;
    function _createBasicToolTitleElement(obj: any): DOMElement;
    function _createBasicToolButtons(obj: any): DOMElement;
    function _createVisibilityElement(obj: any): DOMElement;
    function _setVisibilityButtonState(button: DOMElement, visible: boolean): void;
    function _createDeleteElement(obj: any): DOMElement;
    function _createAdvancedToolToggleElement(obj: any): DOMElement;
    function _createBasicToolNameElement(obj: any): DOMElement;
    function _createBasicToolVisibilityElement(obj: any): DOMElement[];
    function _createAdvancedToolShowElement(obj: any): DOMElement[];
    function _createAdvancedToolElement(obj: any): DOMElement;
    function _createAdvancedToolDeleteElement(obj: any): DOMElement;
    function _createAdvancedToolInformationElement(obj: any): DOMElement;
    function _createAdvancedToolOpacityElement(obj: any): DOMElement[];
    function _setOpacityRangeState(input: DOMElement, value: number): void;
    function _getLayerInfoLegendLinks(obj: any): any[];
    function _createLayerInfoLinksElement(id: string, title: string, links: any[]): DOMElement;
    function _createContainerLayerInfoElement(obj: any): DOMElement;
}
//# sourceMappingURL=LayerSwitcherDOM.d.ts.map