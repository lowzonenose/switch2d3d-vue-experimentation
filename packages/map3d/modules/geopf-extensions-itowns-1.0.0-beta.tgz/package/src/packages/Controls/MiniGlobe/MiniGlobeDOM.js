import { createWidgetToggle } from "../Utils/WidgetToggle";

var MiniGlobeDOM = {

    /**
    * Add uuid to the tag ID
    * @param {String} id - id selector
    * @returns {String} uid - id selector with an unique id
    */
    _addUID : function (id) {
        var uid = (this._uid) ? id + "-" + this._uid : id;
        return uid;
    },

    /**
     * Main container (DOM)
     *
     * @returns {DOMElement} DOM element
     */
    _createMainContainerElement : function () {
        var container = document.createElement("div");
        container.id = this._addUID("GPminiglobeContainer");
        container.className = "GPwidget";
        if (this._dsfr) {
            container.classList.add("gpf-widget", "gpf-mini-globe-dsfr");
        }
        var propagationEvents = [
            "pointerdown", "pointermove", "pointerup", "pointercancel",
            "mousedown", "mousemove", "mouseup", "touchstart", "touchmove",
            "touchend", "wheel", "click", "dblclick", "contextmenu"
        ];
        propagationEvents.forEach(function (eventName) {
            container.addEventListener(eventName, function (event) {
                event.stopPropagation();
            });
        });
        return container;
    },

    _createMiniGlobeButtonElement : function () {
        var self = this;
        var className = "GPshowOpen GPshowMiniGlobePicto";
        if (this._dsfr) {
            className += " gpf-btn gpf-btn--tertiary gpf-btn-icon gpf-btn-icon-overviewmap fr-btn fr-btn--tertiary";
        }
        return createWidgetToggle({
            id : this._addUID("GPshowMiniGlobe"),
            className : className,
            label : "Afficher ou masquer la mini-vue du globe",
            controls : this._addUID("GPminiglobeViewport"),
            expanded : !this.collapsed,
            onClick : function () {
                self.setCollapsed(!self.collapsed);
            }
        });
    },

    _createMiniGlobeViewportElement : function () {
        var viewport = document.createElement("div");
        viewport.id = this._addUID("GPminiglobeViewport");
        viewport.className = "GPminiglobeViewport";
        viewport.setAttribute("role", "region");
        viewport.setAttribute("aria-label", "Mini-vue du globe");
        viewport.setAttribute("aria-hidden", String(this.collapsed));
        if (this.collapsed) {
            viewport.classList.add("GPminiglobeCollapsed");
        }
        return viewport;
    }
};

export default MiniGlobeDOM;
