import Sortable from "sortablejs";
import { createWidgetToggle } from "../Utils/WidgetToggle";

/**
 * Événements interceptés sur le widget DSFR pour ne pas déclencher les
 * contrôles du globe (glisser, zoom molette, menu contextuel, flèches du clavier
 * écoutées sur window par iTowns).
 * Les événements de déplacement et de relâchement ne sont pas interceptés :
 * Sortable les écoute sur le document pendant un glisser-déposer.
 */
var DSFR_STOPPED_EVENTS = [
    "pointerdown", "mousedown", "touchstart", "wheel",
    "dblclick", "contextmenu", "keydown", "keyup"
];

var LayerSwitcherDOM = {

    /**
     * Creation du drag and drop
     *
     * @param {Object} elementDraggable - Element HTML (DOM) Container
     * @param {Object} context - this
     */
    _createDraggableElement : function (elementDraggable, context) {
        var options = {
            handle : ".GPlayerName",
            draggable : ".draggable-layer",
            ghostClass : "GPghostLayer",
            animation : 200,
            // Call event function on drag and drop
            onEnd : function (e) {
                // FIXME pas terrrible, mais il faut bien passer ce contexte...
                context._onDragAndDropLayerClick(e);
            }
        };
        if (this._dsfr) {
            // DSFR : poignée dédiée et titre, comme dans les extensions OpenLayers ;
            // les boutons clavier de la poignée ne démarrent pas de glisser-déposer.
            options.handle = ".GPlayerDragNDrop, .GPtitle";
            options.filter = ".keyboard-navigation";
            options.preventOnFilter = false;
        }
        // FIXME retirer cette détection user-agent pour solution propre
        // option forcefallback pour réparer sortable sous Chrome 97
        // option forcefallback casse le layerswitcher du portail sous firefox
        if (navigator.userAgent.match(/chrome|chromium|crios/i)) {
            options.forceFallback = true;
        }
        Sortable.create(elementDraggable, options);
    },

    // ################################################################### //
    // ######################### Main container ########################## //
    // ################################################################### //

    /**
    * Add uuid to the tag ID
    * @param {String} id - id selector
    * @returns {String} uid - id selector with an unique id
    */
    _addUID : function (id) {
        var uid = (this._uid) ? id + "-" + this._uid : id;
        return uid;
    },

    /**
     * Creation du container principal (DOM)
     *
     * @returns {DOMElement} container - layer switcher DOM element
     */
    _createMainContainerElement : function () {
        var container = document.createElement("div");
        container.id = this._addUID("GPlayerSwitcher");
        container.className = "GPwidget";
        if (this._dsfr) {
            container.classList.add("gpf-widget", "gpf-widget-button", "gpf-mobile-fullscreen", "gpf-layer-switcher-dsfr");
            DSFR_STOPPED_EVENTS.forEach(function (eventName) {
                container.addEventListener(eventName, function (event) {
                    event.stopPropagation();
                });
            });
        }
        return container;
    },

    /**
     * Creation du container principal d"affichage des layers (DOM)
     *
     * @returns {DOMElement} input - element for minimizing/maximizing the layer switcher
     */
    _createMainLayersShowElement : function () {
        // <!-- Hidden checkbox for minimizing/maximizing -->
        var input = document.createElement("input");
        input.id = this._addUID("GPshowLayersList");
        input.type = "checkbox";
        return input;
    },

    /**
     * Creation du container principal des layers (DOM)
     *
     * @returns {DOMElement} container - layers list container
     */
    _createMainLayersElement : function () {
        // ajout de la liste des layers dans le container principal
        // <div id="GPlayersList" class="GPpanel">
        //   (...)
        // </div>
        var div = document.createElement("div");
        div.id = this._addUID("GPlayersList");
        div.className = "GPpanel";
        if (this._dsfr) {
            // panneau non modal (le pilote iTowns n'utilise pas de dialog DSFR)
            var self = this;
            div.classList.add("gpf-panel");
            div.hidden = this._collapsed;
            div.setAttribute("role", "region");
            div.setAttribute("aria-labelledby", this._addUID("GPlayersPanelTitle"));
            div.addEventListener("keydown", function (event) {
                if (event.key === "Escape") {
                    event.stopPropagation();
                    self.setCollapsed(true);
                    self._showLayersListButton.focus();
                }
            });
        }
        return div;
    },

    /**
     * DSFR : en-tête du panneau des couches (icône, titre, fermeture)
     *
     * @returns {DOMElement} header
     */
    _createMainLayersHeaderElement : function () {
        var self = this;
        return this._createDsfrPanelHeaderElement({
            title : "Couches",
            titleId : this._addUID("GPlayersPanelTitle"),
            closeId : this._addUID("GPlayersPanelClose"),
            onClose : function () {
                self.setCollapsed(true);
                self._showLayersListButton.focus();
            }
        });
    },

    /**
     * DSFR : corps du panneau des couches
     *
     * @returns {DOMElement} body
     */
    _createMainLayersDivElement : function () {
        var div = document.createElement("div");
        div.className = "GPpanelBody gpf-panel__body gpf-panel__body_ls fr-modal__body";
        return div;
    },

    /**
     * DSFR : liste des couches (conteneur du glisser-déposer)
     *
     * @returns {DOMElement} list
     */
    _createMainLayerListElement : function () {
        var div = document.createElement("div");
        div.className = "GPLayerListBody";
        div.setAttribute("role", "list");
        div.setAttribute("aria-labelledby", this._addUID("GPlayersPanelTitle"));
        return div;
    },

    /**
     * DSFR : zone de statut (annonce des déplacements et suppressions de couches)
     *
     * @returns {DOMElement} status
     */
    _createMainStatusElement : function () {
        var div = document.createElement("div");
        div.id = this._addUID("GPlayerSwitcherStatus");
        div.className = "fr-sr-only";
        div.setAttribute("role", "status");
        return div;
    },

    /**
     * DSFR : en-tête générique de panneau (même structure que PanelDOM OpenLayers)
     *
     * @param {Object} options - options
     * @param {String} options.title - titre du panneau
     * @param {String} options.titleId - identifiant du titre
     * @param {String} options.closeId - identifiant du bouton de fermeture
     * @param {Function} options.onClose - action du bouton de fermeture
     * @returns {DOMElement} header
     */
    _createDsfrPanelHeaderElement : function (options) {
        var header = document.createElement("div");
        header.className = "GPpanelHeader gpf-panel__header fr-p-1w";

        var icon = document.createElement("span");
        icon.className = "fr-icon-ign-layerswitcher fr-icon--sm fr-mr-1w";
        icon.setAttribute("aria-hidden", "true");
        header.appendChild(icon);

        var title = document.createElement("span");
        title.id = options.titleId;
        title.className = "GPpanelTitle gpf-panel__title";
        title.textContent = options.title;
        header.appendChild(title);

        var close = document.createElement("button");
        close.type = "button";
        close.id = options.closeId;
        close.className = "GPpanelClose fr-btn fr-btn--sm fr-icon-close-line fr-btn--tertiary-no-outline fr-ml-auto";
        close.title = "Fermer le panneau";
        close.textContent = "Fermer le panneau";
        close.addEventListener("click", options.onClose);
        header.appendChild(close);

        return header;
    },

    /**
     * Creation du container du picto du controle (DOM)
     *
     * @returns {DOMElement} label
     */
    _createMainPictoElement : function () {
        var self = this;

        if (this._dsfr) {
            return createWidgetToggle({
                id : this._addUID("GPshowLayersListPicto"),
                className : "GPshowOpen GPshowLayersListPicto gpf-btn gpf-btn--tertiary gpf-btn-icon gpf-btn-icon-layerswitcher fr-btn fr-btn--tertiary",
                label : "Gestionnaire de couches",
                title : "Afficher/masquer le gestionnaire de couches",
                controls : this._addUID("GPlayersList"),
                expanded : !this._collapsed,
                onClick : function () {
                    self.setCollapsed(!self.getCollapsed());
                }
            });
        }

        // exemple :
        // <!-- Label for minimizing/maximizing -->
        // <label id="GPshowLayersListPicto" class="GPshowAdvancedToolPicto" for="GPshowLayersList" title="Afficher/masquer le gestionnaire de couches">
        //    <span id="GPshowLayersListOpen" class="GPshowAdvancedToolOpen"></span><span id="GPshowLayersListClose"></span>
        // </label>

        var label = document.createElement("label");
        label.id = this._addUID("GPshowLayersListPicto");
        label.className = "GPshowAdvancedToolPicto";
        label.htmlFor = this._addUID("GPshowLayersList");
        label.title = "Afficher/masquer le gestionnaire de couches";

        var spanOpen = document.createElement("span");
        spanOpen.id = this._addUID("GPshowLayersListOpen");
        spanOpen.className = "GPshowAdvancedToolOpen";
        spanOpen.addEventListener("click", function () {
            if (document.getElementById(self._addUID("GPshowLayersList")).checked) {
                var layers = document.getElementsByClassName("GPlayerInfoOpened");
                for (var i = 0; i < layers.length; i++) {
                    // eslint-disable-next-line security/detect-object-injection
                    layers[i].className = "GPlayerInfo";
                }
                document.getElementById(self._addUID("GPlayerInfoPanel")).className = "GPlayerInfoPanelClosed";
            }
        });

        label.appendChild(spanOpen);

        var spanClose = document.createElement("span");
        spanClose.addEventListener("click", function () {
            if (document.getElementById(self._addUID("GPshowLayersList")).checked) {
                var layers = document.getElementsByClassName("GPlayerInfoOpened");
                for (var i = 0; i < layers.length; i++) {
                    // eslint-disable-next-line security/detect-object-injection
                    layers[i].className = "GPlayerInfo";
                }
                document.getElementById(self._addUID("GPlayerInfoPanel")).className = "GPlayerInfoPanelClosed";
            }
        });
        spanClose.id = self._addUID("GPshowLayersListClose");

        label.appendChild(spanClose);

        return label;
    },

    /**
     * Creation du container du panneau d"information (DOM)
     *
     * @returns {HTMLElement} container
     * @type {function(): HTMLElement}
     */
    _createMainInfoElement : function () {
        // gestion du panneau d"information dans le container principal
        // <div id="GPlayerInfoPanel" class="GPlayerInfoPanelClosed">...</div>
        var div = document.createElement("div");
        div.id = this._addUID("GPlayerInfoPanel");
        div.className = "GPpanel GPlayerInfoPanelClosed";
        if (this._dsfr) {
            var self = this;
            var closeAndRestoreFocus = function () {
                var button = self._closeLayerInfoPanel();
                if (button) {
                    button.focus();
                }
            };
            div.classList.add("gpf-panel");
            div.hidden = true;
            // reçoit le focus à l'ouverture (il suit toute la liste dans l'ordre de tabulation)
            div.tabIndex = -1;
            div.setAttribute("role", "region");
            div.setAttribute("aria-labelledby", this._addUID("GPlayerInfoPanelTitle"));
            div.addEventListener("keydown", function (event) {
                if (event.key === "Escape") {
                    event.stopPropagation();
                    closeAndRestoreFocus();
                }
            });
            div.appendChild(this._createDsfrPanelHeaderElement({
                title : "Informations",
                titleId : this._addUID("GPlayerInfoPanelTitle"),
                closeId : this._addUID("GPlayerInfoPanelClose"),
                onClose : closeAndRestoreFocus
            }));
            var body = this._layerInfoBody = document.createElement("div");
            body.className = "gpf-panel__body fr-modal__body";
            div.appendChild(body);
        }
        return div;
    },

    // ################################################################### //
    // ######################### Layer container ######################### //
    // ################################################################### //

    /**
     * Creation du container du layer (DOM)
     *
     * @param {Object} obj - options de la couche à ajouter dans le layer switcher
     * @param {Object} obj.layer - couche (ol ou leaflet)
     * @param {String} obj.id - identifiant de la couche (pour ol ou leaflet)
     * @param {String} obj.title - nom de la couche à afficher dans le controle
     * @param {String} obj.description - description de la couche à afficher
     * @param {Boolean} obj.visibility - visibilité de la couche dans la carte (true or false)
     * @param {Float} obj.opacity - opacité de la couche
     *
     * @returns {DOMElement} container
     */
    _createContainerLayerElement : function (obj) {
        // exemple :
        // <div id="GPlayerSwitcher_ID_Layer1" class="GPlayerSwitcher_layer outOfRange">
        //     <!-- Basic toolbar : visibility / layer name
        //     _createBasicToolElement
        //           _createBasicToolVisibilityElement
        //           _createBasicToolNameElement
        //     -->
        //     <!-- Hidden checkbox + label for showing advanced toolbar
        //     _createAdvancedToolShowElement
        //     -->
        //     <!-- Advanced toolbar : layer info / opacity slider / opacity value / removal
        //     _createAdvancedToolElement
        //           _createAdvancedToolDeleteElement
        //           _createAdvancedToolInformationElement
        //           _createAdvancedToolOpacityElement
        //     -->
        // </div>

        // <!-- Layer entry in layer list -->
        // <!-- Every item is marked with layerID, which is defined at layer import -->
        var container = document.createElement("div");
        container.id = this._addUID("GPlayerSwitcher_ID_" + obj.id);
        container.className = "GPlayerSwitcher_layer draggable-layer";

        if (this._dsfr) {
            // DSFR : structure des extensions OpenLayers
            // (outils de base sur une ligne, outils avancés repliables)
            container.setAttribute("role", "listitem");
            container.appendChild(this._createBasicToolElement(obj));
            container.appendChild(this._createAdvancedToolElement(obj));
            return container;
        }

        // ajout des outils basiques (visibility / layer name)
        container.appendChild(this._createBasicToolElement(obj));

        // liste des outils avancés (layer info / opacity slider / opacity value / removal)
        var array = this._createAdvancedToolShowElement(obj);
        for (var i = 0; i < array.length; i++) {
            // eslint-disable-next-line security/detect-object-injection
            container.appendChild(array[i]);
        }

        // ajout des outils avancés
        container.appendChild(this._createAdvancedToolElement(obj));

        return container;
    },

    // ################################################################### //
    // ############################ Layer tool ########################### //
    // ################################################################### //

    /**
     * Creation du container des outils basiques du layer (DOM)
     *
     * @param {Object} obj - options de la couche à ajouter dans le layer switcher
     *
     * @returns {DOMElement} container
     */
    _createBasicToolElement : function (obj) {
        // exemple :
        // <div id="GPbasicTools_ID_1" class="GPlayerBasicTools">
        //      <!-- _createBasicToolVisibilityElement -->
        //      <!-- _createBasicToolNameElement -->
        // </div>

        var div = document.createElement("div");
        div.id = this._addUID("GPbasicTools_ID_" + obj.id);
        div.className = "GPlayerBasicTools";

        if (this._dsfr) {
            // ordre du DOM identique à l'ordre visuel (poignée, titre, boutons)
            div.appendChild(this._createDragNDropElement(obj));
            div.appendChild(this._createBasicToolTitleElement(obj));
            div.appendChild(this._createBasicToolButtons(obj));
            return div;
        }

        div.appendChild(this._createBasicToolNameElement(obj));

        var array = this._createBasicToolVisibilityElement(obj);
        for (var i = 0; i < array.length; i++) {
            // eslint-disable-next-line security/detect-object-injection
            div.appendChild(array[i]);
        }

        return div;
    },

    // ################################################################### //
    // ######################## DSFR layer tools ######################### //
    // ################################################################### //

    /**
     * DSFR : bouton d'outil de couche (type="button", intitulé textuel,
     * décrit par le nom de la couche)
     *
     * @param {Object} options - options
     * @param {String} [options.id] - identifiant du bouton
     * @param {String} options.className - classes du bouton
     * @param {String} options.label - intitulé (masqué visuellement pour les boutons icônes)
     * @param {String} options.layerId - identifiant de la couche
     * @returns {DOMElement} button
     */
    _createDsfrLayerButton : function (options) {
        var button = document.createElement("button");
        button.type = "button";
        if (options.id) {
            button.id = options.id;
        }
        button.className = options.className;
        button.title = options.label;
        button.textContent = options.label;
        button.setAttribute("aria-describedby", this._addUID("GPname_ID_" + options.layerId));
        button.layerId = options.layerId;
        return button;
    },

    /**
     * DSFR : poignée de glisser-déposer et boutons de déplacement au clavier
     *
     * @param {Object} obj - options de la couche à ajouter dans le layer switcher
     * @returns {DOMElement} container
     */
    _createDragNDropElement : function (obj) {
        var self = this;
        var handle = document.createElement("div");
        handle.id = this._addUID("GPdragndropPicto_ID_" + obj.id);
        handle.className = "GPlayerDragNDrop gpf-btn-icon-ls-draggable";
        handle.title = "Déplacer la couche";

        var keyboard = document.createElement("div");
        keyboard.className = "keyboard-navigation";
        [
            ["up", "Déplacer la couche vers le haut", "fr-icon-arrow-up-line"],
            ["down", "Déplacer la couche vers le bas", "fr-icon-arrow-down-line"]
        ].forEach(function (conf) {
            var button = self._createDsfrLayerButton({
                className : "fr-btn fr-btn--sm fr-btn--tertiary-no-outline " + conf[2],
                label : conf[1],
                layerId : obj.id
            });
            button.dataset.direction = conf[0];
            button.addEventListener("click", function () {
                self._onMoveLayerClick(button, conf[0]);
            });
            keyboard.appendChild(button);
        });
        handle.appendChild(keyboard);

        return handle;
    },

    /**
     * DSFR : titre de la couche
     *
     * @param {Object} obj - options de la couche à ajouter dans le layer switcher
     * @returns {DOMElement} container
     */
    _createBasicToolTitleElement : function (obj) {
        var div = document.createElement("div");
        div.id = this._addUID("GPtitle_ID_" + obj.id);
        div.className = "GPtitle";

        var title = document.createElement("div");
        title.id = this._addUID("GPlayerTitle_ID_" + obj.id);
        title.className = "GPlayerTitle";
        title.appendChild(this._createBasicToolNameElement(obj));
        div.appendChild(title);

        return div;
    },

    /**
     * DSFR : boutons de la ligne de couche (suppression, visibilité, outils avancés)
     *
     * @param {Object} obj - options de la couche à ajouter dans le layer switcher
     * @returns {DOMElement} container
     */
    _createBasicToolButtons : function (obj) {
        var div = document.createElement("div");
        div.id = this._addUID("GPbasicToolButtons_ID_" + obj.id);
        div.className = "GPbasicToolButtons";

        div.appendChild(this._createDeleteElement(obj));
        div.appendChild(this._createVisibilityElement(obj));
        div.appendChild(this._createAdvancedToolToggleElement(obj));

        return div;
    },

    /**
     * DSFR : bouton de visibilité de la couche (bouton bascule)
     *
     * @param {Object} obj - options de la couche à ajouter dans le layer switcher
     * @returns {DOMElement} button
     */
    _createVisibilityElement : function (obj) {
        var context = this;
        var visible = (typeof obj.visibility !== "undefined") ? obj.visibility : true;
        var button = this._createDsfrLayerButton({
            id : this._addUID("GPvisibilityPicto_ID_" + obj.id),
            className : "GPlayerVisibility gpf-btn gpf-btn--tertiary fr-btn fr-btn--sm fr-btn--tertiary-no-outline",
            label : "Afficher la couche",
            layerId : obj.id
        });
        this._setVisibilityButtonState(button, visible);
        button.addEventListener("click", function (e) {
            context._onVisibilityLayerClick(e);
        });
        return button;
    },

    /**
     * DSFR : synchronise l'état et l'icône du bouton de visibilité
     *
     * @param {DOMElement} button - bouton de visibilité
     * @param {Boolean} visible - visibilité de la couche
     */
    _setVisibilityButtonState : function (button, visible) {
        visible = !!visible;
        button.setAttribute("aria-pressed", String(visible));
        button.classList.toggle("fr-icon-eye-line", visible);
        button.classList.toggle("fr-icon-eye-off-line", !visible);
    },

    /**
     * DSFR : bouton de suppression de la couche
     *
     * @param {Object} obj - options de la couche à ajouter dans le layer switcher
     * @returns {DOMElement} button
     */
    _createDeleteElement : function (obj) {
        var context = this;
        var button = this._createDsfrLayerButton({
            id : this._addUID("GPremove_ID_" + obj.id),
            className : "GPlayerRemove gpf-btn gpf-btn--tertiary fr-btn fr-btn--sm fr-btn--tertiary-no-outline fr-icon-delete-line",
            label : "Supprimer la couche",
            layerId : obj.id
        });
        button.addEventListener("click", function (e) {
            context._onDropLayerClick(e);
        });
        return button;
    },

    /**
     * DSFR : bouton d'affichage des outils avancés de la couche (divulgation)
     *
     * @param {Object} obj - options de la couche à ajouter dans le layer switcher
     * @returns {DOMElement} button
     */
    _createAdvancedToolToggleElement : function (obj) {
        var button = this._createDsfrLayerButton({
            id : this._addUID("GPshowAdvancedTools_ID_" + obj.id),
            className : "GPshowMoreOptions GPshowLayerAdvancedTools gpf-btn gpf-btn--tertiary fr-btn fr-btn--sm fr-btn--tertiary-no-outline fr-icon-arrow-down-s-line",
            label : "Plus d'outils",
            layerId : obj.id
        });
        button.setAttribute("aria-expanded", "false");
        button.setAttribute("aria-controls", this._addUID("GPadvancedTools_ID_" + obj.id));
        button.addEventListener("click", function () {
            var expanded = button.getAttribute("aria-expanded") !== "true";
            var layer = button.closest(".GPlayerSwitcher_layer");
            button.setAttribute("aria-expanded", String(expanded));
            layer.querySelector(".GPlayerAdvancedTools").hidden = !expanded;
        });
        return button;
    },

    /**
     * Creation du nom du layer (DOM)
     *
     * @param {Object} obj - options de la couche à ajouter dans le layer switcher
     *
     * @returns {DOMElement} container
     */
    _createBasicToolNameElement : function (obj) {
        // exemple :
        // <span id="GPname_ID_Layer1" class="GPlayerName" title="Quartiers prioritaires de la ville">Quartiers prioritaires de la ville</span>
        var span = document.createElement("span");
        span.id = this._addUID("GPname_ID_" + obj.id);
        span.className = "GPlayerName";
        span.title = obj.description || obj.title;
        span.innerHTML = obj.title;

        return span;
    },

    /**
     * Creation de l'icone de visibilité du layer (DOM)
     *
     * @param {Object} obj - options de la couche à ajouter dans le layer switcher

     * @returns {DOMElement[]} array containing input and label elements
     */
    _createBasicToolVisibilityElement : function (obj) {
        // exemple :
        // <input type="checkbox" id="GPvisibility_ID_Layer1" checked="">
        // <label for="GPvisibility_ID_Layer1" id="GPvisibilityPicto_ID_Layer1" class="GPlayerVisibility" title="Afficher/masquer la couche"></label>

        var list = [];

        var checked = (typeof obj.visibility !== "undefined") ? obj.visibility : true;
        var id = this._addUID("GPvisibility_ID_" + obj.id);

        var input = document.createElement("input");
        input.id = id;
        input.type = "checkbox";
        input.checked = checked;

        var label = document.createElement("label");
        label.htmlFor = id;
        label.id = this._addUID("GPvisibilityPicto_ID_" + obj.id);
        label.className = "GPlayerVisibility";
        label.title = "Afficher/masquer la couche";

        // add event for visibility change
        var context = this;
        if (input.addEventListener) {
            input.addEventListener(
                "click",
                function (e) {
                    context._onVisibilityLayerClick(e);
                }
            );
        } else if (input.attachEvent) {
            // internet explorer
            input.attachEvent(
                "onclick",
                function (e) {
                    context._onVisibilityLayerClick(e);
                }
            );
        }

        list.push(input);
        list.push(label);

        return list;
    },

    /**
     * Creation de l'affichage du menu des outils avancés du layer (DOM)
     *
     * @param {Object} obj - options de la couche à ajouter dans le layer switcher
     *
     * @returns {DOMElement[]} array containing input and label elements
     */
    _createAdvancedToolShowElement : function (obj) {
        // <input type="checkbox" id="GPshowAdvancedTools_ID_Layer1">
        // <label for="GPshowAdvancedTools_ID_Layer1" id="GPshowAdvancedToolsPicto_ID_Layer1" class="GPshowMoreOptions GPshowLayerAdvancedTools" title="Plus d'outils"></label>

        var list = [];

        var label = document.createElement("label");
        label.id = this._addUID("GPshowAdvancedToolsPicto_ID_" + obj.id);
        label.htmlFor = this._addUID("GPshowAdvancedTools_ID_" + obj.id);
        label.title = "Plus d'outils";
        label.className = "GPshowMoreOptions GPshowLayerAdvancedTools";

        var input = document.createElement("input");
        input.type = "checkbox";
        input.id = this._addUID("GPshowAdvancedTools_ID_" + obj.id);

        list.push(input);
        list.push(label);

        return list;
    },

    /**
     * Creation du container des outils avancés du layer (DOM)
     *
     * @param {Object} obj - options de la couche à ajouter dans le layer switcher
     *
     * @returns {DOMElement} container
     */
    _createAdvancedToolElement : function (obj) {
        // exemple :
        // <div id="GPadvancedTools_ID_Layer1" class="GPlayerAdvancedTools">
        //     <!-- _createAdvancedToolDeleteElement -->
        //     <!-- _createAdvancedToolInformationElement -->
        //     <!-- _createAdvancedToolOpacityElement -->
        // </div>

        var container = document.createElement("div");
        container.id = this._addUID("GPadvancedTools_ID_" + obj.id);
        container.className = "GPlayerAdvancedTools";

        if (this._dsfr) {
            container.hidden = true;
            if (obj.type !== "feature") {
                var opacity = document.createElement("div");
                opacity.id = this._addUID("GPopacityContainer_ID_" + obj.id);
                opacity.className = "GPopacityContainer";
                this._createAdvancedToolOpacityElement(obj).forEach(function (element) {
                    opacity.appendChild(element);
                });
                container.appendChild(opacity);
            }
            var group = document.createElement("div");
            group.id = this._addUID("GPAdvancedToolBtnsGroup_ID_" + obj.id);
            group.className = "GPAdvancedToolBtnsGroup GPbtnsGroup";
            if (obj.title && obj.description) {
                group.appendChild(this._createAdvancedToolInformationElement(obj));
            }
            container.appendChild(group);
            return container;
        }

        container.appendChild(this._createAdvancedToolDeleteElement(obj));

        // si on n'a de l'informations à afficher, on met en place ce composant
        if (obj.title && obj.description) {
            container.appendChild(this._createAdvancedToolInformationElement(obj));
        }
        if (obj.type !== "feature") {
            var array = this._createAdvancedToolOpacityElement(obj);
            for (var i = 0; i < array.length; i++) {
                // eslint-disable-next-line security/detect-object-injection
                container.appendChild(array[i]);
            }
        }

        return container;
    },

    /**
     * Creation de l'icone de suppression du layer (DOM)
     *
     * @param {Object} obj - options de la couche à ajouter dans le layer switcher
     *
     * @returns {DOMElement} container
     */
    _createAdvancedToolDeleteElement : function (obj) {
        // exemple :
        // <div id="GPremove_ID_Layer1" class="GPlayerRemove" title="Supprimer la couche" onclick="GPdropLayer(this);"></div>

        var div = document.createElement("div");
        div.id = this._addUID("GPremove_ID_" + obj.id);
        div.className = "GPlayerRemove";
        div.title = "Supprimer la couche";
        div.layerId = obj.id;

        var context = this;
        if (div.addEventListener) {
            div.addEventListener(
                "click",
                function (e) {
                    context._onDropLayerClick(e);
                }
            );
        } else if (div.attachEvent) {
            // internet explorer
            div.attachEvent(
                "onclick",
                function (e) {
                    context._onDropLayerClick(e);
                }
            );
        }

        return div;
    },

    /**
     * Creation de l'icone d'information du layer (DOM)
     *
     * @param {Object} obj - options de la couche à ajouter dans le layer switcher
     *
     * @returns {DOMElement} container
     */
    _createAdvancedToolInformationElement : function (obj) {
        // exemple :
        // <div id="GPinfo_ID_Layer1" class="GPlayerInfo" title="Informations/légende" onclick="GPopenLayerInfo(this);"></div>

        if (this._dsfr) {
            var self = this;
            var button = this._createDsfrLayerButton({
                id : this._addUID("GPinfo_ID_" + obj.id),
                className : "GPlayerInfo gpf-btn gpf-btn--tertiary fr-btn fr-btn--sm fr-btn--tertiary-no-outline fr-btn--icon-left fr-icon-information-line",
                label : "Informations",
                layerId : obj.id
            });
            button.removeAttribute("title");
            button.setAttribute("aria-expanded", "false");
            button.setAttribute("aria-controls", this._addUID("GPlayerInfoPanel"));
            button.addEventListener("click", function (e) {
                self._onOpenLayerInfoClick(e);
            });
            return button;
        }

        var div = document.createElement("div");
        div.id = this._addUID("GPinfo_ID_" + obj.id);
        div.className = "GPlayerInfo";
        div.title = "Informations/légende";
        div.layerId = obj.id;
        // add event on click
        var context = this;
        if (div.addEventListener) {
            div.addEventListener(
                "click",
                function (e) {
                    context._onOpenLayerInfoClick(e);
                }
            );
        } else if (div.attachEvent) {
            // internet explorer
            div.attachEvent(
                "onclick",
                function (e) {
                    context._onOpenLayerInfoClick(e);
                }
            );
        }

        return div;
    },

    /**
     * Creation de l'icone de gestion de l'opacité du layer (DOM)
     *
     * @param {Object} obj - options de la couche à ajouter dans le layer switcher
     *
     * @returns {DOMElement[]} array of two containers
     */
    _createAdvancedToolOpacityElement : function (obj) {
        // exemple :
        // <div id="GPopacity_ID_Layer1" class="GPlayerOpacity" title="Opacité">
        //   <input id="GPopacityRange_ID_Layer1" type="range" value="100" oninput="GPchangeLayerOpacity(this);" onchange="GPchangeLayerOpacity(this);">
        // </div>
        // <div class="GPlayerOpacityValue" id="GPopacityValueDiv_ID_Layer1">
        //   <span id="GPopacityValue_ID_Layer1">100</span>
        //   %
        // </div>

        var list = [];

        if (this._dsfr) {
            // curseur DSFR (fr-range) piloté par le widget, sans JavaScript DSFR
            var self = this;
            var dsfrOpacity = Math.round(((typeof obj.opacity !== "undefined") ? obj.opacity : 1) * 100);
            var inputId = this._addUID("GPopacityValueDiv_ID_" + obj.id);

            var label = document.createElement("label");
            label.className = "GPlayerOpacityLabel fr-label";
            label.htmlFor = inputId;
            label.textContent = "Opacité";

            var range = document.createElement("div");
            range.id = this._addUID("GPopacity_ID_" + obj.id);
            range.className = "GPlayerOpacity fr-range fr-range--sm";
            range.dataset.frJsRange = "true";

            var rangeInput = document.createElement("input");
            rangeInput.id = inputId;
            rangeInput.type = "range";
            rangeInput.min = "0";
            rangeInput.max = "100";
            rangeInput.step = "1";
            rangeInput.value = dsfrOpacity;
            rangeInput.setAttribute("aria-describedby", this._addUID("GPname_ID_" + obj.id));
            ["input", "change"].forEach(function (eventName) {
                rangeInput.addEventListener(eventName, function (e) {
                    self._onChangeLayerOpacity(e);
                });
            });
            range.appendChild(rangeInput);

            var output = document.createElement("div");
            output.className = "GPlayerOpacityValue";
            // valeur déjà restituée par le curseur (aria-valuetext)
            output.setAttribute("aria-hidden", "true");
            var outputValue = document.createElement("span");
            outputValue.id = this._addUID("GPopacityValue_ID_" + obj.id);
            outputValue.className = "gpf-range__output";
            outputValue.textContent = dsfrOpacity + "%";
            output.appendChild(outputValue);

            this._setOpacityRangeState(rangeInput, dsfrOpacity);

            return [label, range, output];
        }

        // curseur pour changer l'opacité
        var divO = document.createElement("div");
        divO.id = this._addUID("GPopacity_ID_" + obj.id);
        divO.className = "GPlayerOpacity";
        divO.title = "Opacité";

        var opacity = (typeof obj.opacity !== "undefined") ? obj.opacity : 1;
        opacity = Math.round(opacity * 100);

        var input = document.createElement("input");
        input.id = this._addUID("GPopacityValueDiv_ID_" + obj.id);
        input.type = "range";
        input.value = opacity;

        // add event for opacity change
        var context = this;
        if (input.addEventListener) {
            input.addEventListener(
                "change",
                function (e) {
                    context._onChangeLayerOpacity(e);
                }
            );
        } else if (input.attachEvent) {
            // internet explorer
            input.attachEvent(
                "onchange",
                function (e) {
                    context._onChangeLayerOpacity(e);
                }
            );
        }

        if (input.addEventListener) {
            input.addEventListener(
                "input",
                function (e) {
                    context._onChangeLayerOpacity(e);
                }
            );
        } else if (input.attachEvent) {
            // internet explorer
            input.attachEvent(
                "oninput",
                function (e) {
                    context._onChangeLayerOpacity(e);
                }
            );
        }

        divO.appendChild(input);

        // Valeur d'opacité
        var divC = document.createElement("div");
        divC.id = this._addUID("GPopacityValueDiv_ID_" + obj.id);
        divC.className = "GPlayerOpacityValue";

        var span = document.createElement("span");
        span.id = this._addUID("GPopacityValue_ID_" + obj.id);
        span.innerHTML = opacity + "%";

        divC.appendChild(span);

        list.push(divO);
        list.push(divC);

        return list;
    },

    /**
     * DSFR : synchronise la restitution du curseur d'opacité
     * (valeur textuelle et remplissage de la piste fr-range)
     *
     * @param {DOMElement} input - curseur d'opacité
     * @param {Number} value - opacité en pourcentage
     */
    _setOpacityRangeState : function (input, value) {
        var ratio = value / 100;
        input.setAttribute("aria-valuetext", value + " %");
        if (input.parentNode) {
            // même calcul que le JavaScript DSFR : centre du curseur
            input.parentNode.style.setProperty(
                "--progress-right",
                "calc(" + value + "% + " + (0.5 - ratio) + " * var(--thumb-size))"
            );
        }
    },

    // ################################################################### //
    // ############################ Layer info ########################### //
    // ################################################################### //

    /**
     * DSFR : liens de légende ordonnés par dénominateur d'échelle
     * (même calcul que le rendu Classic)
     *
     * @param {Object} obj - informations de la couche
     * @returns {Object[]} liens (url, label)
     */
    _getLayerInfoLegendLinks : function (obj) {
        var links = [];
        var legends = {};
        var maxScale = obj.maxScaleDenominator || 560000000;
        for (var k = 0; k < obj.legends.length; k++) {
            // eslint-disable-next-line security/detect-object-injection
            var minScale = obj.legends[k].minScaleDenominator;
            if (minScale) {
                var s = minScale.toString();
                minScale = Math.round(parseInt(s.substring(0, 3), 10) / 10) * Math.pow(10, s.length - 2);
            } else {
                minScale = 270;
            }
            // eslint-disable-next-line security/detect-object-injection
            legends[minScale] = obj.legends[k];
        }
        for (var scale in legends) {
            if (legends.hasOwnProperty(scale)) {
                // eslint-disable-next-line security/detect-object-injection
                var legend = legends[scale];
                // on n'affiche pas les légendes pointant vers "nolegend.jpg"
                if (typeof legend.url === "string" && legend.url.toLowerCase().indexOf("nolegend.jpg") === -1) {
                    maxScale = legend.maxScaleDenominator || maxScale;
                    links.push({
                        url : legend.url,
                        label : "Du 1/" + scale + " au 1/" + maxScale
                    });
                }
            }
        }
        return links;
    },

    /**
     * DSFR : section de liens du panneau d'informations
     *
     * @param {String} id - identifiant de la section
     * @param {String} title - titre de la section
     * @param {Object[]} links - liens (url, label)
     * @returns {DOMElement} section
     */
    _createLayerInfoLinksElement : function (id, title, links) {
        var section = document.createElement("div");
        section.id = id;

        var subtitle = document.createElement("p");
        subtitle.className = "GPlayerInfoSubtitle fr-text--bold fr-mb-1v";
        subtitle.textContent = title;
        section.appendChild(subtitle);

        var list = document.createElement("ul");
        list.className = "GPlayerInfoLinks";
        links.forEach(function (link) {
            var item = document.createElement("li");
            item.className = "GPlayerInfoLink";
            var anchor = document.createElement("a");
            anchor.className = "fr-link fr-link--sm";
            anchor.href = link.url;
            anchor.target = "_blank";
            anchor.rel = "noopener";
            anchor.title = link.label + " - nouvelle fenêtre";
            anchor.textContent = link.label;
            item.appendChild(anchor);
            list.appendChild(item);
        });
        section.appendChild(list);

        return section;
    },

    /**
     * Creation du container du layer info (DOM)
     *
     * TODO GPlayerInfoPopup : ???
     * TODO GPlayerInfoLink  : mettre en forme les échelles !
     *
     * @param {Object} obj - options de la couche à ajouter dans le layer switcher
     *
     * @returns {DOMElement} container
     */
    _createContainerLayerInfoElement : function (obj) {
        var container = document.createElement("div");
        container.id = this._addUID("GPlayerInfoContent");

        if (this._dsfr) {
            container.className = "gpf-panel__content";

            var dsfrTitle = document.createElement("p");
            dsfrTitle.id = this._addUID("GPlayerInfoTitle");
            dsfrTitle.className = "GPlayerInfoTitle fr-text--bold fr-mb-1w";
            dsfrTitle.innerHTML = obj.title;
            container.appendChild(dsfrTitle);

            var dsfrDesc = document.createElement("div");
            dsfrDesc.id = this._addUID("GPlayerInfoDescription");
            dsfrDesc.className = "GPlayerInfoDescription fr-text--sm";
            dsfrDesc.innerHTML = obj.description;
            container.appendChild(dsfrDesc);

            if (obj.quicklookUrl) {
                var quicklook = document.createElement("p");
                quicklook.className = "fr-mb-1w";
                var quicklookLink = document.createElement("a");
                quicklookLink.id = this._addUID("GPlayerInfoQuicklook");
                quicklookLink.className = "fr-link fr-link--sm fr-link--icon-left fr-icon-image-line";
                quicklookLink.href = obj.quicklookUrl;
                quicklookLink.target = "_blank";
                quicklookLink.rel = "noopener";
                quicklookLink.title = "Aperçu de la couche - nouvelle fenêtre";
                quicklookLink.textContent = "Aperçu de la couche";
                quicklook.appendChild(quicklookLink);
                container.appendChild(quicklook);
            }

            var metadataLinks = (obj.metadata || []).map(function (metadata) {
                return {
                    url : metadata.url,
                    label : metadata.url
                };
            });
            if (metadataLinks.length) {
                container.appendChild(this._createLayerInfoLinksElement(
                    this._addUID("GPlayerInfoMetadata"), "Métadonnées", metadataLinks
                ));
            }

            var legendLinks = obj.legends ? this._getLayerInfoLegendLinks(obj) : [];
            if (legendLinks.length) {
                container.appendChild(this._createLayerInfoLinksElement(
                    this._addUID("GPlayerInfoLegend"), "Légende", legendLinks
                ));
            }

            return container;
        }

        var title = document.createElement("div");
        title.id = this._addUID("GPlayerInfoTitle");
        title.innerHTML = obj.title;
        container.appendChild(title);

        if (obj.quicklookUrl) {
            var quick = document.createElement("div");
            quick.id = this._addUID("GPlayerInfoQuicklook");
            quick.title = "Afficher un aperçu de la couche";
            var refquick = document.createElement("a");
            refquick.href = obj.quicklookUrl;
            refquick.appendChild(quick);
            container.appendChild(refquick);
        }

        var close = document.createElement("div");
        close.id = this._addUID("GPlayerInfoClose");
        close.title = "Fermer la fenêtre";

        var self = this;
        /** Call event function on close click */
        var onCloseClick = function () {
            document.getElementById(self._addUID("GPlayerInfoPanel")).className = "GPlayerInfoPanelClosed";
            var layers = document.getElementsByClassName("GPlayerInfoOpened");
            for (var i = 0; i < layers.length; i++) {
                // eslint-disable-next-line security/detect-object-injection
                layers[i].className = "GPlayerInfo";
            }
        };
        if (close.addEventListener) {
            close.addEventListener("click", onCloseClick);
        } else if (close.attachEvent) {
            // internet explorer
            close.attachEvent("onclick", onCloseClick);
        }
        container.appendChild(close);

        var desc = document.createElement("div");
        desc.id = this._addUID("GPlayerInfoDescription");
        desc.innerHTML = obj.description;
        container.appendChild(desc);

        if (obj.metadata) {
            var mtd = document.createElement("div");
            mtd.id = this._addUID("GPlayerInfoMetadata");

            var mtdtitle = document.createElement("div");
            mtdtitle.className = "GPlayerInfoSubtitle";
            mtdtitle.innerHTML = "Métadonnées";
            mtd.appendChild(mtdtitle);

            for (var i = 0; i < obj.metadata.length; i++) {
                // eslint-disable-next-line security/detect-object-injection
                var urlmtd = obj.metadata[i].url;

                var mtdlink = document.createElement("div");
                mtdlink.className = "GPlayerInfoLink";

                var refmtd = document.createElement("a");
                refmtd.href = urlmtd;
                refmtd.innerHTML = urlmtd;
                mtdlink.appendChild(refmtd);
                mtd.appendChild(mtdlink);
            }

            if (obj.metadata.length !== 0) {
                container.appendChild(mtd);
            }
        }

        if (obj.legends) {
            var lgd = document.createElement("div");
            lgd.id = this._addUID("GPlayerInfoLegend");

            var lgdtitle = document.createElement("div");
            lgdtitle.className = "GPlayerInfoSubtitle";
            lgdtitle.innerHTML = "Légende";
            lgd.appendChild(lgdtitle);

            var legends = {};
            var maxScale = obj.maxScaleDenominator || 560000000;

            // on crée un tableau temporaire pour ordonner les légendes selon le dénominateur d'échelle
            for (var k = 0; k < obj.legends.length; k++) {
                // eslint-disable-next-line security/detect-object-injection
                var minScale = obj.legends[k].minScaleDenominator;
                if (minScale) {
                    var s = minScale.toString();
                    minScale = Math.round(parseInt(s.substring(0, 3), 10) / 10) * Math.pow(10, s.length - 2);
                } else {
                    minScale = 270;
                }
                // eslint-disable-next-line security/detect-object-injection
                legends[minScale] = obj.legends[k];
            }

            for (var scale in legends) {
                if (legends.hasOwnProperty(scale)) {
                    // eslint-disable-next-line security/detect-object-injection
                    var urllgd = legends[scale].url;
                    // on n'affiche pas les légendes pointant vers "nolegend.jpg"
                    if (typeof urllgd === "string" && urllgd.toLowerCase().indexOf("nolegend.jpg") === -1) {
                        // TODO GPlayerInfoPopup
                        var lgdlink = document.createElement("div");
                        lgdlink.className = "GPlayerInfoLink";

                        // eslint-disable-next-line security/detect-object-injection
                        maxScale = legends[scale].maxScaleDenominator || maxScale;

                        var reflgd = document.createElement("a");
                        reflgd.href = urllgd;
                        reflgd.innerHTML = "Du 1/" + scale + " au 1/" + maxScale;
                        lgdlink.appendChild(reflgd);
                        lgd.appendChild(lgdlink);
                    } else {
                        // eslint-disable-next-line security/detect-object-injection
                        delete legends[scale];
                    }
                }
            }

            if (Object.keys(legends).length !== 0) {
                container.appendChild(lgd);
            }
        }

        return container;
    }
};

export default LayerSwitcherDOM;
