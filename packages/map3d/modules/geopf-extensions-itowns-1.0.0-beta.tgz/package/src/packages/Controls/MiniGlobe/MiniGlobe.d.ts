export default MiniGlobe;
/**
 * @classdesc
 * Control to display the MiniGlobe with itowns
 *
 * @constructor
 * @extends {itowns.control.Widget}
 * @alias itowns.control.MiniGlobe
 * @param {Object} [options] - control options
 * @param {Object} [options.layer] - custom itowns layer to display on the mini globe
 * @param {Boolean} [options.collapsed = false] - hide the mini globe while keeping its toggle visible
 * @example
 * var miniglobe = new itowns.control.MiniGlobe();
 *
 */
declare function MiniGlobe(options?: {
    layer?: any;
    collapsed?: boolean | undefined;
}): void;
declare class MiniGlobe {
    /**
     * @classdesc
     * Control to display the MiniGlobe with itowns
     *
     * @constructor
     * @extends {itowns.control.Widget}
     * @alias itowns.control.MiniGlobe
     * @param {Object} [options] - control options
     * @param {Object} [options.layer] - custom itowns layer to display on the mini globe
     * @param {Boolean} [options.collapsed = false] - hide the mini globe while keeping its toggle visible
     * @example
     * var miniglobe = new itowns.control.MiniGlobe();
     *
     */
    constructor(options?: {
        layer?: any;
        collapsed?: boolean | undefined;
    });
    _dsfr: boolean;
    /**
     * Bind globe to control
     *
     * @param {GlobeViewExtended} globe - the globe
     */
    setGlobe(globe: GlobeViewExtended): void;
    _globeObj: GlobeViewExtended | undefined;
    private _initialize;
    _uid: number | undefined;
    _MiniGlobeContainer: any;
    _options: any;
    collapsed: any;
    _callbacks: {} | undefined;
    private _initContainer;
    _miniGlobeButton: any;
    _miniGlobeViewport: any;
    /**
     * Collapses or displays the mini globe viewport.
     *
     * @param {Boolean} collapsed - True to hide the mini globe, False to display it
     */
    setCollapsed(collapsed: boolean): void;
}
import GlobeViewExtended from "../../GlobeViewExtended";
//# sourceMappingURL=MiniGlobe.d.ts.map