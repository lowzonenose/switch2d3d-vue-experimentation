export function createWidgetToggle(options: any): HTMLButtonElement;
export function updateWidgetToggle(button: any, expanded: any): void;
//# sourceMappingURL=WidgetToggle.d.ts.map