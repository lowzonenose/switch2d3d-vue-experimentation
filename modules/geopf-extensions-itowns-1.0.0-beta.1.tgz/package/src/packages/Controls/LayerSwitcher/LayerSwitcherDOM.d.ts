export default LayerSwitcherDOM;
declare namespace LayerSwitcherDOM {
    function _createDraggableElement(elementDraggable: any, context: any): void;
    function _addUID(id: string): string;
    function _createMainContainerElement(): DOMElement;
    function _createMainLayersShowElement(): DOMElement;
    function _createMainLayersElement(): DOMElement;
    function _createMainPictoElement(): DOMElement;
    function _createMainInfoElement(): DOMElement;
    function _createContainerLayerElement(obj: {
        layer: any;
        id: string;
        title: string;
        description: string;
        visibility: boolean;
        opacity: Float;
    }): DOMElement;
    function _createBasicToolElement(obj: any): DOMElement;
    function _createBasicToolNameElement(obj: any): DOMElement;
    function _createBasicToolVisibilityElement(obj: any): DOMElement[];
    function _createAdvancedToolShowElement(obj: any): DOMElement[];
    function _createAdvancedToolElement(obj: any): DOMElement;
    function _createAdvancedToolDeleteElement(obj: any): DOMElement;
    function _createAdvancedToolInformationElement(obj: any): DOMElement;
    function _createAdvancedToolOpacityElement(obj: any): DOMElement[];
    function _createContainerLayerInfoElement(obj: any): DOMElement;
}
//# sourceMappingURL=LayerSwitcherDOM.d.ts.map