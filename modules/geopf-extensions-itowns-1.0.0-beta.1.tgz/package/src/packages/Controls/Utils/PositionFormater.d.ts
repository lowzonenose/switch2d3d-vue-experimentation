export default PositionFormater;
declare namespace PositionFormater {
    let NORTH: string;
    let SOUTH: string;
    let EAST: string;
    let WEST: string;
    let digitSecond: number;
    let digitDecimal: number;
    let digitRadian: number;
    function roundToDecimal(inputNum: any, numPoints: any): number;
    function decimalToRadian(location: any): number;
    function decimalToGrade(location: any): number;
    function decimalToDMS(location: any, hemisphere: any): string;
    function decimalLatToDMS(location: any): string;
    function decimalLongToDMS(location: any): string;
    function DMSToDecimal(degrees: any, minutes: any, seconds: any, hemisphere: any): number;
}
//# sourceMappingURL=PositionFormater.d.ts.map