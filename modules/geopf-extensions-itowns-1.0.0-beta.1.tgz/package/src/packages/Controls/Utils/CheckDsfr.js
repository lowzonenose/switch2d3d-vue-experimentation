/**
 * Detect the optional extension theme, not just a DSFR host page.
 * @returns {Boolean} Whether the DSFR extension theme is loaded.
 */
export default function checkDsfr () {
    var style = getComputedStyle(document.documentElement);
    return style.getPropertyValue("--gpf-itowns-theme").trim() === "dsfr" &&
        style.getPropertyValue("--blue-france-sun-113-625").trim() !== "";
}
