/**
 * Detect the optional extension theme, not just a DSFR host page.
 * @returns {Boolean} Whether the DSFR extension theme is loaded.
 */
export default function checkDsfr(): boolean;
//# sourceMappingURL=CheckDsfr.d.ts.map