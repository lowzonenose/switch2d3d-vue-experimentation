export default LayerWMTS;
/**
 * @classdesc
 * Geopf WMTS source creation
 *
 * @constructor
 * @alias itowns.layer.GeopfWMTS
 * @param {Object} options            - options for function call.
 * @param {String} options.layer      - Layer name (e.g. "ORTHOIMAGERY.ORTHOPHOTOS")
 * @param {Boolean} [options.ssl = true] - use of ssl or not (default true, service requested using https protocol)
 * @param {String} [options.apiKey]   - Access key to Geoplateform
 * @param {Boolean} [options.tag]   - Indicates whether the layer should be tagged or not
 * @param {Array} [options.legends]   - Overloads the default legends objects associated to the layer
 * @param {Array} [options.metadata]   - Overloads the default Metadata objects associated to the layer
 * @param {String} [options.title]   - Overloads the default title of the layer
 * @param {String} [options.description]   - Overloads the default description of the layer
 * @param {String} [options.quicklookUrl]   - Overloads the default quicklookUrl of the layer
 * @param {Object} [options.itownsParams] - other options for itowns.GlobeView.addLayer function (see {@link http://www.itowns-project.org/itowns/API_Doc/GlobeView.html#addLayer GlobeView.addLayer})
 * @example
 * var geoportalWMTS = new itowns.layer.GeopfWMTS({
 *      layer  : "ORTHOIMAGERY.ORTHOPHOTOS"
 * });
 */
declare function LayerWMTS(options: {
    layer: string;
    ssl?: boolean | undefined;
    apiKey?: string | undefined;
    tag?: boolean | undefined;
    legends?: any[] | undefined;
    metadata?: any[] | undefined;
    title?: string | undefined;
    description?: string | undefined;
    quicklookUrl?: string | undefined;
    itownsParams?: any;
}): any;
declare class LayerWMTS {
    /**
     * @classdesc
     * Geopf WMTS source creation
     *
     * @constructor
     * @alias itowns.layer.GeopfWMTS
     * @param {Object} options            - options for function call.
     * @param {String} options.layer      - Layer name (e.g. "ORTHOIMAGERY.ORTHOPHOTOS")
     * @param {Boolean} [options.ssl = true] - use of ssl or not (default true, service requested using https protocol)
     * @param {String} [options.apiKey]   - Access key to Geoplateform
     * @param {Boolean} [options.tag]   - Indicates whether the layer should be tagged or not
     * @param {Array} [options.legends]   - Overloads the default legends objects associated to the layer
     * @param {Array} [options.metadata]   - Overloads the default Metadata objects associated to the layer
     * @param {String} [options.title]   - Overloads the default title of the layer
     * @param {String} [options.description]   - Overloads the default description of the layer
     * @param {String} [options.quicklookUrl]   - Overloads the default quicklookUrl of the layer
     * @param {Object} [options.itownsParams] - other options for itowns.GlobeView.addLayer function (see {@link http://www.itowns-project.org/itowns/API_Doc/GlobeView.html#addLayer GlobeView.addLayer})
     * @example
     * var geoportalWMTS = new itowns.layer.GeopfWMTS({
     *      layer  : "ORTHOIMAGERY.ORTHOPHOTOS"
     * });
     */
    constructor(options: {
        layer: string;
        ssl?: boolean | undefined;
        apiKey?: string | undefined;
        tag?: boolean | undefined;
        legends?: any[] | undefined;
        metadata?: any[] | undefined;
        title?: string | undefined;
        description?: string | undefined;
        quicklookUrl?: string | undefined;
        itownsParams?: any;
    });
}
//# sourceMappingURL=LayerWMTS.d.ts.map