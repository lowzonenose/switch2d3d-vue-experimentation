export default MathUtils;
declare namespace MathUtils {
    function modulo(a: number, b: number): number;
    function decimalToDMS(degrees: number, hemispheres: any[], numDigits: number): any;
    function toInteger(s: string, base: Numeric): null | Numeric;
    function isInteger(s: string): boolean;
    function toFloat(s: string): null | Numeric;
}
//# sourceMappingURL=MathUtils.d.ts.map