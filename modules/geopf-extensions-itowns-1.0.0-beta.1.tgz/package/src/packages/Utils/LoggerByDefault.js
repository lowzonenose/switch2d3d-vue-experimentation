import * as Log from "loglevel";

/**
 * @module LoggerByDefault
 * @alias [private] LoggerByDefault
 * @description
 * ...
 *
 * @example
 * getLogger();
 * disableAll();
 * enableAll();
 */
var LoggerByDefault = {
    /**
     * creation d'un logger statique
     *
     * @function getLogger
     * @param {String} [name="default"] - the logger name
     * @returns {Object} logger
     */
    getLogger : function (name) {
        const verbose =
            (typeof process !== "undefined") &&
            process.env &&
            process.env.VERBOSE;

        verbose ? Log.enableAll() : Log.disableAll();

        return Log.getLogger(name || "default");
    },
    /**
     * desactive tous les loggers
     * @function disableAll
     */
    disableAll : function () {
        var loggers = Log.getLoggers();
        for (const key in loggers) {
            if (Object.hasOwnProperty.call(loggers, key)) {
                // eslint-disable-next-line security/detect-object-injection
                const logger = loggers[key];
                logger.disableAll();
            }
        }
    },
    /**
     * active tous les loggers
     * @function enableAll
     */
    enableAll : function () {
        var loggers = Log.getLoggers();
        for (const key in loggers) {
            if (Object.hasOwnProperty.call(loggers, key)) {
                // eslint-disable-next-line security/detect-object-injection
                const logger = loggers[key];
                logger.enableAll();
            }
        }
    }
};

export default LoggerByDefault;
