// Common styles
import "./CSS/GPwaiting.css";
import "./CSS/GPgeneralWidget.css";
import "./CSS/GPboostRelief.css";
import "./CSS/GPbuildings.css";
import "./CSS/GPlayerSwitcher.css";
import "./CSS/GPmousePosition.css";

// iTowns specific styles
import "./CSS/GPgeneralWidgetItowns.css";
import "./CSS/Controls/Attribution/GPattributionItowns.css";
import "./CSS/Controls/BoostRelief/GPboostReliefItowns.css";
import "./CSS/Controls/Buildings/GPbuildingsItowns.css";
import "./CSS/Controls/LayerSwitcher/GPlayerSwitcherItowns.css";
import "./CSS/Controls/MiniGlobe/GPminiGlobeItowns.css";
import "./CSS/Controls/MousePosition/GPmousePositionItowns.css";
import "./CSS/Controls/Scale/GPscaleItowns.css";
