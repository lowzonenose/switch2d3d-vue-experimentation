export default Utils;
declare namespace Utils {
    function isSafeObjectKey(key: string): boolean;
    function detectSupport(): boolean;
    function assign(dest: any, source: any): any;
    function mergeParams(dest: any, source: any, replace: boolean): void;
}
//# sourceMappingURL=Utils.d.ts.map