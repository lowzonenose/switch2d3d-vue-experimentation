/**
* @module Utils
* @alias Gp.olUtils
* @description
* ...
*
* @example
* detectSupport();
* assign();
* mergeParams();
*/
var Utils = {

    /**
     * Guard against prototype-pollution keys when merging/copying objects.
     *
     * @param {String} key - object key
     * @returns {Boolean} true if key is safe
     */
    isSafeObjectKey : function (key) {
        return key !== "__proto__" && key !== "prototype" && key !== "constructor";
    },

    /**
     * this method is called by the constructor.
     * this information is useful to switch to touch mode.
     * Detection : test for desktop or tactile
     *
     * @function detectSupport
     * @returns {Boolean} isDesktop - true for desktop userAgent, false for mobile
     */
    detectSupport : function () {
        var isDesktop = true;
        var userAgent = window.navigator.userAgent.toLowerCase();

        if (userAgent.indexOf("iphone") !== -1 ||
            userAgent.indexOf("ipod") !== -1 ||
            userAgent.indexOf("ipad") !== -1 ||
            userAgent.indexOf("android") !== -1 ||
            userAgent.indexOf("mobile") !== -1 ||
            userAgent.indexOf("blackberry") !== -1 ||
            userAgent.indexOf("tablet") !== -1 ||
            userAgent.indexOf("phone") !== -1 ||
            userAgent.indexOf("touch") !== -1) {
            isDesktop = false;
        }

        if (userAgent.indexOf("msie") !== -1 ||
            userAgent.indexOf("trident") !== -1) {
            isDesktop = true;
        }

        return isDesktop;
    },

    /**
     *  Copies all source object members to dest
     *
     * @function assign
     * @param {Object} dest - destination object where properties and method will be copied
     * @param {Object} source - source object from which properties and method will be copied
     * @returns {Object} dest
     */
    assign : function (dest, source) {
        dest = dest || {};
        /* eslint-disable security/detect-object-injection */
        for (var prop in source) {
            if (source.hasOwnProperty(prop) && this.isSafeObjectKey(prop)) {
                dest[prop] = source[prop];
            }
        }
        /* eslint-enable security/detect-object-injection */
        return dest;
    },

    /**
     * Merge two objects parameters (deeper than assign)
     *
     * @function mergeParams
     * @param {Object} dest     - destination object where properties and method will be merge
     * @param {Object} source   - source object from which properties and method will be merge
     * @param {Boolean} replace - replace destination value by source if exists or not (true by default)
     */
    mergeParams : function (dest, source, replace) {
        if (typeof dest === "undefined" || typeof source === "undefined") {
            return;
        }
        if (typeof replace === "undefined") {
            replace = true;
        }
        /* eslint-disable security/detect-object-injection */
        for (var param in source) {
            if (source.hasOwnProperty(param) && this.isSafeObjectKey(param)) {
                if (typeof source[param] === "object") {
                    if (dest.hasOwnProperty(param)) {
                        this.mergeParams(dest[param], source[param], replace);
                    } else {
                        dest[param] = source[param];
                    }
                } else {
                    if (dest.hasOwnProperty(param)) {
                        if (replace) {
                            dest[param] = source[param];
                        }
                    } else {
                        dest[param] = source[param];
                    }
                }
            }
        }
        /* eslint-enable security/detect-object-injection */
    }
};

export default Utils;
