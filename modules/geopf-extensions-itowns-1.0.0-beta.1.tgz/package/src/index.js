import Pkg from "../package.json";

// Keep module samples visually consistent with bundle samples.
import "./packages/Styles";

// couches
// export { default as LayerElevation } from "./packages/Layers/LayerElevation";
// export { default as LayerWMTS } from "./packages/Layers/LayerWMTS";
// export { default as LayerWMS } from "./packages/Layers/LayerWMS";
// export { default as VectorTileLayer } from "./packages/Layers/VectorTileLayer";
export { default as GeopfWMTS } from "./packages/Layers/LayerWMTS";
export { default as GeopfWMS } from "./packages/Layers/LayerWMS";
export { default as GeopfElevation } from "./packages/Layers/LayerElevation";
export { default as VectorTileLayer } from "./packages/Layers/VectorTileLayer";

// controles
export { default as LayerSwitcher } from "./packages/Controls/LayerSwitcher/LayerSwitcher";
export { default as MousePosition } from "./packages/Controls/MousePosition/MousePosition";
export { default as Attributions } from "./packages/Controls/Attributions/Attributions";
export { default as BoostRelief } from "./packages/Controls/BoostRelief/BoostRelief";
export { default as Buildings } from "./packages/Controls/Buildings/Buildings";
export { default as Scale } from "./packages/Controls/Scale/Scale";
export { default as MiniGlobe } from "./packages/Controls/MiniGlobe/MiniGlobe";
export { default as GlobeViewExtended } from "./packages/GlobeViewExtended";

// proj4
export { default as Proj4 } from "proj4";

// utilitaires
export { default as LayerUtils } from "./packages/Utils/LayerUtils";
export { default as ProxyUtils } from "./packages/Utils/ProxyUtils";
export { default as ColorUtils  } from "./packages/Utils/ColorUtils";
export { default as MathUtils } from "./packages/Utils/MathUtils";
export { default as LoggerUtils } from "./packages/Utils/LoggerByDefault";
// TODO : à activer quand le module sera disponible
// export { sanitizeHtml } from "./packages/Utils/Sanitize";

// projections
export { default as CRS } from "./packages/CRS/CRS";

/** Version */
export const version = Pkg.version;
/** Publication date */
export const date = Pkg.date;