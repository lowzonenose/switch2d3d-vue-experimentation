# DEPENDENCIES (30/03/2026)

* proj4

last
└── proj4@2.7.2

* Sortable

last
└── sortablejs@1.14.0

* geoportal-access-lib

last
└── geoportal-access-lib@3.1.0

last
└── leaflet-draw@1.0.4

* "itowns"

└── "itowns@2.33.0"

* loglevel

last
└── "loglevel@1.6.1"

* request

last
└── "request@2.83.0"

* xmldom

last
└── "@xmldom/xmldom@0.9.0"
