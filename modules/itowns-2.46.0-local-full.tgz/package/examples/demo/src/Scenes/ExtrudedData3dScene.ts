import * as itowns from 'itowns';
import * as THREE from 'three';
import * as Layers from '../Layers';
import { View3D } from '../Views';
import type { SceneType } from '../Types';

export const ExtrudedData3dScene: SceneType = {
    title: 'Build Cities in Seconds',
    description: 'Bring your city to life by extruding building footprints '
        + 'based on height attributes. Create realistic urban landscapes in real-time.',
    placement: {
        coord: new itowns.Coordinates('EPSG:4326', 4.828, 45.7254),
        range: 2000,
        tilt: 45,
        heading: 0,
    },
    layers: [],
    view: undefined,
    meshes: [],
    ready: false,
    event: function update(/* dt */) {
        const itownsView = ExtrudedData3dScene.getItownsView();
        const meshes = ExtrudedData3dScene.meshes ?? [];
        if (meshes.length) {
            for (let i = 0; i < meshes.length; i++) {
                const mesh = meshes[i];
                if (mesh && mesh.scale.z < 1) {
                    mesh.scale.z = Math.min(1.0, mesh.scale.z + 0.005);
                    mesh.updateMatrixWorld(true);
                }
            }
            itownsView.notifyChange(itownsView.camera3D, true);
        }
    },
    getView: () => {
        if (!ExtrudedData3dScene.view) {
            ExtrudedData3dScene.view = new View3D();
        }
        return ExtrudedData3dScene.view;
    },
    getItownsView: () => ExtrudedData3dScene.getView().getItownsView(),
    onCreate: async () => {
        if (ExtrudedData3dScene.ready) {
            return;
        }
        if (!ExtrudedData3dScene.view) {
            ExtrudedData3dScene.view = new View3D();
        }

        function scaleZ(mesh: THREE.Mesh) {
            for (let i = 0; i < mesh.children.length; i++) {
                const c = mesh.children[i];
                c.scale.z = 0.01;
                ExtrudedData3dScene.meshes?.push(c);
            }
        }

        ExtrudedData3dScene.layers.push(await Layers.OrthoFetcherLayer.getLayer());
        ExtrudedData3dScene.layers.push(await Layers.WorldDTMFetcherLayer.getLayer());
        ExtrudedData3dScene.layers.push(await Layers.IgnMntHighResFetcherLayer.getLayer());
        ExtrudedData3dScene.layers.push(await Layers.FlatBuildingsLayer.getLayer());
        ExtrudedData3dScene.layers.push(await Layers.ParksLayer.getLayer());
        ExtrudedData3dScene.layers.push(await Layers.Buildings3dLayer.getLayer(scaleZ));
        await ExtrudedData3dScene.view.addLayers(ExtrudedData3dScene.layers);

        ExtrudedData3dScene.ready = true;
    },
    onEnter: async () => {
        const itownsView = ExtrudedData3dScene.getItownsView();
        for (const mesh of ExtrudedData3dScene.meshes ?? []) {
            itownsView.scene.add(mesh);
        }
        itownsView.addFrameRequester(
            itowns.MAIN_LOOP_EVENTS.BEFORE_RENDER, ExtrudedData3dScene.event);
    },
    onExit: async () => {
        const itownsView = ExtrudedData3dScene.getItownsView();
        for (const mesh of ExtrudedData3dScene.meshes ?? []) {
            itownsView.scene.remove(mesh);
        }
        itownsView.removeFrameRequester(
            itowns.MAIN_LOOP_EVENTS.BEFORE_RENDER, ExtrudedData3dScene.event);
    },
};
