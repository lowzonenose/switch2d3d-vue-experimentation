import * as THREE from 'three';

// set object position to the coordinate
// set object ENH orientation: X to the east, Y (green) to the north, Z (blue) look to the sky.
function placeObjectFromCoordinate(object, coord) {
    // set object position to the coordinate
    coord.toVector3(object.position);
    // set ENH orientation, looking at the sky (Z axis), so Y axis look to the north..
    object.lookAt(coord.geodesicNormal.clone().add(object.position));
}

function createTexturedPlane(textureUrl, opacity) {
    const texture = new THREE.TextureLoader().load(textureUrl);
    const geometry = new THREE.PlaneGeometry(1, 1, 32);
    const material = new THREE.MeshBasicMaterial({
        map: texture,
        color: 0xffffff,
        transparent: true,
        opacity: opacity,
    });
    return new THREE.Mesh(geometry, material);
}

function transformTexturedPlane(camera, distance, plane) {
    const Yreel = 2 * Math.tan(THREE.MathUtils.degToRad(camera.fov / 2)) * distance;
    const Xreel = camera.aspect * Yreel;

    // set position and scale
    plane.scale.set(Xreel, Yreel, 1);
    plane.position.set(0, 0, -distance);

    plane.updateMatrixWorld();
}

function initCamera(view, image, coord, EnhToOrientationUp, EnhToOrientationLookAt, rotMatrix,
    orientationToCameraUp, orientationToCameraLookAt, distance, size, focale) {
    const fov = THREE.MathUtils.radToDeg((2 * Math.atan((size[1] / 2) / focale)));
    const coordView = coord.as(view.referenceCrs);

    // create 'local space', with the origin placed on 'coord',
    // with Y axis to the north, X axis to the east and Z axis as the geodesic normal.
    const localSpace = new THREE.Object3D();
    view.scene.add(localSpace);
    placeObjectFromCoordinate(localSpace, coordView);

    // add second object : 'oriented image'
    const orientedImage = new THREE.Object3D();
    // setup initial convention orientation.
    orientedImage.up.copy(EnhToOrientationUp);
    orientedImage.lookAt(EnhToOrientationLookAt);

    // place the 'oriented image' in the 'local space'
    localSpace.add(orientedImage);

    // apply rotation
    const quaternion = new THREE.Quaternion().setFromRotationMatrix(rotMatrix);
    orientedImage.quaternion.multiply(quaternion);
    // orientedImage.updateMatrixWorld();

    // create a THREE JS Camera
    const camera = new THREE.PerspectiveCamera(fov, size[0] / size[1], distance / 2, distance * 2);
    camera.up.copy(orientationToCameraUp);
    camera.lookAt(orientationToCameraLookAt);

    orientedImage.add(camera);

    localSpace.updateMatrixWorld(true);
    return camera;
}

function setupPictureFromCamera(camera, imageUrl, opacity, distance) {
    // create a textured plane, representing the picture.
    const plane = createTexturedPlane(imageUrl, opacity);
    camera.add(plane);

    transformTexturedPlane(camera, distance, plane);

    return plane;
}

// set camera settings to view.camera,
// BUT keep the geodesic normal as Up vector
function setupViewCameraLookingAtObject(camera, coord, objectToLookAt) {
    camera.position.copy(coord);
    camera.up.copy(coord.geodesicNormal);
    camera.lookAt(objectToLookAt.getWorldPosition());
}

// set camera settings to view.camera, even the up vector !
function setupViewCameraDecomposing(view, camera) {
    let upWorld;
    camera.matrixWorld.decompose(view.camera3D.position, view.camera3D.quaternion, view.camera3D.scale);

    // setup up vector
    upWorld = camera.localToWorld(camera.up.clone());
    upWorld = view.camera3D.position.clone().sub(upWorld);
    view.camera3D.up.copy(upWorld);
}

// add a camera helper to debug camera position..
function addCameraHelper(view, camera) {
    const cameraHelper = new THREE.CameraHelper(camera);
    view.scene.add(cameraHelper);
    cameraHelper.updateMatrixWorld(true);
}

function setupPictureUI(menu, pictureInfos, plane, updateDistanceCallback, view, min, max) {
    const orientedImageGUI = menu.gui.addFolder('Oriented Image');
    orientedImageGUI.add(pictureInfos, 'distance', min, max).name('Distance').onChange(function distanceChanged(value) {
        pictureInfos.distance = value;
        updateDistanceCallback();
        view.notifyChange();
    });
    orientedImageGUI.add(pictureInfos, 'opacity', 0, 1).name('Opacity').onChange(function opacityChanged(value) {
        plane.material.opacity = value;
        view.notifyChange();
    });
}


export default {
    setupPictureFromCamera,
    setupViewCameraLookingAtObject,
    initCamera,
    setupViewCameraDecomposing,
    addCameraHelper,
    transformTexturedPlane,
    setupPictureUI,
};
