declare namespace _default {
    function update(context: any, layer: any, node: any): any;
}
export default _default;
