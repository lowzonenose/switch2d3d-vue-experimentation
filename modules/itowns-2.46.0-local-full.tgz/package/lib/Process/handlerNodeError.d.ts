export default function handlingError(err: any, node: any, layer: any, targetLevel: any, view: any, layerState: any): void;
