export default threeExamples.LegacyGLTFLoader;
declare var LegacyGLTFLoader: {
    new (manager: any): {
        load(url: any, onLoad: any, onProgress: any, onError: any): void;
        parse(data: any, path: any, callback: any): void;
        crossOrigin: string;
        withCredentials: boolean;
        path: string;
        resourcePath: string;
        manager: THREE.LoadingManager;
        requestHeader: {
            [header: string]: string;
        };
        loadAsync(url: string, onProgress?: (event: ProgressEvent) => void): Promise<any>;
        setCrossOrigin(crossOrigin: string): /*elided*/ any;
        setWithCredentials(value: boolean): /*elided*/ any;
        setPath(path: string): /*elided*/ any;
        setResourcePath(resourcePath: string): /*elided*/ any;
        setRequestHeader(requestHeader: {
            [header: string]: string;
        }): /*elided*/ any;
        abort(): /*elided*/ any;
    };
    Shaders: {
        update: () => void;
    };
    Animations: {
        update: () => void;
    };
    DEFAULT_MATERIAL_NAME: string;
};
declare namespace threeExamples { }
import * as THREE from 'three';
