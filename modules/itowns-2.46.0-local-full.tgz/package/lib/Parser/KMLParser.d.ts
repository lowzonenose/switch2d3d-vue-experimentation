declare namespace _default {
    /**
     * Parse a KML file content and return a {@link FeatureCollection}.
     *
     * @param {XMLDocument} kmlFile - The KML file content to parse.
     * @param {ParsingOptions} options - Options controlling the parsing.
     *
     * @returns {Promise} A promise resolving with a {@link FeatureCollection}.
     */
    function parse(kmlFile: XMLDocument, options: ParsingOptions): Promise<any>;
}
export default _default;
