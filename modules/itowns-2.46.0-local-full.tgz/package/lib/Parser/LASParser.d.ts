declare namespace _default {
    function enableLazPerf(path: any): void;
    /**
     * Terminate all worker instances.
     * @returns {Promise<void>}
     */
    function terminate(): Promise<void>;
    /**
     * Parses a chunk of a LAS or LAZ (LASZip) and returns the corresponding
     * `THREE.BufferGeometry`.
     *
     * @param {ArrayBuffer} data - The file content to parse.
     * @param {object} options
     * @param {object} options.in - Options to give to the parser.
     * @param {number} options.in.numPoints - Number of points encoded in this
     * data chunk.
     * @param {object} options.in.source - Source information.
     * @param {object} options.in.source.header - Partial LAS file header.
     * @param {number} options.in.source.header.pointDataRecordFormat - Type of
     * Point Data Record contained in the LAS file.
     * @param {number} options.in.source.header.pointDataRecordLength - Size
     * (in bytes) of the Point Data Record.
     * @param {object} [options.in.source.eb] - Extra bytes LAS VLRs headers.
     * @param { 8 | 16 } [options.in.colorDepth] - Color depth (in bits).
     * Defaults to 8 bits for LAS 1.2 and 16 bits for later versions
     * (as mandatory by the specification)
     *
     * @returns {Promise<THREE.BufferGeometry>} A promise resolving with a
     * `THREE.BufferGeometry`.
     */
    function parseChunk(data: ArrayBuffer, options?: {
        in: {
            numPoints: number;
            source: {
                header: {
                    pointDataRecordFormat: number;
                    pointDataRecordLength: number;
                };
                eb?: object | undefined;
            };
            colorDepth?: 8 | 16 | undefined;
        };
    }): Promise<THREE.BufferGeometry>;
    /**
     * Parses a LAS file or a LAZ (LASZip) file and return the corresponding
     * `THREE.BufferGeometry`.
     *
     * @param {ArrayBuffer} data - The file content to parse.
     * @param {object} options - Options to give to the parser.
     * @param {object} options.in
     * @param {object} options.in.source - Source of the node.
     * @param {string} options.in.source.crs - Crs of the source.
     * @param { 8 | 16 } [options.in.source.colorDepth] - Color depth (in bits).
     * Defaults to 8 bits for LAS 1.2 and 16 bits for later versions
     * (as mandatory by the specification)
     * @param {THREE.Matrix4} options.in.clampOBB.matrix - World transformation
     * matrix of the node
     * @param {string} options.out.crs - Crs of the view.
     *
     * @returns {Promise} A promise resolving with a `THREE.BufferGeometry`. The
     * header of the file is contained in `userData`.
     */
    function parse(data: ArrayBuffer, options?: {
        in: {
            source: {
                crs: string;
                colorDepth?: 8 | 16 | undefined;
            };
        };
    }): Promise<any>;
}
export default _default;
import * as THREE from 'three';
