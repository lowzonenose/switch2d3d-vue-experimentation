/**
 * Calculates the minimum maximum texture elevation with xbil data
 *
 * @param      {THREE.Texture}   texture                     The texture to parse
 * @param      {THREE.Vector4}   pitch                       The pitch,  restrict zone to parse
 * @param      {object}          options                     No data value and clamp values
 * @param      {number}          options.noDataValue         No data value
 * @param      {number}          [options.zmin]   The minimum elevation value after which it will be clamped
 * @param      {number}          [options.zmax]   The maximum elevation value after which it will be clamped
 * @returns     {object}  The minimum and maximum elevation.
 */
export function computeMinMaxElevation(texture: THREE.Texture, pitch: THREE.Vector4, options: {
    noDataValue: number;
    zmin?: number | undefined;
    zmax?: number | undefined;
}): object;
export function checkNodeElevationTextureValidity(data: any, noDataValue: any): boolean;
export function insertSignificantValuesFromParent(data: any, dataParent: () => number, noDataValue: any): void;
