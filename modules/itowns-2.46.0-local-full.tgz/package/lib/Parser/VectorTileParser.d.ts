declare namespace _default {
    /**
     * Parse a vector tile file and return a [Feature]{@link module:GeoJsonParser.Feature}
     * or an array of Features. While multiple formats of vector tile are
     * available, the only one supported for the moment is the
     * [Mapbox Vector Tile](https://www.mapbox.com/vector-tiles/specification/).
     *
     * @param {ArrayBuffer} file - The vector tile file to parse.
     *
     * @param {object} options - Options controlling the parsing {@link ParsingOptions}.
     *
     * @param {object} options.in - Object containing all styles,
     * layers and informations data, see {@link Source}.
     *
     * @param {object} options.in.styles - Object containing subobject with
     * informations on a specific style layer. Styles available is by `layer.id` and by zoom.
     *
     * @param {object} options.in.layers - Object containing subobject with
     *
     * @param {FeatureBuildingOptions} options.out - options indicates how the features should be built,
     * see {@link FeatureBuildingOptions}.
     *
     * @returns {Promise} A Promise resolving with a Feature or an array a
     * Features.
     */
    function parse(file: ArrayBuffer, options: {
        in: {
            styles: object;
            layers: object;
        };
        out: FeatureBuildingOptions;
    }): Promise<any>;
}
export default _default;
