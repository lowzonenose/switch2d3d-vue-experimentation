declare namespace _default {
    function parse(buffer: ArrayBuffer, options: object): Promise<any>;
}
export default _default;
