import { DataTexture, Vector2 } from 'three';
import type { TextureDataType } from 'three';
import type { Extent } from '@itowns/geographic';
import type { Pool, GeoTIFFImage } from 'geotiff';
export type TextureWithExtent = DataTexture & {
    extent: Extent;
};
declare function selectDataType(format: number, bitsPerSample: number): 1009 | 1010 | 1011 | 1012 | 1013 | 1014 | 1015 | 1016;
/**
 * A node that stores information about an image in a GeoTIFF File and accessors
 * to retrieve actual image data.
 *
 * It is basicaly a wrapper around
 * [GeoTIFFImage](https://geotiffjs.github.io/geotiff.js/module-geotiffimage-GeoTIFFImage.html).
 */
declare class GeotiffNode {
    /**
     * A GeoTIFFImage instance for the image.
     */
    image: GeoTIFFImage;
    /**
     * The width of the image, in pixel.
     */
    width: number;
    /**
     * The height of the image, in pixel.
     */
    height: number;
    /**
     * The resolution of the image, in distance per pixel. The resolution is
     * stored in a array containing in order the horizontal resolution and the
     * vertical resolution.
     */
    resolution: number[];
    /**
     * The coordinates of the top-left corner of the image, expressed in the
     * GeoTIFF data CRS.
     */
    origin: number[];
    /**
     * The Three.js TextureDataType that matches the format of the image.
     */
    dataType: TextureDataType;
    /**
     * The number of bands in the image (4 for RGBA, 3 for RGB...)
     */
    samplesPerPixel: number;
    constructor(config: {
        image: GeoTIFFImage;
        resolution?: number[];
        origin?: number[];
        dataType?: TextureDataType;
    });
    private get reader();
    /**
     * Extract a portion of the image into a Three.js Texture. The portion is
     * delimited by a window. This window is a set of four boundaries (Xmin,
     * Ymin, Xmax, Ymax) expressed in the image pixel space.
     * @param options
     * @param options.imageWindow
     * @param options.textureDimensions
     * @param options.resampleMethod
     * @param options.defaultAlpha
     * @param options.pool
     * @returns
     */
    extractTexture(options: {
        imageWindow?: number[];
        textureDimensions: Vector2;
        resampleMethod?: string;
        defaultAlpha?: number;
        pool?: Pool;
    }): Promise<DataTexture>;
    /**
     * Converts an extent expressed in the GeoTIFF data CRS to an image window,
     * so the same extent expressed in the image pixel space.
     * @param extent
     * @returns
     */
    extentToImageWindow(extent: Extent): number[];
}
/**
 * Parse a GeoTIFFImage object read from a GeoTIFF file and returns a Three.js
 * Texture.
 *
 * At the moment, iTowns only displays data either as single band or RGBA
 * textures. Therefore, a GeoTIFF image with a number of samples other than 1,
 * 2 or 3 won't be displayed.
 * @param data
 * @param options
 * @returns
 */
declare function parse(data: GeoTIFFImage, options: any): Promise<TextureWithExtent>;
declare const _default: {
    parse: typeof parse;
};
export default _default;
export { GeotiffNode, selectDataType, };
