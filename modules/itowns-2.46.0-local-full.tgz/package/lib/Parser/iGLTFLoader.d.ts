export default iGLTFLoader;
declare class iGLTFLoader extends THREE.Loader<any, string> {
    /**
     * Parses [glTF](https://www.khronos.org/gltf/) 1.0 and 2.0 files.
     *
     * Under the hood, glTF 2.0 files are parsed with THREE.GLTFLoader and GLTF 1.0 are parsed with the previous THREE
     * GltfLoader (for 1.0 glTF) that has been kept and maintained in iTowns.
     *
     * Beware that gltf convention is y-up while itowns is z-up. You can apply a PI/2 rotation around the X axis to the
     * loaded model to transform from y-up to z-up. Note that you can also use Coordinates.geodesicNormal to get the normal
     * to a position on the globe (i.e. in GlobeView) to correctly orient a model on a GlobeView.
     *
     * @param {THREE.LoadingManager} [manager] - The loadingManager for the loader to use. Default is THREE.DefaultLoadingManager.
     */
    constructor(manager?: THREE.LoadingManager);
    legacyGLTFLoader: {
        load(url: any, onLoad: any, onProgress: any, onError: any): void;
        parse(data: any, path: any, callback: any): void;
        crossOrigin: string;
        withCredentials: boolean;
        path: string;
        resourcePath: string;
        manager: THREE.LoadingManager;
        requestHeader: {
            [header: string]: string;
        };
        loadAsync(url: string, onProgress?: (event: ProgressEvent) => void): Promise<any>;
        setCrossOrigin(crossOrigin: string): /*elided*/ any;
        setWithCredentials(value: boolean): /*elided*/ any;
        setPath(path: string): /*elided*/ any;
        setResourcePath(resourcePath: string): /*elided*/ any;
        setRequestHeader(requestHeader: {
            [header: string]: string;
        }): /*elided*/ any;
        abort(): /*elided*/ any;
    };
    glTFLoader: GLTFLoader;
    /**
     * Loads a gltf model from url and call the callback function with the parsed response content.
     * Adapted from threejs.
     * @param {string} url - the path/URL of the .gltf or .glb file.
     * @param {Function} onLoad - A function to be called after the loading is successfully completed. The function
     * receives the loaded JSON response returned from {@link parse}.
     * @param {Function} onProgress
     * @param {Function} onError
     */
    load(url: string, onLoad: Function, onProgress: Function, onError: Function): void;
    /**
     * Sets the draco loader instance for this gltf parser. Enable loading files with
     * [Draco](https://google.github.io/draco/) geometry extension. See Threejs
     * [DracoLoader](https://threejs.org/docs/index.html#examples/en/loaders/DRACOLoader) for more information.
     * Only works for GLTF 2.0 files.
     * @param {THREE.DracoLoader} dracoLoader - the threejs DracoLoader instance.
     */
    setDRACOLoader(dracoLoader: THREE.DracoLoader): void;
    /**
     * Sets the KTX2 loader instance for this gltf parser. Enable loading files with
     * [KTX2](https://www.khronos.org/ktx/) texture extension. See Threejs
     * [KTX2Loader](https://threejs.org/docs/index.html?q=KTX2#examples/en/loaders/KTX2Loader) for more information.
     * Only works for GLTF 2.0 files.
     * @param {THREE.KTX2Loader} ktx2Loader - the threejs KTX2Loader instance.
     */
    setKTX2Loader(ktx2Loader: THREE.KTX2Loader): void;
    /**
     * Sets the Mesh Optimizer decoder instance for this gltf parser. Enable loading files with
     * [MeshOptimizer](https://meshoptimizer.org/) geometry extension.
     * Only works for GLTF 2.0 files.
     * @param {object} meshoptDecoder - the threejs meshopt decoder instance.
     */
    setMeshoptDecoder(meshoptDecoder: object): void;
    /**
     * Registers a callback to load specific unknown or not standard GLTF extensions.
     * See Threejs [GltfLoader](https://threejs.org/docs/?q=gltflo#examples/en/loaders/GLTFLoader) for more
     * information.
     * @param {Function} callback - the callback function
     */
    register(callback: Function): void;
    /**
     * Unregisters a load callback.
     * See Threejs [GltfLoader](https://threejs.org/docs/?q=gltflo#examples/en/loaders/GLTFLoader) for more
     * information.
     * @param {Function} callback - the callback function
     */
    unregister(callback: Function): void;
    /**
     * Parse a glTF-based ArrayBuffer, JSON string or object and fire onLoad callback when complete.
     * Calls Threejs [GLTFLoader.parse](https://threejs.org/docs/?q=gltflo#examples/en/loaders/GLTFLoader.parse) for
     * glTF 2.0 files and LegacyGLTFLoader.parse for gtTF 1.0 files.
     * @param {ArrayBuffer | string | object} buffer - the glTF asset to parse, as an ArrayBuffer, JSON string or object.
     * @param {string} path - the base path from which to find subsequent glTF resources such as textures and .bin data files.
     * @param {Function} onLoad — A function to be called when parse completes. The argument to the onLoad function will
     * be an Object that contains loaded parts: .scene, .scenes, .cameras, .animations, and .asset.
     * @param {Function} [onError] — A function to be called if an error occurs during parsing. The function receives error as an argument.
     */
    parse(buffer: ArrayBuffer | string | object, path: string, onLoad: Function, onError?: Function): void;
    /**
     * Async promise-based parsing of a glTF-based ArrayBuffer, JSON string or object.
     * @param {ArrayBuffer | string | object} data - the glTF asset to parse, as an ArrayBuffer, JSON string or object.
     * @param {string} path - the base path from which to find subsequent glTF resources such as textures and .bin data files.
     * @returns {Promise<object>} A promise that resolves an Object that contains loaded parts:
     * .scene, .scenes, .cameras, .animations, and .asset, when parsing is done.
     */
    parseAsync(data: ArrayBuffer | string | object, path: string): Promise<object>;
}
import * as THREE from 'three';
import { GLTFLoader } from 'three/addons/loaders/GLTFLoader.js';
