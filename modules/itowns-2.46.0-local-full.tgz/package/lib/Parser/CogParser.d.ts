import type { TextureWithExtent } from '../Parser/GeotiffParser';
declare function parse(data: any, options: any): Promise<TextureWithExtent>;
declare const _default: {
    parse: typeof parse;
};
export default _default;
