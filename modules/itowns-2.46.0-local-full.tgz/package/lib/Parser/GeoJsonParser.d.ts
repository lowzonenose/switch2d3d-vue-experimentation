declare namespace _default {
    /**
     * Parse a GeoJSON file content and return a {@link FeatureCollection}.
     *
     * @param {string} json - The GeoJSON file content to parse.
     * @param {ParsingOptions} options - Options controlling the parsing.
     * @returns {Promise} A promise resolving with a {@link FeatureCollection}.
     */
    function parse(json: string, options?: ParsingOptions): Promise<any>;
}
export default _default;
