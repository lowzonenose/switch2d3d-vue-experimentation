declare namespace _default {
    /**
     * Parse a GPX file content and return a {@link FeatureCollection}.
     *
     * @param {XMLDocument} gpxFile - The GPX file content to parse.
     * @param {ParsingOptions} options - Options controlling the parsing.
     *
     * @returns {Promise} A promise resolving with a {@link FeatureCollection}.
     */
    function parse(gpxFile: XMLDocument, options: ParsingOptions): Promise<any>;
}
export default _default;
