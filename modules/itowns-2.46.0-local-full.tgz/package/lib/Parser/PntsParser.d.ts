declare namespace _default {
    function parse(buffer: ArrayBuffer, registeredExtensions: object): Promise<any>;
}
export default _default;
