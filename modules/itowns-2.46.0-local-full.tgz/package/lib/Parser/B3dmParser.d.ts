declare namespace _default {
    /**
     * Parse b3dm buffer and extract THREE.Scene and batch table
     * @param {ArrayBuffer} buffer - the b3dm buffer.
     * @param {object} options - additional properties.
     * @param {string=} [options.gltfUpAxis='Y'] - embedded glTF model up axis.
     * @param {string} options.urlBase - the base url of the b3dm file (used to fetch textures for the embedded glTF model).
     * @param {boolean=} [options.doNotPatchMaterial=false] - disable patching material with logarithmic depth buffer support.
     * @param {float} [options.opacity=1.0] - the b3dm opacity.
     * @param {boolean=} [options.frustumCulled=false] - enable frustum culling.
     * @param {boolean|Material=} [options.overrideMaterials=false] - override b3dm's embedded glTF materials. If
     * true, a threejs [MeshBasicMaterial](https://threejs.org/docs/index.html?q=meshbasic#api/en/materials/MeshBasicMaterial)
     * is set up. config.overrideMaterials can also be a threejs [Material](https://threejs.org/docs/index.html?q=material#api/en/materials/Material)
     * in which case it will be the material used to override.
     * @returns {Promise} - a promise that resolves with an object containig a THREE.Scene (gltf) and a batch table (batchTable).
     *
     */
    function parse(buffer: ArrayBuffer, options: {
        gltfUpAxis?: string | undefined;
        urlBase: string;
        doNotPatchMaterial?: boolean | undefined;
        opacity?: any;
        frustumCulled?: boolean | undefined;
        overrideMaterials?: (boolean | Material) | undefined;
    }): Promise<any>;
}
export default _default;
