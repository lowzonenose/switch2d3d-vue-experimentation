declare namespace _default {
    /**
     * @returns {Promise<void>}
     */
    function terminate(): Promise<void>;
    function parse(buffer: ArrayBuffer, options: object): Promise<any>;
}
export default _default;
