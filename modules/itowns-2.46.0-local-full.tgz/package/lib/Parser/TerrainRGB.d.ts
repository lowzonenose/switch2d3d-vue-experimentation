export function decodeTerrainRGB(data: any, index: any): number;
export function computeTerrainRGBMinMax(texture: any, pitch: any, zmin?: number, zmax?: number): {
    min: number;
    max: number;
};
