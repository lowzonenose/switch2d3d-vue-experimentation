export function getLookAtFromMath(view: any, camera: any): false | THREE.Vector3;
export function getRig(camera: any): any;
declare namespace _default {
    let defaultStopPlaceOnGroundAtEnd: boolean;
    let Easing: Readonly<{
        Linear: Readonly<{
            In: (amount: number) => number;
            Out: (amount: number) => number;
            InOut: (amount: number) => number;
        } & {
            None: (amount: number) => number;
        }>;
        Quadratic: Readonly<{
            In: (amount: number) => number;
            Out: (amount: number) => number;
            InOut: (amount: number) => number;
        }>;
        Cubic: Readonly<{
            In: (amount: number) => number;
            Out: (amount: number) => number;
            InOut: (amount: number) => number;
        }>;
        Quartic: Readonly<{
            In: (amount: number) => number;
            Out: (amount: number) => number;
            InOut: (amount: number) => number;
        }>;
        Quintic: Readonly<{
            In: (amount: number) => number;
            Out: (amount: number) => number;
            InOut: (amount: number) => number;
        }>;
        Sinusoidal: Readonly<{
            In: (amount: number) => number;
            Out: (amount: number) => number;
            InOut: (amount: number) => number;
        }>;
        Exponential: Readonly<{
            In: (amount: number) => number;
            Out: (amount: number) => number;
            InOut: (amount: number) => number;
        }>;
        Circular: Readonly<{
            In: (amount: number) => number;
            Out: (amount: number) => number;
            InOut: (amount: number) => number;
        }>;
        Elastic: Readonly<{
            In: (amount: number) => number;
            Out: (amount: number) => number;
            InOut: (amount: number) => number;
        }>;
        Back: Readonly<{
            In: (amount: number) => number;
            Out: (amount: number) => number;
            InOut: (amount: number) => number;
        }>;
        Bounce: Readonly<{
            In: (amount: number) => number;
            Out: (amount: number) => number;
            InOut: (amount: number) => number;
        }>;
        generatePow(power?: number): {
            In: (amount: number) => number;
            Out: (amount: number) => number;
            InOut: (amount: number) => number;
        };
    }>;
    /**
     * Stop camera's animation
     *
     * @param      {View}  view    The camera view
     * @param      {Camera}  camera  The camera to stop animation
     */
    function stop(view: View, camera: Camera): void;
    /**
     * Gets the current parameters transform camera looking at target.
     *
     * @param      {View}  view    The camera view
     * @param      {Camera}  camera  The camera to get transform
     * @param      {THREE.Vector3} [target] - The optional target
     * @returns     {CameraTransformOptions}  The transform camera looking at target
     */
    function getTransformCameraLookingAtTarget(view: View, camera: Camera, target?: THREE.Vector3): {
        /**
         * Camera look at geographic coordinate
         */
        coord?: Coordinate;
        /**
         * camera's tilt, in degree
         */
        tilt?: number | undefined;
        /**
         * camera's heading, in degree
         */
        heading?: number | undefined;
        /**
         * camera distance to target coordinate, in meter
         */
        range?: number | undefined;
        /**
         * duration of the animation, in ms
         */
        time?: number | undefined;
        /**
         * use proxy to handling camera's transformation. if proxy == true, other camera's transformation stops rig's transformation
         */
        proxy?: boolean | undefined;
        /**
         * in and out easing animation
         */
        easing?: number | undefined;
        /**
         * callback call each animation's frame (params are current cameraTransform and worldTargetPosition)
         */
        callback?: Function | undefined;
        /**
         * stop place target on the ground at animation ending
         */
        stopPlaceOnGroundAtEnd?: boolean | undefined;
    };
    /**
     * Apply transform to camera
     *
     * @param      {View}  view    The camera view
     * @param      {Camera}  camera  The camera to transform
     * @param      {CameraTransformOptions|Extent}  params  The parameters
     * @returns     {Promise} promise with resolve final CameraTransformOptions
     */
    function transformCameraToLookAtTarget(view: View, camera: Camera, params?: {
        /**
         * Camera look at geographic coordinate
         */
        coord?: Coordinate;
        /**
         * camera's tilt, in degree
         */
        tilt?: number | undefined;
        /**
         * camera's heading, in degree
         */
        heading?: number | undefined;
        /**
         * camera distance to target coordinate, in meter
         */
        range?: number | undefined;
        /**
         * duration of the animation, in ms
         */
        time?: number | undefined;
        /**
         * use proxy to handling camera's transformation. if proxy == true, other camera's transformation stops rig's transformation
         */
        proxy?: boolean | undefined;
        /**
         * in and out easing animation
         */
        easing?: number | undefined;
        /**
         * callback call each animation's frame (params are current cameraTransform and worldTargetPosition)
         */
        callback?: Function | undefined;
        /**
         * stop place target on the ground at animation ending
         */
        stopPlaceOnGroundAtEnd?: boolean | undefined;
    } | Extent): Promise<any>;
    /**
     * Compute the CameraTransformOptions that allow a given camera to display a given extent in its entirety.
     *
     * @param   {View}    view    The camera view
     * @param   {THREE.Camera}  camera  The camera to get the CameraTransformOptions from
     * @param   {Extent}  extent  The extent the camera must display
     *
     * @returns  {CameraTransformOptions}   The CameraTransformOptions allowing camera to display the extent.
     */
    function getCameraTransformOptionsFromExtent(view: View, camera: THREE.Camera, extent: Extent): {
        /**
         * Camera look at geographic coordinate
         */
        coord?: Coordinate;
        /**
         * camera's tilt, in degree
         */
        tilt?: number | undefined;
        /**
         * camera's heading, in degree
         */
        heading?: number | undefined;
        /**
         * camera distance to target coordinate, in meter
         */
        range?: number | undefined;
        /**
         * duration of the animation, in ms
         */
        time?: number | undefined;
        /**
         * use proxy to handling camera's transformation. if proxy == true, other camera's transformation stops rig's transformation
         */
        proxy?: boolean | undefined;
        /**
         * in and out easing animation
         */
        easing?: number | undefined;
        /**
         * callback call each animation's frame (params are current cameraTransform and worldTargetPosition)
         */
        callback?: Function | undefined;
        /**
         * stop place target on the ground at animation ending
         */
        stopPlaceOnGroundAtEnd?: boolean | undefined;
    };
    /**
     * Apply transform to camera with animation
     *
     * @param      {View}  view    The camera view
     * @param      {Camera}  camera  The camera to animate
     * @param      {CameraTransformOptions}  params  The parameters
     * @returns     {Promise} promise with resolve final CameraTransformOptions
     */
    function animateCameraToLookAtTarget(view: View, camera: Camera, params?: {
        /**
         * Camera look at geographic coordinate
         */
        coord?: Coordinate;
        /**
         * camera's tilt, in degree
         */
        tilt?: number | undefined;
        /**
         * camera's heading, in degree
         */
        heading?: number | undefined;
        /**
         * camera distance to target coordinate, in meter
         */
        range?: number | undefined;
        /**
         * duration of the animation, in ms
         */
        time?: number | undefined;
        /**
         * use proxy to handling camera's transformation. if proxy == true, other camera's transformation stops rig's transformation
         */
        proxy?: boolean | undefined;
        /**
         * in and out easing animation
         */
        easing?: number | undefined;
        /**
         * callback call each animation's frame (params are current cameraTransform and worldTargetPosition)
         */
        callback?: Function | undefined;
        /**
         * stop place target on the ground at animation ending
         */
        stopPlaceOnGroundAtEnd?: boolean | undefined;
    }): Promise<any>;
    /**
     * chain animation transform to camera
     *
     * @param      {View}  view    The camera view
     * @param      {Camera}  camera  The camera to animate
     * @param      {CameraTransformOptions[]}  params  array parameters, each parameters transforms are apply to camera, in serial
     * @returns     {Promise} promise with resolve final CameraTransformOptions
     */
    function sequenceAnimationsToLookAtTarget(view: View, camera: Camera, params?: {
        /**
         * Camera look at geographic coordinate
         */
        coord?: Coordinate;
        /**
         * camera's tilt, in degree
         */
        tilt?: number | undefined;
        /**
         * camera's heading, in degree
         */
        heading?: number | undefined;
        /**
         * camera distance to target coordinate, in meter
         */
        range?: number | undefined;
        /**
         * duration of the animation, in ms
         */
        time?: number | undefined;
        /**
         * use proxy to handling camera's transformation. if proxy == true, other camera's transformation stops rig's transformation
         */
        proxy?: boolean | undefined;
        /**
         * in and out easing animation
         */
        easing?: number | undefined;
        /**
         * callback call each animation's frame (params are current cameraTransform and worldTargetPosition)
         */
        callback?: Function | undefined;
        /**
         * stop place target on the ground at animation ending
         */
        stopPlaceOnGroundAtEnd?: boolean | undefined;
    }[]): Promise<any>;
    /**
     * Gets the difference camera transformation
     *
     * @param      {CameraTransformOptions}  first  param to compare with the second
     * @param      {CameraTransformOptions}  second param to compare with the first
     * @returns     {object} The difference parameters
     */
    function getDiffParams(first: {
        /**
         * Camera look at geographic coordinate
         */
        coord?: Coordinate;
        /**
         * camera's tilt, in degree
         */
        tilt?: number | undefined;
        /**
         * camera's heading, in degree
         */
        heading?: number | undefined;
        /**
         * camera distance to target coordinate, in meter
         */
        range?: number | undefined;
        /**
         * duration of the animation, in ms
         */
        time?: number | undefined;
        /**
         * use proxy to handling camera's transformation. if proxy == true, other camera's transformation stops rig's transformation
         */
        proxy?: boolean | undefined;
        /**
         * in and out easing animation
         */
        easing?: number | undefined;
        /**
         * callback call each animation's frame (params are current cameraTransform and worldTargetPosition)
         */
        callback?: Function | undefined;
        /**
         * stop place target on the ground at animation ending
         */
        stopPlaceOnGroundAtEnd?: boolean | undefined;
    }, second: {
        /**
         * Camera look at geographic coordinate
         */
        coord?: Coordinate;
        /**
         * camera's tilt, in degree
         */
        tilt?: number | undefined;
        /**
         * camera's heading, in degree
         */
        heading?: number | undefined;
        /**
         * camera distance to target coordinate, in meter
         */
        range?: number | undefined;
        /**
         * duration of the animation, in ms
         */
        time?: number | undefined;
        /**
         * use proxy to handling camera's transformation. if proxy == true, other camera's transformation stops rig's transformation
         */
        proxy?: boolean | undefined;
        /**
         * in and out easing animation
         */
        easing?: number | undefined;
        /**
         * callback call each animation's frame (params are current cameraTransform and worldTargetPosition)
         */
        callback?: Function | undefined;
        /**
         * stop place target on the ground at animation ending
         */
        stopPlaceOnGroundAtEnd?: boolean | undefined;
    }): object;
}
export default _default;
import * as THREE from 'three';
