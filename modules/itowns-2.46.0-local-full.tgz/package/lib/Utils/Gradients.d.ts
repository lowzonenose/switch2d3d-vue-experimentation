declare namespace _default {
    let SPECTRAL: (number | THREE.Color)[][];
    let PLASMA: (number | THREE.Color)[][];
    let YELLOW_GREEN: (number | THREE.Color)[][];
    let VIRIDIS: (number | THREE.Color)[][];
    let INFERNO: (number | THREE.Color)[][];
    let GRAYSCALE: (number | THREE.Color)[][];
    let TURBO: (number | THREE.Color)[][];
    let RAINBOW: (number | THREE.Color)[][];
    let CONTOUR: (number | THREE.Color)[][];
}
export default _default;
import * as THREE from 'three';
