/**
 * Removes a material and its textures, memory will be freed.
 * IMPORTANT NOTE: the material and the texture must not be referenced by other threejs objects, otherwise the memory
 * won't be freed.
 * @param {Material} material the material to remove
 */
export default function disposeThreeMaterial(material: Material): void;
/**
 * Merge groups of an object3D when it can to reduce number of them + remove unused materials
 * Reduce draw call https://threejs.org/docs/index.html?q=geometry#api/en/core/BufferGeometry.groups
 *
 * @param {THREE.Object3D} object3D - object to get optimize
 */
export function optimizeGeometryGroups(object3D: THREE.Object3D): void;
