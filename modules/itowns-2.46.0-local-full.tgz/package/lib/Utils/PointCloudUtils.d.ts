import type PointCloudNode from '../Core/PointCloudNode';
export declare function computeVisibilityTextureData(root: PointCloudNode, visibleNodes: PointCloudNode[]): {
    data: Uint8Array<ArrayBuffer>;
    nodeToIndex: Map<PointCloudNode, number>;
};
