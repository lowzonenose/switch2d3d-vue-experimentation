/**
 * Enable loading 3D Tiles with [Draco](https://google.github.io/draco/) geometry extension.
 *
 * @param {string} path path to draco library folder containing the JS and WASM decoder libraries. They can be found in
 * [itowns examples](https://github.com/iTowns/itowns/tree/master/examples/libs/draco).
 * @param {object} [config] optional configuration for Draco decoder (see threejs'
 * [setDecoderConfig](https://threejs.org/docs/index.html?q=draco#examples/en/loaders/DRACOLoader.setDecoderConfig) that
 * is called under the hood with this configuration for details.
 */
export function enableDracoLoader(path: string, config?: object): void;
/**
 * Enable loading 3D Tiles with [KTX2](https://www.khronos.org/ktx/) texture extension.
 *
 * @param {string} path path to ktx2 library folder containing the JS and WASM decoder libraries. They can be found in
 * [itowns examples](https://github.com/iTowns/itowns/tree/master/examples/libs/basis).
 * @param {THREE.WebGLRenderer} renderer the threejs renderer
 */
export function enableKtx2Loader(path: string, renderer: THREE.WebGLRenderer): void;
/**
 * Enable loading 3D Tiles and GLTF with
 * [meshopt](https://github.com/KhronosGroup/glTF/blob/main/extensions/2.0/Vendor/EXT_meshopt_compression/README.md) compression extension.
 *
 * @param {MeshOptDecoder.constructor} MeshOptDecoder - The Meshopt decoder
 * module.
 *
 * @example
 * import * as itowns from 'itowns';
 * import { MeshoptDecoder } from 'three/addons/libs/meshopt_decoder.module.js';
 *
 * // Enable support of EXT_meshopt_compression
 * itowns.enableMeshoptDecoder(MeshoptDecoder);
 */
export function enableMeshoptDecoder(MeshOptDecoder: MeshOptDecoder.constructor): void;
export const itownsGLTFLoader: iGLTFLoader;
export namespace OGC3DTILES_LAYER_EVENTS {
    let LOAD_TILE_SET: object;
    let LOAD_MODEL: object;
    let DISPOSE_MODEL: object;
    let TILE_VISIBILITY_CHANGE: object;
    let TILES_LOAD_START: string;
    let TILES_LOAD_END: string;
}
export default OGC3DTilesLayer;
import * as THREE from 'three';
import iGLTFLoader from '../Parser/iGLTFLoader';
declare class OGC3DTilesLayer extends GeometryLayer {
    /**
     * Layer for [3D Tiles](https://www.ogc.org/standard/3dtiles/) datasets.
     *
     * Advanced configuration note: 3D Tiles rendering is delegated to 3DTilesRendererJS that exposes several
     * configuration options accessible through the tilesRenderer property of this class. see the
     * [3DTilesRendererJS doc](https://github.com/NASA-AMMOS/3DTilesRendererJS/blob/master/README.md). Also note that
     * the cache is shared amongst 3D tiles layers and can be configured through tilesRenderer.lruCache (see the
     * [following documentation](https://github.com/NASA-AMMOS/3DTilesRendererJS/blob/master/README.md#lrucache-1).
     * The cache max byte size is configured to 1GB, but it can also be configured with tilesRenderer.lruCache.maxBytesSize.
     *
     * @extends Layer
     *
     * @param {string} id - unique layer id.
     * @param {object} config - layer specific configuration
     * @param {OGC3DTilesSource} config.source - data source configuration
     * @param {string} [config.pntsMode = PNTS_MODE.COLOR] Point cloud coloring mode (passed to {@link PointsMaterial}).
     *      Only 'COLOR' or 'CLASSIFICATION' are possible. COLOR uses RGB colors of the points,
     *      CLASSIFICATION uses a classification property of the batch table to color points.
     * @param {ClassificationScheme}  [config.classificationScheme = ClassificationScheme.DEFAULT]  {@link PointsMaterial} classification scheme
     * @param {string} [config.pntsShape = PNTS_SHAPE.CIRCLE] Point cloud point shape. Only 'CIRCLE' or 'SQUARE' are possible.
     * (passed to {@link PointsMaterial}).
     * @param {string} [config.pntsSizeMode = PNTS_SIZE_MODE.VALUE] {@link PointsMaterial} Point cloud size mode (passed to {@link PointsMaterial}).
     * Only 'VALUE' or 'ATTENUATED' or 'ADAPTIVE' are possible. VALUE use constant size, ATTENUATED compute size depending on distance
     * from point to camera and ADAPTIVE computes the point size on a per-point basis rather than on a per-node basis.
     * **Warning:** ADAPTIVE work only if point cloud is an octree
     * @param {number} [config.pntsMinAttenuatedSize = 3] Minimum scale used by 'ATTENUATED' size mode.
     * @param {number} [config.pntsMaxAttenuatedSize = 10] Maximum scale used by 'ATTENUATED' size mode.
     */
    constructor(id: string, config: {
        source: OGC3DTilesSource;
        pntsMode?: string | undefined;
        classificationScheme?: {
            DEFAULT: {
                0: {
                    visible: boolean;
                    name: string;
                    color: THREE.Color;
                    opacity: number;
                };
                1: {
                    visible: boolean;
                    name: string;
                    color: THREE.Color;
                    opacity: number;
                };
                2: {
                    visible: boolean;
                    name: string;
                    color: THREE.Color;
                    opacity: number;
                };
                3: {
                    visible: boolean;
                    name: string;
                    color: THREE.Color;
                    opacity: number;
                };
                4: {
                    visible: boolean;
                    name: string;
                    color: THREE.Color;
                    opacity: number;
                };
                5: {
                    visible: boolean;
                    name: string;
                    color: THREE.Color;
                    opacity: number;
                };
                6: {
                    visible: boolean;
                    name: string;
                    color: THREE.Color;
                    opacity: number;
                };
                7: {
                    visible: boolean;
                    name: string;
                    color: THREE.Color;
                    opacity: number;
                };
                8: {
                    visible: boolean;
                    name: string;
                    color: THREE.Color;
                    opacity: number;
                };
                9: {
                    visible: boolean;
                    name: string;
                    color: THREE.Color;
                    opacity: number;
                };
                10: {
                    visible: boolean;
                    name: string;
                    color: THREE.Color;
                    opacity: number;
                };
                11: {
                    visible: boolean;
                    name: string;
                    color: THREE.Color;
                    opacity: number;
                };
                12: {
                    visible: boolean;
                    name: string;
                    color: THREE.Color;
                    opacity: number;
                };
                DEFAULT: {
                    visible: boolean;
                    name: string;
                    color: THREE.Color;
                    opacity: number;
                };
            };
        } | undefined;
        pntsShape?: string | undefined;
        pntsSizeMode?: string | undefined;
        pntsMinAttenuatedSize?: number | undefined;
        pntsMaxAttenuatedSize?: number | undefined;
    });
    isOGC3DTilesLayer: boolean;
    pntsMode: string | number;
    pntsShape: string | number;
    classification: any;
    pntsSizeMode: string | number;
    pntsMinAttenuatedSize: number;
    pntsMaxAttenuatedSize: number;
    /** @type {any} */
    tilesRenderer: any;
    _res: any;
    /**
     * @type {number}
     */
    sseThreshold: number;
    /**
     * Binds 3d-tiles-renderer events to this layer.
     * @private
     */
    private _setupEvents;
    /**
     * Setup 3D tiles renderer js TilesRenderer with the camera, binds events and start updating. Executed when the
     * layer has been added to the view.
     * @param {View} view - the view the layer has been added to.
     * @private
     */
    private _setup;
    /**
     * Replace materials from GLTFLoader by our own custom materials. Note that
     * the replaced materials are not compiled yet and will be disposed by the
     * GC.
     * @param {Object3D} model
     * @private
     */
    private _assignFinalMaterial;
    /**
     * @param {Object3D} model
     * @private
     */
    private _assignFinalAttributes;
    preUpdate(context: any): null;
    scale: any;
    update(): void;
    /**
     * Deletes the layer and frees associated memory
     */
    delete(): void;
    /**
     * Get the [metadata](https://github.com/CesiumGS/3d-tiles/tree/main/specification/Metadata)
     * of the closest intersected object from a list of intersections.
     *
     * This method retrieves structured metadata stored in GLTF 2.0 assets using
     * the [`EXT_structural_metadata`](https://github.com/CesiumGS/glTF/tree/3d-tiles-next/extensions/2.0/Vendor/EXT_structural_metadata)
     * extension.
     *
     * Internally, it uses the closest intersected point to index metadata
     * stored in property attributes and textures.
     *
     * If present in GLTF 2.0 assets, this method leverages the
     * [`EXT_mesh_features`](`https://github.com/CesiumGS/glTF/tree/3d-tiles-next/extensions/2.0/Vendor/EXT_mesh_features)
     * extension and the returned featured to index metadata stored in property tables.
     *
     * @param {Array<THREE.Intersection>} intersections
     * @returns {Promise<object | null>} - the intersected object's metadata
     */
    getMetadataFromIntersections(intersections: Array<THREE.Intersection>): Promise<object | null>;
    /**
     * Get the attributes for the closest intersection from a list of
     * intersects.
     * @param {Array<THREE.Intersection>} intersects -  An array containing all
     * objects picked under mouse coordinates computed with view.pickObjectsAt(..).
     * @returns {object | null} - An object containing
     */
    getC3DTileFeatureFromIntersectsArray(intersects: Array<THREE.Intersection>): object | null;
    /**
     * Get all 3D objects (mesh and points primitives) as intersects at the
     * given non-normalized screen coordinates.
     * @param {View} view - The view instance.
     * @param {THREE.Vector2} coords - The coordinates to pick in the view. It
     * should have at least `x` and `y` properties.
     * @param {number} radius - Radius of the picking circle.
     * @param {Array} [target=[]] - Target array to push results too
     * @returns {Array} Array containing all target objects picked under the
     * specified coordinates.
     */
    pickObjectsAt(view: View, coords: THREE.Vector2, radius: number, target?: any[]): any[];
    attach(layer: any): void;
    detach(layer: any): boolean;
    getObjectToUpdateForAttachedLayers(obj: any): null;
    /**
     * Executes a callback for each tile of this layer tileset.
     *
     * @param {Function} callback The callback to execute for each tile. Has the following two parameters:
     *  1. tile (Object) - the JSON tile
     *  2. scene (THREE.Object3D | null) - The tile content. Contains a `batchTable` property. Can be null if the tile
     *  has not yet been loaded.
     */
    forEachTile(callback: Function): void;
}
import GeometryLayer from '../Layer/GeometryLayer';
