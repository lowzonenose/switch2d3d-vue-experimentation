export function moveLayerToIndex(layer: any, newIndex: any, imageryLayers: any): void;
export function moveLayerDown(layer: any, imageryLayers: any): void;
export function moveLayerUp(layer: any, imageryLayers: any): void;
export function getColorLayersIdOrderedBySequence(imageryLayers: any): any[];
