import * as THREE from 'three';
import GeometryLayer from './GeometryLayer';
interface UpdateContext {
    camera: {
        camera3D: THREE.PerspectiveCamera | THREE.OrthographicCamera;
    };
    view: {
        renderer: THREE.WebGLRenderer;
        scene: THREE.Scene;
        date: Date;
        altitude: number;
    };
}
/**
 * Manages directional lighting and shadows as a layer.
 * Updates the sun light position and shadow camera parameters
 * based on the current camera view and sun direction.
 */
declare class SunLightLayer extends GeometryLayer {
    sunLight: THREE.DirectionalLight;
    sunDirection: THREE.Vector3;
    isSunLightLayer: boolean;
    forceDaytime: boolean;
    shadowsMaxAltitude: number;
    sunTiltAltitude: number;
    private _prevSunIntensity;
    private readonly _up;
    private readonly _worldRef;
    private readonly _tangent;
    private readonly _newSunDirection;
    /**
     * @param [forceDaytime=false] - Indicates whether to force daytime lighting regardless of the scene's time.
     * @param [shadowsMaxAltitude=30000] - Specifies the maximum altitude at which shadows are cast.
     * @param [sunTiltAltitude=30000] - Specifies the maximum altitude at which the sun tilts when forceDaytime is true
     * @returns
     */
    constructor(forceDaytime?: boolean, shadowsMaxAltitude?: number, sunTiltAltitude?: number);
    preUpdate(): this[];
    /**
     * Updates the sun light position and its target to shine on what the
     * camera sees. Dynamically adjusts the shadow box size to minimize
     * flickering while covering the visible area.
     * @param context - The update context.
     */
    update(context: UpdateContext): void;
    _dayTimeSunDirection(cameraPosition: THREE.Vector3, altitude: number, sunDirection: THREE.Vector3): void;
}
export default SunLightLayer;
