export default ElevationLayer;
/**
 * @property {boolean} isElevationLayer - Used to checkout whether this layer is
 * an ElevationLayer. Default is true. You should not change this, as it is used
 * internally for optimisation.
 * @property {number} noDataValue - Used to specify a **null** or **no data value** in the elevation terrain.
 * @property {number} [zmin] - Used to specify a minimum value for the elevation terrain (if the data goes lower, it will be clamped).
 * @property {number} [zmax] - Used to specify a maximum value for the elevation terrain (if the data goes higher, it will be clamped)
 * @property {number} scale - Used to apply a scale on the elevation value. It
 * can be used for exageration of the elevation, like in [this
 * example](https://www.itowns-project.org/itowns/examples/#plugins_pyramidal_tiff).
 * @property {boolean} useColorTextureElevation - the elevation is computed with one color texture channel,
 * `this.colorTextureElevationMaxZ` and `this.colorTextureElevationMinZ`.
 *
 * The formula is:
 *
 * ```js
 * elevation = color.r * (this.colorTextureElevationMaxZ - this.colorTextureElevationMinZ) + this.colorTextureElevationMinZ
 * ```
 * @property {number} colorTextureElevationMinZ - elevation minimum in `useColorTextureElevation` mode.
 * @property {number} colorTextureElevationMaxZ - elevation maximum in `useColorTextureElevation` mode.
 * @property {boolean} useRgbaTextureElevation - Decode lossless RGB textures using the Mapbox Terrain-RGB encoding:
 * `-10000 + (R * 65536 + G * 256 + B) * 0.1` meters, where each channel is an 8-bit value.
 * This is not an IEEE 754 float encoding. Use PNG rather than JPEG to preserve channel values.
 * The elevation bounds are computed from the texture; `clampValues` also limits the bounds before it loads.
 * The `noDataValue` option is not supported in this mode.
 *
 * @extends RasterLayer
 */
declare class ElevationLayer extends RasterLayer {
    /**
     * A simple layer, managing an elevation texture to add some reliefs on the
     * plane or globe view for example.
     *
     * @param {string} id - The id of the layer, that should be unique. It is
     * not mandatory, but an error will be emitted if this layer is added a
     * {@link View} that already has a layer going by that id.
     * @param {object} [config] - Optional configuration, all elements in it
     * will be merged as is in the layer. For example, if the configuration
     * contains three elements `name, protocol, extent`, these elements will be
     * available using `layer.name` or something else depending on the property
     * name.
     * @param {number} [config.noDataValue]   The value coding the noData in the data set
     * @param {object} [config.clampValues] - Optional information for clamping
     * the elevation between a minimum and a maximum value
     * @param {number} [config.clampValues.min]   The minimum value to clamp the elevation
     * @param {number} [config.clampValues.max]   The maximum value to clamp the elevation
     *
     * @example
     * // Create an ElevationLayer
     * const elevation = new ElevationLayer('IGN_MNT', {
     *      source: new WMTSSource({
     *          "url": "https://data.geopf.fr/wmts?",
     *           "crs": "EPSG:4326",
     *           "format": "image/x-bil;bits=32",
     *           "name": "ELEVATION.ELEVATIONGRIDCOVERAGE",
     *      }),
     * });
     *
     * // Add the layer
     * view.addLayer(elevation);
     */
    constructor(id: string, config?: {
        noDataValue?: number | undefined;
        clampValues?: {
            min?: number | undefined;
            max?: number | undefined;
        } | undefined;
    });
    /**
     * @type {boolean}
     * @readonly
     */
    readonly isElevationLayer: boolean;
    noDataValue: number | undefined;
    /**
     * @type {number | undefined}
     */
    zmin: number | undefined;
    /**
     * @type {number | undefined}
     */
    zmax: number | undefined;
    useRgbaTextureElevation: any;
    useColorTextureElevation: any;
    colorTextureElevationMinZ: any;
    colorTextureElevationMaxZ: any;
    bias: any;
    mode: any;
    rasterTile: typeof RasterElevationTile;
    /**
     * Setup RasterElevationTile added to TileMesh. This RasterElevationTile handles
     * the elevation texture to displace TileMesh vertices.
     *
     * @param      {TileMesh}  node    The node to apply new RasterElevationTile;
     * @returns     {RasterElevationTile}  The raster elevation node added.
     */
    addRasterTile(node: TileMesh): RasterElevationTile;
    getRasterTileParent(node: any): any;
    onNodeCreated(node: any): void;
}
import RasterLayer from '../Layer/RasterLayer';
import { RasterElevationTile } from '../Renderer/RasterTile';
