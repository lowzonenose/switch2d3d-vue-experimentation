import PointCloudLayer, { PointCloudLayerParameters } from '../Layer/PointCloudLayer';
import type PotreeSource from '../Source/PotreeSource';
interface PotreeLayerParameters extends PointCloudLayerParameters {
    source: PotreeSource;
}
declare class PotreeLayer extends PointCloudLayer<PotreeSource> {
    /**
     * Used to checkout whether this layer is a PotreeLayer. Default is `true`.
     * You should not change this, as it is used internally for optimisation.
     */
    readonly isPotreeLayer: true;
    /**
     * Constructs a new instance of Potree layer.
     *
     * @example
     * ```js
     * // Create a new point cloud layer
     * const points = new PotreeLayer('points', {
     *     source: new PotreeSource({
     *         url: 'https://pointsClouds/',
     *         file: 'points.js',
     *     })
     * });
     *
     * View.prototype.addLayer.call(view, points);
     * ```
     *
     * @param id - The id of the layer, that should be unique. It is
     * not mandatory, but an error will be emitted if this layer is added a
     * View that already has a layer going by that id.
     * @param config - Configuration, all elements in it
     * will be merged as is in the layer. For example, if the configuration
     * contains three elements `name, protocol, extent`, these elements will be
     * available using `layer.name` or something else depending on the property
     * name. See the list of properties to know which one can be specified.
     */
    constructor(id: string, config: PotreeLayerParameters);
}
export default PotreeLayer;
