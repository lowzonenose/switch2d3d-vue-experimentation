export default LabelLayer;
/**
 * A layer to handle a bunch of `Label`. This layer can be created on its own,
 * but it is better to use the option `addLabelLayer` on another `Layer` to let
 * it work with it (see the `vector_tile_raster_2d` example). Supported for Points features, not yet
 * for Lines and Polygons features.
 *
 * @property {boolean} isLabelLayer - Used to checkout whether this layer is a
 * LabelLayer.  Default is true. You should not change this, as it is used
 * internally for optimisation.
 */
declare class LabelLayer extends GeometryLayer {
    /**
     * @extends Layer
     *
     * @param {string} id - The id of the layer, that should be unique. It is
     * not mandatory, but an error will be emitted if this layer is added a
     * {@link View} that already has a layer going by that id.
     * @param {object} [config] - Optional configuration, all elements in it
     * will be merged as is in the layer. For example, if the configuration
     * contains three elements `name, protocol, extent`, these elements will be
     * available using `layer.name` or something else depending on the property
     * name.
     * @param {boolean} [config.performance=true] - remove labels that have no chance of being visible.
     * if the `config.performance` is set to true then the performance is improved
     * proportional to the amount of unnecessary labels that are removed.
     * Indeed, even in the best case, labels will never be displayed. By example, if there's many labels.
     * We advise you to not use this option if your data is optimized.
     * @param {HTMLElement|Function} config.domElement - An HTML domElement.
     * If set, all `Label` displayed within the current instance `LabelLayer`
     * will be this domElement.
     *
     * It can be set to a method. The single parameter of this method gives the
     * properties of each feature on which a `Label` is created.
     *
     * If set, all the parameters set in the `LabelLayer` `Style.text` will be overridden,
     * except for the `Style.text.anchor` parameter which can help place the label.
     */
    constructor(id: string, config?: {
        performance?: boolean | undefined;
        domElement: HTMLElement | Function;
    });
    isLabelLayer: boolean;
    style: Style;
    domElement: DomNode;
    buildExtent: boolean;
    performance: boolean;
    forceClampToTerrain: any;
    margin: any;
    toHide: THREE.Group<THREE.Object3DEventMap>;
    labelDomelement: Function | HTMLElement;
    get submittedLabelNodes(): any;
    /**
     * Reads each {@link FeatureGeometry} that contains label configuration, and
     * creates the corresponding {@link Label}. To create a `Label`, a geometry
     * needs to have a `label` object with at least a few properties:
     * - `content`, which refers to `Label#content`
     * - `position`, which refers to `Label#position`
     * - (optional) `config`, containing miscellaneous configuration for the
     *   label
     *
     * The geometry (or its parent Feature) needs to have a Style set.
     *
     * @param {FeatureCollection} data - The FeatureCollection to read the
     * labels from.
     * @param {Extent|Tile} extentOrTile
     *
     * @returns {Label[]} An array containing all the created labels.
     */
    convert(data: FeatureCollection, extentOrTile: Extent | Tile): Label[];
    preUpdate(context: any, sources: any): void;
    update(context: any, layer: any, node: any): any;
    removeLabelsFromNodeRecursive(node: any): void;
    removeNodeDomElement(node: any): void;
    #private;
}
import GeometryLayer from '../Layer/GeometryLayer';
import Style from '../Core/Style';
/**
 * DomNode is a node in the tree data structure of labels divs.
 *
 * @class DomNode
 */
declare class DomNode {
    dom: HTMLDivElement;
    set visible(v: boolean);
    get visible(): boolean;
    hide(): void;
    show(): void;
    add(node: any): void;
    #private;
}
import * as THREE from 'three';
import { Extent } from '@itowns/geographic';
import Label from '../Core/Label';
