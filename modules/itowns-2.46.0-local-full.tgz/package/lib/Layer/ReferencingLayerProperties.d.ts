/**
 * Patches castShadow and receiveShadow on a THREE.Object3D so that they
 * combine the layer value with a local per-object value:
 *   getter returns `layer.<prop> && localValue`
 *   setter stores the local value
 *
 * @param {THREE.Object3D} object3d - The object to patch
 * @param {GeometryLayer} layer - The layer whose shadow properties are combined
 */
export function referShadowProperties(object3d: THREE.Object3D, layer: GeometryLayer): void;
export default ReferLayerProperties;
declare function ReferLayerProperties(material: any, layer: any): any;
