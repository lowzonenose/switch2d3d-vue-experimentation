import * as THREE from 'three';
import GeometryLayer from '../Layer/GeometryLayer';
import type PointCloudNode from '../Core/PointCloudNode';
export interface PointCloudSource {
    /** The minimal value for elevation (read from the metadata). */
    zmin: number;
    /** The maximal value for elevation (read from the metadata). */
    zmax: number;
}
export interface PointCloudLayerParameters {
    /**
     * Description and options of the source.
     * @see {@link Layer}.
     */
    source: PointCloudSource;
    object3d?: THREE.Group;
    group?: THREE.Group;
    octreeDepthLimit?: number;
    pointBudget?: number;
    pointSize?: number;
    sseThreshold?: number;
    /**
     * The minimal intensity of the layer. Changing this value will affect the
     * material, if it has the corresponding uniform. The value is normalized
     * between 0 and 1.
     */
    minIntensityRange?: number;
    /**
     * The maximal intensity of the layer. Changing this value will affect the
     * material, if it has the corresponding uniform. The value is normalized
     * between 0 and 1.
     */
    maxIntensityRange?: number;
    /**
     * Min value for the elevation range (default value taken from the
     * source.metadata).
     */
    minElevationRange?: number;
    /**
     * Max value for the elevation range (default value taken from the
     * source.metadata).
     */
    maxElevationRange?: number;
    minAngleRange?: number;
    maxAngleRange?: number;
    material?: THREE.Material;
    /**
     * The displaying mode of the points. Values are specified in
     * `PointsMaterial`.
     */
    mode?: number;
}
interface Context {
    camera: {
        camera3D: THREE.PerspectiveCamera;
        preSSE: number;
        width: number;
        height: number;
        isBox3Visible: (bbox: THREE.Box3, matrixWorld: THREE.Matrix4) => boolean;
    };
    scheduler: {
        execute: (command: {
            layer: PointCloudLayer;
            requester: PointCloudNode;
            view: object;
            priority: number;
            redraw: boolean;
            earlyDropFunction?: (cmd: {
                requester: PointCloudNode;
            }) => boolean;
        }) => Promise<THREE.Points>;
    };
    view: {
        notifyChange: (elt: PointCloudLayer) => void;
    };
}
declare abstract class PointCloudLayer<S extends PointCloudSource = PointCloudSource> extends GeometryLayer {
    /**
     * Read-only flag to assert that a given object is of type PointCloudLayer.
     * Used internally for optimisation.
     */
    readonly isPointCloudLayer: true;
    /** Used internally for scheduling tasks. */
    readonly protocol: 'pointcloud';
    source: S;
    /**
     * Container group for the points.
     * Add this to the three.js scene in order to render it.
     */
    readonly group: THREE.Group;
    /**
     * Container group for the oriented points bounding boxes.
     * Add this to the three.js scene in order to render it.
     */
    readonly obbes: THREE.Group;
    /**
     * Maximum depth to which points will be loaded and rendered.
     * Setting it to 1 will only render the root node.
     * Default to `Infinity`.
     */
    octreeDepthLimit: number;
    /**
     * Maximum number of points to display at the same time.
     * Defaults to 2 millions points.
     */
    pointBudget: number;
    /**
     * Size of the points (in pixels) rendered on the screen.
     * In attenuated point size mode, this value is used as basis for the
     * attenuation.
     * Defaults to 2 pixels.
     */
    pointSize: number;
    /**
     * Screen space error (in pixels) to target when updating the geometry.
     * Points below this threshold will not rendered.
     * Defaults to 2 pixels.
     */
    sseThreshold: number;
    /** Minimal intensity value of the layer. */
    minIntensityRange: number;
    /** Maximal intensity value of the layer. */
    maxIntensityRange: number;
    /** Minimal elevation value of the layer. */
    minElevationRange: number;
    /** Maximal elevation value of the layer. */
    maxElevationRange: number;
    /** Minimal angle value of the layer. */
    minAngleRange: number;
    /** Maximal angle value of the layer. */
    maxAngleRange: number;
    /** Number of points displayed in the last update. */
    displayedCount: number;
    /** Root node of the point cloud tree. */
    root: PointCloudNode | undefined;
    /**
     * The material to use to display the points of the cloud.
     * Be default it is a new `PointsMaterial`.
     */
    material: THREE.PointsMaterial;
    private _candidateNodes;
    private _visibleNodes;
    private _visibilityTextureNeedsUpdate;
    private _visibilityTextureData;
    /**
     * Constructs a new instance of point cloud layer.
     * Constructs a new instance of a Point Cloud Layer. This should not be used
     * directly, but rather implemented using `extends`.
     *
     * @param id - The id of the layer, that should be unique. It is
     * not mandatory, but an error will be emitted if this layer is added a
     * {@link View} that already has a layer going by that id.
     * @param config - Optional configuration, all elements in it
     * will be merged as is in the layer. For example, if the configuration
     * contains three elements `name, protocol, extent`, these elements will be
     * available using `layer.name` or something else depending on the property
     * name. See the list of properties to know which one can be specified.
     */
    constructor(id: string, config: PointCloudLayerParameters);
    setElevationRange(): void;
    setNodeVisible(node: PointCloudNode, visible: boolean): void;
    preUpdate(context: Context): (PointCloudNode | undefined)[];
    /**
     * Load the data of a node.
     * Send a promise to get the data (if not already sent)
     * and add the result to the node when resolve.
     * Check the visiblility of children to see if the need to be updated
     * as well.
     *
     * @param elt - The element (node) to load data.
     * @param context - The context.
     * @param layer - The layer on wich the node is attach.
     *
     * @returns The child nodes to update or [].
     */
    loadData(elt: PointCloudNode, context: Context, layer: this): void;
    /**
     * Check if the node need to be rendered. In that case it call the
     * node.loadData() on it.
     *
     * @param context - The context.
     * @param layer - The layer on wich the node is attach.
     * @param root - The element (node) to render.
     *
     * @returns The child nodes to update or [] if there is none.
     */
    update(context: Context, layer: this, root: PointCloudNode): PointCloudNode[];
    postUpdate(): void;
    pickObjectsAt(view: any, mouse: any, radius: any, target?: never[]): any[] | undefined;
    getObjectToUpdateForAttachedLayers(meta: any): {
        elements: any[];
        parent: any;
    } | {
        elements: any[];
        parent?: undefined;
    } | undefined;
}
export default PointCloudLayer;
