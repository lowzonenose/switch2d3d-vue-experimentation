export default VpcLayer;
/**
 * A layer for [Virtual Point Clouds](https://github.com/PDAL/wrench/blob/main/vpc-spec.md) (VPC) datasets.
 * See {@link PointCloudLayer} class for documentation on base properties.
 *
 * @extends {PointCloudLayer}
 *
 * @property {boolean} isVpcLayer - Used to checkout whether this layer
 * is a VpcLayer. Default is `true`. You should not change this, as it is
 * used internally for optimisation.
 *
 *
 *
 * @example
 * // Create a new VPC layer
 * const vpcSource = new VpcSource({
 *     url: 'https://data.geopf.fr/chunk/telechargement/download/lidarhd_fxx_ept/vpc/index.vpc',
 * });
 *
 * const vpcLayer = new VpcLayer('VPC', {
 *     source: vpcSource,
 * });
 *
 * View.prototype.addLayer.call(view, vpcLayer);
 */
declare class VpcLayer extends PointCloudLayer<import("../Layer/PointCloudLayer").PointCloudSource> {
    /**
     * @param {string} id - Unique id of the layer.
     * @param {object} config - See {@link PointCloudLayer} for base pointcloud
     * options.
     */
    constructor(id: string, config: object);
    /**
     * @type {boolean}
     * @readonly
     */
    readonly isVpcLayer: boolean;
    scale: THREE.Vector3;
    offset: THREE.Vector3;
    loadData(elt: any, context: any, layer: any): void;
}
import PointCloudLayer from '../Layer/PointCloudLayer';
import * as THREE from 'three';
