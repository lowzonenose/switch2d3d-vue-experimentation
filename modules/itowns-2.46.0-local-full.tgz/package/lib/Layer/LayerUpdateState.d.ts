declare const UPDATE_STATE: {
    readonly IDLE: 0;
    readonly PENDING: 1;
    readonly ERROR: 2;
    readonly DEFINITIVE_ERROR: 3;
    readonly FINISHED: 4;
};
export type UpdateState = (typeof UPDATE_STATE)[keyof typeof UPDATE_STATE];
/**
 * LayerUpdateState is the update state of a layer, for a given object
 * (e.g. tile).
 * It stores information to allow smart update decisions, and especially
 * network error handling.
 */
declare class LayerUpdateState {
    errorCount: number;
    failureParams: {
        lowestLevelError: number;
    };
    private state;
    private lastErrorTimestamp;
    constructor();
    /**
     * Checks if the update has finished successfully.
     * @returns
     */
    hasFinished(): boolean;
    /**
     * Checks if an update can be attempted based on the current update state.
     *
     * @param timestamp - Current timestamp in milliseconds (defaults to
     * Date.now()).
     * @returns
     */
    canTryUpdate(timestamp?: number): boolean;
    /**
     * Gives the number of seconds to wait before the next retry attempt.
     * @returns
     */
    secondsUntilNextTry(): number;
    /**
     * Marks the beginning of a new update attempt.
     */
    newTry(): void;
    /**
     * Marks the update as successful. It resets the error tracking.
     */
    success(): void;
    /**
     * Marks the update as permanently finished, preventing further update
     * attempts.
     */
    noMoreUpdatePossible(): void;
    /**
     * Handles the case where no data is available for the requested level.
     * Updates the lowest level error tracking for future retry attempts.
     *
     * @param failureParams - The current context of the failure (this includes
     * the current updated level).
     * @param failureParams.targetLevel - The level where no data was available
     */
    noData(failureParams: {
        targetLevel: number;
    }): void;
    /**
     * Handles update failures. An error is either definitive or retryable (up
     * to four attempts).
     *
     * @param timestamp - The timestamp when the failure occurred.
     * @param definitive - Whether this error stops the update process.
     * @param failureParams - The current context of the failure (this includes
     * the current updated level).
     * @param failureParams.targetLevel - The level where the error occurred
     */
    failure(timestamp: number, definitive: boolean, failureParams: {
        targetLevel: number;
    }): void;
    /**
     * Checks if the layer is currently in an error state.
     * @returns
     */
    inError(): boolean;
}
export default LayerUpdateState;
