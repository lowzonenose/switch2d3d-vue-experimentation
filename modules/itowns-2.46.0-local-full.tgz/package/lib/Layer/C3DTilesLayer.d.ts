export namespace C3DTILES_LAYER_EVENTS {
    let ON_TILE_CONTENT_LOADED: object;
    let ON_TILE_REQUESTED: object;
}
export default C3DTilesLayer;
/**
 * @extends GeometryLayer
 */
declare class C3DTilesLayer extends GeometryLayer {
    /**
     * @deprecated Deprecated 3D Tiles layer. Use {@link OGC3DTilesLayer} instead.
     *
     * @example
     * // Create a new 3d-tiles layer from a web server
     * const l3dt = new C3DTilesLayer('3dtiles', {
     *      name: '3dtl',
     *      source: new C3DTilesSource({
     *           url: 'https://tileset.json'
     *      })
     * }, view);
     * View.prototype.addLayer.call(view, l3dt);
     *
     * // Create a new 3d-tiles layer from a Cesium ion server
     * const l3dt = new C3DTilesLayer('3dtiles', {
     *      name: '3dtl',
     *      source: new C3DTilesIonSource({
     *              accessToken: 'myAccessToken',
                    assetId: 12
     *      })
     * }, view);
     * View.prototype.addLayer.call(view, l3dt);
     *
     * @param      {string}  id - The id of the layer, that should be unique.
     *     It is not mandatory, but an error will be emitted if this layer is
     *     added a
     * {@link View} that already has a layer going by that id.
     * @param      {object}  config   configuration, all elements in it
     * will be merged as is in the layer.
     * @param {C3DTilesSource} config.source The source of 3d Tiles.
     *
     * name.
     * @param {number} [config.sseThreshold=16] The [Screen Space Error](https://github.com/CesiumGS/3d-tiles/blob/main/specification/README.md#geometric-error)
     * threshold at which child nodes of the current node will be loaded and added to the scene.
     * @param {number} [config.cleanupDelay=1000] The time (in ms) after which a tile content (and its children) are
     * removed from the scene.
     * @param {C3DTExtensions} [config.registeredExtensions] 3D Tiles extensions managers registered for this tileset.
     * @param {string} [config.pntsMode= PNTS_MODE.COLOR] {@link PointsMaterial} Point cloud coloring mode.
     *      Only 'COLOR' or 'CLASSIFICATION' are possible. COLOR uses RGB colors of the points,
     *      CLASSIFICATION uses a classification property of the batch table to color points.
     * @param {string} [config.pntsShape= PNTS_SHAPE.CIRCLE] Point cloud point shape. Only 'CIRCLE' or 'SQUARE' are possible.
     * @param {string} [config.pntsSizeMode= PNTS_SIZE_MODE.VALUE] {@link PointsMaterial} Point cloud size mode.
     * Only 'VALUE' or 'ATTENUATED' or 'ADAPTIVE' are possible. VALUE use constant size, ATTENUATED compute size depending on distance
     * from point to camera and ADAPTIVE computes the point size on a per-point basis rather than on a per-node basis.
     * **Warning:** ADAPTIVE work only if point cloud is an octree
     * @param {number} [config.pntsMinAttenuatedSize=3] Minimum scale used by 'ATTENUATED' size mode
     * @param {number} [config.pntsMaxAttenuatedSize=10] Maximum scale used by 'ATTENUATED' size mode
     * @param {Style} [config.style=null] - style used for this layer
     * @param  {View}  view  The view
     */
    constructor(id: string, config: {
        source: C3DTilesSource;
        sseThreshold?: number | undefined;
        cleanupDelay?: number | undefined;
        registeredExtensions?: C3DTExtensions | undefined;
        pntsMode?: string | undefined;
        pntsShape?: string | undefined;
        pntsSizeMode?: string | undefined;
        pntsMinAttenuatedSize?: number | undefined;
        pntsMaxAttenuatedSize?: number | undefined;
        style?: Style | undefined;
    }, view: View);
    isC3DTilesLayer: boolean;
    sseThreshold: number;
    cleanupDelay: number;
    protocol: string;
    name: any;
    registeredExtensions: C3DTExtensions;
    pntsMode: string | number;
    pntsShape: string | number;
    classification: any;
    pntsSizeMode: string | number;
    pntsMinAttenuatedSize: number;
    pntsMaxAttenuatedSize: number;
    /** @type {Style | null} */
    _style: Style | null;
    /**
     * Map all C3DTFeature of the layer according their tileId and their batchId
     * Map< tileId, Map< batchId, C3DTFeature>>
     *
     * @type {Map<number, Map<number,C3DTFeature>>}
     */
    tilesC3DTileFeatures: Map<number, Map<number, C3DTFeature>>;
    overrideMaterials: any;
    _cleanableTiles: any[];
    tileset: C3DTileset;
    preUpdate(context: any): any[];
    update(context: any, layer: any, node: any): any;
    getObjectToUpdateForAttachedLayers(meta: any): {
        elements: any[];
        parent: any;
    } | {
        elements: any[];
        parent?: undefined;
    } | undefined;
    /**
     * Get the closest c3DTileFeature of an intersects array.
     * @param {Array} intersects - An array containing all
     * targets picked under specified coordinates. Intersects can be
     * computed with view.pickObjectsAt(..). See fillHTMLWithPickingInfo()
     * in 3dTilesHelper.js for an example.
     *
     * @returns {C3DTileFeature} - the closest C3DTileFeature of the intersects array
     */
    getC3DTileFeatureFromIntersectsArray(intersects: any[]): C3DTileFeature;
    /**
     * Called when a tile content is loaded
     * @param {THREE.Object3D} tileContent - tile as THREE.Object3D
     */
    onTileContentLoaded(tileContent: THREE.Object3D): void;
    /**
     * Initialize C3DTileFeatures from tileContent
     * @param {THREE.Object3D} tileContent - tile as THREE.Object3D
     */
    initC3DTileFeatures(tileContent: THREE.Object3D): void;
    /**
     * Update style of the C3DTFeatures, an allowList of tile id can be passed to only update certain tile.
     * Note that this function only update THREE.Object3D materials, in order to see style changes you should call view.notifyChange()
     * @param {Array<number>|null} [allowTileIdList] - tile ids to allow in updateStyle computation if null all tiles are updated
     *
     * @returns {boolean} true if style updated false otherwise
     */
    updateStyle(allowTileIdList?: Array<number> | null): boolean;
    get materialCount(): number;
    set style(value: Style | null);
    get style(): Style | null;
    #private;
}
import GeometryLayer from '../Layer/GeometryLayer';
import C3DTExtensions from '../Core/3DTiles/C3DTExtensions';
import Style from '../Core/Style';
import C3DTFeature from '../Core/3DTiles/C3DTFeature';
import C3DTileset from '../Core/3DTiles/C3DTileset';
import * as THREE from 'three';
