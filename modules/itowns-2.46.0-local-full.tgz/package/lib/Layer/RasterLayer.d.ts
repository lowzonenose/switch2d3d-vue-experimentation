export default RasterLayer;
declare class RasterLayer extends Layer {
    constructor(id: any, config: any);
    visible: boolean;
    minFilter: any;
    magFilter: any;
    updateStrategy: any;
    convert(data: any, extentDestination: any): any;
    hasData(node: any): any;
    /**
     * Updates raster data for a node if the layer is active and data is available.
     * Creates or recreates the raster tile when needed, then triggers loading.
     *
     * @param {object} context - Update context.
     * @param {View} context.view - Active view used to schedule loading.
     * @param {RasterLayer} layer - Current raster layer.
     * @param {TileMesh} node - Tile node to update.
     * @returns {Promise<void>|undefined} A loading promise when an update is scheduled.
     */
    update(context: {
        view: View;
    }, layer: RasterLayer, node: TileMesh): Promise<void> | undefined;
    addRasterTile(node: any): any;
    removeRasterTile(node: any): void;
    onNodeCreated(): void;
}
import Layer from '../Layer/Layer';
