import PointCloudLayer, { type PointCloudLayerParameters } from '../Layer/PointCloudLayer';
import type Potree2Source from '../Source/Potree2Source';
interface Potree2LayerParameters extends PointCloudLayerParameters {
    source: Potree2Source;
}
declare class Potree2Layer extends PointCloudLayer<Potree2Source> {
    /**
     * Used to checkout whether this layer is a Potree2Layer.
     * Default is `true`. You should not change this, as it is used internally
     * for optimisation.
     */
    readonly isPotree2Layer: true;
    metadata?: unknown;
    /**
     * Constructs a new instance of Potree2 layer.
     *
     * @example
     * ```js
     * // Create a new point cloud layer
     * const points = new Potree2Layer('points', {
     *     source: new Potree2Source({
     *         url: 'https://pointsClouds/',
     *         file: 'metadata.json',
     *     })
     * });
     *
     * View.prototype.addLayer.call(view, points);
     * ```
     *
     * @param id - The id of the layer, that should be unique. It is
     * not mandatory, but an error will be emitted if this layer is added a
     * View that already has a layer going by that id.
     * @param config - Configuration, all elements in it
     * will be merged as is in the layer. For example, if the configuration
     * contains three elements `name, protocol, extent`, these elements will be
     * available using `layer.name` or something else depending on the property
     * name. See the list of properties to know which one can be specified.
     */
    constructor(id: string, config: Potree2LayerParameters);
}
export default Potree2Layer;
