import { type RasterTile } from '../Renderer/RasterTile';
/**
 * This modules implements various layer update strategies.
 *
 * Default strategy is STRATEGY_MIN_NETWORK_TRAFFIC which aims
 * to reduce the amount of network traffic.
 */
export declare const STRATEGY_MIN_NETWORK_TRAFFIC = 0;
export declare const STRATEGY_GROUP = 1;
export declare const STRATEGY_PROGRESSIVE = 2;
export declare const STRATEGY_DICHOTOMY = 3;
export type LayerUpdateStrategy = StrategyMinNetworkTraffic | StrategyGroup | StrategyProgressive | StrategyDichotomy;
interface StrategyMinNetworkTraffic {
    type: typeof STRATEGY_MIN_NETWORK_TRAFFIC;
}
interface StrategyGroup {
    type: typeof STRATEGY_GROUP;
    options: {
        groups: number[];
    };
}
interface StrategyProgressive {
    type: typeof STRATEGY_PROGRESSIVE;
    options: {
        increment?: number;
    };
}
interface StrategyDichotomy {
    type: typeof STRATEGY_DICHOTOMY;
}
export declare function chooseNextLevelToFetch(strategy: LayerUpdateStrategy, nodeLevel: number, currentLevel: number, failureParams: {
    lowestLevelError: number;
}, zoom?: {
    min: number;
    max: number;
}): number;
export declare const nextLevelToFetch: (t: RasterTile) => number;
export {};
