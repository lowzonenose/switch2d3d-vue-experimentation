export default VRControls;
/**
 * @property {Array} controllers - WebXR controllers list
 */
declare class VRControls {
    static MIN_DELTA_ALTITUDE: number;
    static MAX_NUMBER_CONTROLLERS: number;
    static init(view: any, vrHeadSet: any): VRControls;
    /**
     * Requires a contextXR variable.
     * @param {*} _view itowns view object
     * @param {*} _groupXR XR 3D object group
     */
    constructor(_view: any, _groupXR?: any);
    view: any;
    groupXR: any;
    webXRManager: any;
    rightButtonPressed: boolean;
    controllers: any[];
    initControllers(): void;
    bindGripController(controllerModelFactory: any, gripController: any, vrHeadSet: any): void;
    setupEventListeners(controller: any): void;
    listenGamepad(): void;
    clampAndApplyTransformationToXR(trans: any, offsetRotation: any): void;
    applyTransformationToXR(trans: any, offsetRotation: any): void;
    /**
     * Clamp the given translation vector so that the camera remains at or above ground level.
     * @param {THREE.Vector3} trans - The translation vector.
     * @returns {THREE.Vector3} The clamped coordinates as a Vector3.
     */
    clampToGround(trans: THREE.Vector3): THREE.Vector3;
    getSpeedFactor(): number;
    getRotationYaw(axisValue: any): any;
    getRotationPitch(axisValue: any): any;
    getTranslationElevation(axisValue: any, speedFactor: any): any;
    cameraOnFly(ctrl: any): void;
    onSelectRightEnd(): void;
    onSelectRightStart(): void;
    onSelectLeftStart(): void;
    onSelectLeftEnd(): void;
    onSelectStart(data: any): void;
    onSelectEnd(data: any): void;
    onButtonPressed(data: any): void;
    onRightButtonPressed(data: any): void;
    onLeftButtonPressed(): void;
    onAxisChanged(data: any): void;
    onRightAxisChanged(ctrl: any): void;
    onLeftAxisChanged(ctrl: any): void;
    onAxisStop(data: any): void;
    onRightAxisStop(): void;
    onLeftAxisStop(): void;
    onButtonReleased(data: any): void;
    onRightButtonReleased(): void;
    onLeftButtonReleased(): void;
}
import * as THREE from 'three';
