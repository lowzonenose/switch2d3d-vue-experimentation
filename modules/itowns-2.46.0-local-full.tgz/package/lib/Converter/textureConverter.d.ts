declare namespace _default {
    function convert(data: any, destinationTile: any, layer: any): any;
}
export default _default;
