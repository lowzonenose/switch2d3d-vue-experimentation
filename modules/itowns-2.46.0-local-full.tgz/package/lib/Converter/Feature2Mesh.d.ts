/**
 * Rebuild the geometry of each child mesh in a {@link FeatureMesh} using the
 * current layer style. Disposes the old geometry before replacing the mesh.
 * @param {FeatureMesh} featureMesh - the feature mesh whose children to rebuild
 * @param {Style} layerStyle - the layer style to use for the rebuild
 */
export function rebuildMeshTopology(featureMesh: FeatureMesh, layerStyle: Style): void;
/**
 * Updates the visual properties of a single feature mesh from the current
 * module-level style. Only the geometry buffers affected by `parameter` are
 * marked as needing an update.
 *
 * @param {THREE.Mesh} featureMesh - The mesh to update.
 * @param {THREE.Group} collection - The collection providing matrix/world context.
 * @param {Style} styleIn - The style to apply.
 * @param {string[]} buffersToUpdate - Buffer names to update (e.g. ['color', 'position']).
 */
export function applyStyle(featureMesh: THREE.Mesh, collection: THREE.Group, styleIn: Style, buffersToUpdate?: string[]): void;
declare namespace _default {
    /**
     * Return a function that converts [Features]{@link module:GeoJsonParser} to Meshes. Feature collection will be converted to a
     * a THREE.Group.
     *
     * @param {object} options - options controlling the conversion
     * @param {Function} [options.batchId] - optional function to create batchId attribute.
     * It is passed the feature property and the feature index. As the batchId is using an unsigned int structure on 32 bits,
     * the batchId could be between 0 and 4,294,967,295.
     * @param {StyleOptions} [options.style] - optional style properties. Only needed if the convert is used without instancing
     * a layer beforehand.
     * @returns {Function}
     * @example <caption>Example usage of batchId with featureId.</caption>
     * view.addLayer({
     *     id: 'WFS Buildings',
     *     type: 'geometry',
     *     update: itowns.FeatureProcessing.update,
     *     convert: itowns.Feature2Mesh.convert({
     *         batchId: (property, featureId) => featureId,
     *     }),
     *     filter: acceptFeature,
     *     source,
     * });
     *
     * @example <caption>Example usage of batchId with property.</caption>
     * view.addLayer({
     *     id: 'WFS Buildings',
     *     type: 'geometry',
     *     update: itowns.FeatureProcessing.update,
     *     convert: itowns.Feature2Mesh.convert({
     *         batchId: (property, featureId) => property.house ? 10 : featureId,
     *         }),
     *     filter: acceptFeature,
     *     source,
     * });
     */
    function convert(options?: {
        batchId?: Function | undefined;
        style?: any;
    }): Function;
}
export default _default;
declare class FeatureMesh extends THREE.Group<THREE.Object3DEventMap> {
    constructor(meshes: any, collection: any);
    meshes: THREE.Group<THREE.Object3DEventMap>;
    extent: any;
    isFeatureMesh: boolean;
    get collection(): THREE.Group<THREE.Object3DEventMap>;
    as(crs: any): this;
    #private;
}
import Style from '../Core/Style';
import * as THREE from 'three';
