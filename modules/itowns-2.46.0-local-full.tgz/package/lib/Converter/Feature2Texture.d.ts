declare namespace _default {
    function createTextureFromFeature(collection: any, extent: any, zoom: any, sizeTexture: any, layerStyle: any, backgroundColor: any): THREE.Texture<unknown>;
}
export default _default;
import * as THREE from 'three';
