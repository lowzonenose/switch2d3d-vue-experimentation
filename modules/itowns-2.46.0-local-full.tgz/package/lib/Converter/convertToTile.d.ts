import TileMesh, { TileLayerLike } from '../Core/TileMesh';
import type { Extent } from '@itowns/geographic';
declare const _default: {
    convert(requester: TileMesh, extent: Extent, layer: TileLayerLike): TileMesh;
};
export default _default;
