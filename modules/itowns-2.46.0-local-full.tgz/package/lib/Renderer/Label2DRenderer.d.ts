export class ScreenGrid {
    constructor(x: number | undefined, y: number | undefined, width: any, height: any);
    x: number;
    y: number;
    grid: any[];
    visible: any[];
    width: any;
    height: any;
    reset(): void;
    resize(): void;
    insert(obj: any): boolean;
}
export default Label2DRenderer;
/**
 * This renderer is inspired by the
 * [`THREE.CSS2DRenderer`](https://threejs.org/docs/#examples/en/renderers/CSS2DRenderer).
 * It is instantiated in `c3DEngine`, as another renderer to handles Labels.
 */
declare class Label2DRenderer {
    domElement: HTMLDivElement;
    garbage: HTMLDivElement;
    halfWidth: number;
    halfHeight: number;
    grid: ScreenGrid;
    infoTileLayer: any;
    setSize(width: any, height: any): void;
    registerLayer(layer: any): void;
    render(scene: any, camera: any): void;
    culling(label: any, camera: any, tileLayer: any): void;
    removeLabelDOM(label: any): void;
}
