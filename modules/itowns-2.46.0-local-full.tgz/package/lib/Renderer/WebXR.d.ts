export namespace VR_EVENTS {
    let CONTROLS_INITIALIZED: string;
}
export default WebXR;
/**
 * @property {VRControls} vrControls - WebXR controllers handler
 */
declare class WebXR extends THREE.EventDispatcher<any> {
    /**
     * Handler of a webXR session
     *
     *
     * @param {GlobeView} view - The view where the webXR session will be started
     * @param {object} [options] - WebXR configuration - its presence alone
     * enable WebXR to switch on VR visualization.
     * @param {Function} [options.callback] - WebXR rendering callback.
     * @param {boolean} [options.controllers] - Enable the webXR controllers handling.
     */
    constructor(view: GlobeView, options?: {
        callback?: Function | undefined;
        controllers?: boolean | undefined;
    });
    view: GlobeView;
    options: {
        callback?: Function | undefined;
        controllers?: boolean | undefined;
    } | undefined;
    renderCb: Function | undefined;
    vrControls: VRControls | null;
    initializeWebXR: () => void;
}
import * as THREE from 'three';
import VRControls from '../Controls/VRControls';
