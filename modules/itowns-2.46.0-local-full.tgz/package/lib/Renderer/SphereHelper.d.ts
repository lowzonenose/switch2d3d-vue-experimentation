export default SphereHelper;
declare function SphereHelper(radius: any): void;
declare class SphereHelper {
    constructor(radius: any);
    geometry: THREE.SphereGeometry;
    material: THREE.MeshBasicMaterial;
    update(radius: any): void;
}
import * as THREE from 'three';
