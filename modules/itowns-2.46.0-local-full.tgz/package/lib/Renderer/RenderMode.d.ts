import * as THREE from 'three';
declare const MODES: {
    FINAL: number;
    DEPTH: number;
    ID: number;
};
type RenderMode = typeof MODES[keyof typeof MODES];
/**
 * @privateRemarks
 * Look at the use of CommonMaterial in PointsMaterial to see why this interface
 * workaround is required: we're currently dynamically adding properties to
 * materials as aliases to the uniform values.
 */
export interface ModalObject extends THREE.Object3D {
    mode: RenderMode;
    material: THREE.Material & {
        mode: RenderMode;
    };
}
/**
 * Sets the rendering mode of all the `objects` and their children to `mode`,
 * runs the `callback`, reverts the rendering mode and returns the result.
 * @param objects
 * @param mode
 * @param callback
 * @returns
 */
declare function scope<T>(objects: ModalObject[], mode: RenderMode, callback: (objects: ModalObject[]) => T): T;
declare const _default: {
    MODES: {
        FINAL: number;
        DEPTH: number;
        ID: number;
    };
    scope: typeof scope;
};
export default _default;
