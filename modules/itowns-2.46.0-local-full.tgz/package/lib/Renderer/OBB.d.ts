import * as THREE from 'three';
import type { Extent, ProjectionLike } from '@itowns/geographic';
/**
 * Represents an oriented bounding box.
 */
declare class OBB extends THREE.Object3D {
    box3D: THREE.Box3;
    natBox: THREE.Box3;
    z: {
        min: number;
        max: number;
        scale: number;
        delta: number;
    };
    private _center;
    matrixWorldInverse: THREE.Matrix4;
    /**
     * @param min - (optional) A {@link THREE.Vector3} representing the lower
     * (x, y, z) boundary of the box.
     * Default is ( + Infinity, + Infinity, + Infinity ).
     * @param max - (optional) A {@link THREE.Vector3} representing the upper
     * (x, y, z) boundary of the box.
     * Default is ( - Infinity, - Infinity, - Infinity ).
     */
    constructor(min?: THREE.Vector3, max?: THREE.Vector3);
    get center(): THREE.Vector3;
    updateMatrixWorld(force?: boolean): void;
    /**
     * Copies the property from cOBB to this OBB.
     *
     * @param cOBB - OBB to copy
     * @returns
     */
    copy(cOBB: OBB): this;
    /**
     * Updates the z min, z max and z scale of oriented bounding box.
     *
     * @param elevation - Elevation parameters
     * @param elevation.min - The minimum elevation
     * @param elevation.max - The maximum elevation
     * @param elevation.scale - The scale of the elevation
     * @param elevation.geoidHeight - The geoid height
     */
    updateZ(elevation?: {
        min?: number;
        max?: number;
        scale?: number;
        geoidHeight?: number;
    }): void;
    /**
     * Determines if the sphere is above the XY space of the box.
     *
     * @param sphere - The sphere
     * @returns true if the sphere is above the XY space of the box, false
     * otherwise.
     */
    isSphereAboveXYBox(sphere: THREE.Sphere): boolean;
    /**
     * Computes the OBB from an extent.
     * The OBB resulted can be only in the system 'EPSG:3946'.
     *
     * @param extent - The extent (with crs 'EPSG:4326') to compute oriented
     * bounding box
     * @param minHeight - The minimum height of OBB
     * @param maxHeight - The maximum height of OBB
     * @returns return this object
     */
    setFromExtent(extent: Extent, minHeight?: number, maxHeight?: number): this;
    setFromBox3(box3: THREE.Box3): this;
    setFromArray(array: number[]): this;
    /**
     * Project the OBB in a specified crs.
     * The OBB new position will be the initial OBB center
     * projected at z=0 in the initial crs.
     * It doesn't modified the initial value of the OBB (this.natBox)
     *
     * @param crsIn - The initial crs (at the creation of the OBB)
     * @param crsOut - The crs in which we want the obb to be projected
     */
    projOBB(crsIn: ProjectionLike, crsOut: ProjectionLike): void;
    /**
     * Clamped the OBB natBox on the z axes.
     * /!\ If the box3 and the values don't intersect
     * the initial box is kept.
     *
     * @param zmin - The min z value for clamping.
     * @param zmax - the max z value for clamping.
     *
     * @returns The new OBB clamped on z.
     */
    clampZ(zmin: number, zmax: number): this;
}
export default OBB;
