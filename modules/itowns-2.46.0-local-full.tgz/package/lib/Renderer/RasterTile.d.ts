export const EMPTY_TEXTURE_ZOOM: -1;
/**
 * A `RasterTile` is part of raster {@link Layer} data.
 * This part is a spatial subdivision of the extent of a layer.
 * In the `RasterTile`, The data are converted on three.js textures.
 * This `RasterTile` textures are assigned to a `LayeredMaterial`.
 * This material is applied on terrain (TileMesh).
 * The color textures are mapped to color the terrain.
 * The elevation textures are used to displace vertex terrain.
 *
 * @class RasterTile
 */
export class RasterTile extends THREE.EventDispatcher<any> {
    constructor(layer: any, tiles: any);
    layer: any;
    crs: any;
    textures: any[];
    tiles: any;
    offsetScales: any[];
    level: number;
    needsUpdate: boolean;
    state: LayerUpdateState;
    lowestLevelError: number;
    _handlerCBEvent: () => void;
    get id(): any;
    get opacity(): any;
    get visible(): any;
    get maxLevel(): any;
    load(requester: any, view: any): any;
    hasData(): boolean;
    getZoomDelta(): number;
    initFromParent(parent: any): void;
    sortBestParentTextures(textures: any): any;
    disposeRedrawnTextures(newTextures: any): void;
    dispose(removeEvent?: boolean): void;
    _listeners: {} | undefined;
    disposeAtIndexes(indexes: any): void;
    setTexture(index: any, texture: any, offsetScale: any): any;
    setTextures(textures: any): void;
    shouldWriteTextureAtIndex(index: any, texture: any): any;
}
export class RasterColorTile extends RasterTile {
    get effect_type(): any;
    get effect_parameter(): any;
    get transparent(): any;
}
export class RasterElevationTile extends RasterTile {
    isRasterElevationTile: boolean;
    scaleFactor: number;
    set min(value: any);
    get min(): any;
    set max(value: any);
    get max(): any;
    bias: any;
    mode: any;
    zmin: any;
    zmax: any;
    _min: any;
    _max: any;
    terrainRGBBound(value: any): number;
    get scale(): number;
    dispose(removeEvent: any): void;
    updateMinMaxElevation(): void;
    replaceNoDataValueFromTexture(texture: any): void;
}
import * as THREE from 'three';
import LayerUpdateState from '../Layer/LayerUpdateState';
