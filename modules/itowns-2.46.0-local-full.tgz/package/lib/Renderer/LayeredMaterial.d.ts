import * as THREE from 'three';
import RenderMode from '../Renderer/RenderMode';
import { RasterTile, RasterElevationTile, RasterColorTile } from './RasterTile';
import { RenderTargetCache } from './RenderTargetCache';
export declare function unpack1K(color: THREE.Vector4Like, factor: number): number;
export declare function getMaxColorSamplerUnitsCount(): number;
export declare const colorLayerEffects: {
    readonly noEffect: 0;
    readonly removeLightColor: 1;
    readonly removeWhiteColor: 2;
    readonly customEffect: 3;
};
/** GPU struct for color layers */
interface StructColorLayer {
    textureOffset: number;
    crs: number;
    opacity: number;
    effect_parameter: number;
    effect_type: number;
    transparent: boolean;
}
/** GPU struct for elevation layers */
interface StructElevationLayer {
    scale: number;
    bias: number;
    mode: number;
    zmin: number;
    zmax: number;
}
export declare const ELEVATION_MODES: {
    readonly RGBA: 0;
    readonly COLOR: 1;
    readonly DATA: 2;
};
/**
 * Convenience type that wraps all of the generic type's fields in
 * [THREE.IUniform]s.
 */
type MappedUniforms<Uniforms> = {
    [name in keyof Uniforms]: THREE.IUniform<Uniforms[name]>;
};
/** List of the uniform types required for a LayeredMaterial. */
interface LayeredMaterialRawUniforms {
    diffuse: THREE.Color;
    opacity: number;
    lightingEnabled: boolean;
    lightPosition: THREE.Vector3;
    fogNear: number;
    fogFar: number;
    fogColor: THREE.Color;
    fogDensity: number;
    overlayAlpha: number;
    overlayColor: THREE.Color;
    objectId: number;
    geoidHeight: number;
    minBorderDistance: number;
    showOutline: boolean;
    outlineWidth: number;
    outlineColors: THREE.Color[];
    elevationLayers: StructElevationLayer[];
    elevationTextures: THREE.DataArrayTexture | null;
    elevationOffsetScales: THREE.Vector4[];
    elevationTextureCount: number;
    colorLayers: StructColorLayer[];
    colorTextures: THREE.DataArrayTexture | null;
    colorOffsetScales: THREE.Vector4[];
    colorTextureCount: number;
}
/** Replacing the default uniforms dynamic type with our own static map. */
export interface LayeredMaterialParameters extends THREE.ShaderMaterialParameters {
    uniforms?: MappedUniforms<LayeredMaterialRawUniforms>;
}
type DefineMapping<Prefix extends string, Mapping extends Record<string, unknown>> = {
    [Name in Extract<keyof Mapping, string> as `${Prefix}_${Name}`]: Mapping[Name];
};
type ElevationModeDefines = DefineMapping<'ELEVATION', typeof ELEVATION_MODES>;
type RenderModeDefines = DefineMapping<'MODE', typeof RenderMode.MODES>;
type LayeredMaterialDefines = {
    NUM_VS_TEXTURES: number;
    NUM_FS_TEXTURES: number;
    NUM_CRS: number;
    DEBUG: number;
    MODE: number;
} & ElevationModeDefines & RenderModeDefines;
/** Material that handles the overlap of multiple raster tiles. */
export declare class LayeredMaterial extends THREE.ShaderMaterial {
    private _visible;
    colorTiles: RasterColorTile[];
    elevationTiles: RasterElevationTile[];
    colorTileIds: string[];
    elevationTileId: string | undefined;
    layersNeedUpdate: boolean;
    renderTargetCache: RenderTargetCache | undefined;
    defines: LayeredMaterialDefines;
    constructor(options: LayeredMaterialParameters | undefined, crsCount: number);
    get mode(): number;
    set mode(mode: number);
    getUniform<Name extends keyof LayeredMaterialRawUniforms>(name: Name): LayeredMaterialRawUniforms[Name] | undefined;
    setUniform<Name extends keyof LayeredMaterialRawUniforms, Value extends LayeredMaterialRawUniforms[Name]>(name: Name, value: Value): void;
    initUniforms(uniforms: {
        [Name in keyof LayeredMaterialRawUniforms]?: LayeredMaterialRawUniforms[Name];
    }): void;
    setUniforms(uniforms: {
        [Name in keyof LayeredMaterialRawUniforms]?: LayeredMaterialRawUniforms[Name];
    }): void;
    getLayerUniforms<Type extends 'color' | 'elevation'>(type: Type): MappedUniforms<{
        layers: (Type extends 'color' ? StructColorLayer : StructElevationLayer)[];
        textures: THREE.Texture[];
        offsetScales: THREE.Vector4[];
        textureCount: number;
    }>;
    /**
     * Updates uniforms for both color and elevation layers.
     * Orchestrates the processing of visible color layers and elevation tiles.
     *
     * @param renderer - The renderer used to render textures into arrays.
     */
    updateLayersUniforms(renderer: THREE.WebGLRenderer): void;
    /**
     * Track usage of current render targets for deferred disposal.
     * Should be called every time this material is rendered.
     */
    markAsRendered(): void;
    dispose(): void;
    setColorTileIds(ids: string[]): void;
    removeTile(tileId: string): void;
    addRasterTile(rasterTile: RasterTile): void;
    getCurrentElevationTile(): RasterElevationTile | undefined;
    updateElevations(): void;
    getTile(id: string): RasterTile | undefined;
    getAllTiles(): (RasterColorTile | RasterElevationTile)[];
    getTiles(ids: string[]): RasterTile[];
}
export {};
