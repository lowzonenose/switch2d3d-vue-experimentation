export namespace PNTS_MODE {
    let COLOR: number;
    let INTENSITY: number;
    let CLASSIFICATION: number;
    let ELEVATION: number;
    let RETURN_NUMBER: number;
    let RETURN_TYPE: number;
    let RETURN_COUNT: number;
    let POINT_SOURCE_ID: number;
    let SCAN_ANGLE: number;
    let NORMAL: number;
}
export namespace PNTS_SHAPE {
    let CIRCLE: number;
    let SQUARE: number;
}
export namespace PNTS_SIZE_MODE {
    let VALUE: number;
    let ATTENUATED: number;
    let ADAPTIVE: number;
}
export namespace ClassificationScheme {
    let DEFAULT: {
        0: {
            visible: boolean;
            name: string;
            color: THREE.Color;
            opacity: number;
        };
        1: {
            visible: boolean;
            name: string;
            color: THREE.Color;
            opacity: number;
        };
        2: {
            visible: boolean;
            name: string;
            color: THREE.Color;
            opacity: number;
        };
        3: {
            visible: boolean;
            name: string;
            color: THREE.Color;
            opacity: number;
        };
        4: {
            visible: boolean;
            name: string;
            color: THREE.Color;
            opacity: number;
        };
        5: {
            visible: boolean;
            name: string;
            color: THREE.Color;
            opacity: number;
        };
        6: {
            visible: boolean;
            name: string;
            color: THREE.Color;
            opacity: number;
        };
        7: {
            visible: boolean;
            name: string;
            color: THREE.Color;
            opacity: number;
        };
        8: {
            visible: boolean;
            name: string;
            color: THREE.Color;
            opacity: number;
        };
        9: {
            visible: boolean;
            name: string;
            color: THREE.Color;
            opacity: number;
        };
        10: {
            visible: boolean;
            name: string;
            color: THREE.Color;
            opacity: number;
        };
        11: {
            visible: boolean;
            name: string;
            color: THREE.Color;
            opacity: number;
        };
        12: {
            visible: boolean;
            name: string;
            color: THREE.Color;
            opacity: number;
        };
        DEFAULT: {
            visible: boolean;
            name: string;
            color: THREE.Color;
            opacity: number;
        };
    };
}
export default PointsMaterial;
/**
 * Every lidar point can have a classification assigned to it that defines
 * the type of object that has reflected the laser pulse. Lidar points can be
 * classified into a number of categories including bare earth or ground,
 * top of canopy, and water. The different classes are defined using numeric
 * integer codes in the files.
 */
export type Classification = {
    /**
     * - category visibility,
     */
    visible: boolean;
    /**
     * - category name,
     */
    name: string;
    /**
     * - category color,
     */
    color: THREE.Color;
    /**
     * - category opacity,
     */
    opacity: number;
};
import * as THREE from 'three';
declare class PointsMaterial extends THREE.ShaderMaterial {
    /**
     * @class      PointsMaterial
     * @param      {object}  [options={}]  The options
     * @param      {number}  [options.size=1] point size
     * @param      {number}  [options.mode=PNTS_MODE.COLOR]  display mode.
     * @param      {number}  [options.shape=PNTS_SHAPE.CIRCLE]  rendered points shape.
     * @param      {THREE.Vector4}  [options.overlayColor=new THREE.Vector4(0, 0, 0, 0)]  overlay color.
     * @param      {Scheme}  [options.classificationScheme]  LUT for point classification colorization.
     * @param      {Scheme}  [options.discreteScheme]  LUT for other discret point values colorization.
     * @param      {string}  [options.gradient]  Descrition of the gradient to use for continuous point values.
     *                          (Default value will be the 'SPECTRAL' gradient from Utils/Gradients)
     * @param      {number}  [options.sizeMode=PNTS_SIZE_MODE.VALUE]  point cloud size mode. Only 'VALUE' or 'ATTENUATED' or 'ADAPTIVE' are possible.
     * VALUE use constant size, ATTENUATED compute size depending on distance from point to camera and ADAPTIVE computes the point size on a per-point basis rather than on a per-node basis.
     * **Warning:** ADAPTIVE work only if point cloud is an octree
     * @param      {number}  [options.minAttenuatedSize=3]  minimum scale used by 'ATTENUATED' size mode
     * @param      {number}  [options.maxAttenuatedSize=10]  maximum scale used by 'ATTENUATED' size mode
     *
     * @property {object} options - options for the PointsMaterial.
     * @property {THREE.Vector2}  [options.intensityRange=new THREE.Vector2(1, 65536)]  intensity range (default value will be [1, 65536] if not defined at Layer level).
     * @property {THREE.Vector2}  [options.elevationRange=new THREE.Vector2(0, 1000)]  elevation range (default value will be [0, 1000] if not defined at Layer level).
     * @property {THREE.Vector2}  [options.angleRange=new THREE.Vector2(-90, 90)]  scan angle range (default value will be [-90, 90] if not defined at Layer level).
     * @property {Scheme}  classificationScheme - Color scheme for point classification values.
     * @property {Scheme}  discreteScheme - Color scheme for all other discrete values.
     * @property {object}  gradients - Descriptions of all available gradients.
     * @property {object}  gradient - Description of the gradient to use for display.
     * @property {THREE.CanvasTexture}  gradientTexture - The texture generate from the choosen gradient.
     *
     * @example
     * // change color category classification
     * const pointMaterial = new PointsMaterial();
     * pointMaterial.classification[3].color.setStyle('red');
     * pointMaterial.recomputeClassification();
     */
    constructor(options?: {
        size?: number | undefined;
        mode?: number | undefined;
        shape?: number | undefined;
        overlayColor?: THREE.Vector4 | undefined;
        classificationScheme?: any;
        discreteScheme?: any;
        gradient?: string | undefined;
        sizeMode?: number | undefined;
        minAttenuatedSize?: number | undefined;
        maxAttenuatedSize?: number | undefined;
    });
    gradients: any;
    gradientTexture: THREE.CanvasTexture<HTMLCanvasElement>;
    /** @param {number} size */
    set size(size: number);
    /** @returns {number} */
    get size(): number;
    classificationScheme: any;
    discreteScheme: any;
    set gradient(value: any);
    /**
     * Copy the parameters from the passed material into this material.
     * @override
     * @param {THREE.PointsMaterial} source
     * @returns {this}
     */
    override copy(source: THREE.PointsMaterial): this;
    /** @param {THREE.Texture | null} map */
    set map(map: THREE.Texture | null);
    /** @returns {THREE.Texture | null} */
    get map(): THREE.Texture | null;
    /** @param {THREE.Texture | null} map */
    set alphaMap(map: THREE.Texture | null);
    /** @returns {THREE.Texture | null} */
    get alphaMap(): THREE.Texture | null;
    /** @param {boolean} value */
    set sizeAttenuation(value: boolean);
    /** @returns {boolean} */
    get sizeAttenuation(): boolean;
    /** @param {THREE.Color} color */
    set color(color: THREE.Color);
    /** @returns {THREE.Color} */
    get color(): THREE.Color;
    sizeMode: number | undefined;
    /** @param {number} gamma */
    set gamma(gamma: number);
    /** @returns {number} */
    get gamma(): number;
    /** @param {number} ambientBoost */
    set ambientBoost(ambientBoost: number);
    /** @returns {number} */
    get ambientBoost(): number;
    recomputeClassification(): void;
    recomputeDiscreteTexture(): void;
    recomputeVisibilityTexture(): void;
    enablePicking(picking: any): void;
    picking: any;
}
