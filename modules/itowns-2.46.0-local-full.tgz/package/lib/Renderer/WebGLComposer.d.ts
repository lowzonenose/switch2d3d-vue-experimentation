import * as THREE from 'three';
import { RasterTile } from './RasterTile';
/**
 * Initializes a THREE.WebGLArrayRenderTarget with immutable storage
 * and populates its layers.
 * Returns the populated render target so callers can own/dispose it.
 *
 * @param width - The width of each layer in the DataArrayTexture.
 * @param height - The height of each layer in the DataArrayTexture.
 * @param count - The total number of layers the DataArrayTexture should have.
 * @param tiles - An array of RasterTile objects, each containing textures.
 * @param max - The maximum allowed number of layers for the DataArrayTexture.
 * @param renderer - The renderer used to render the texture.
 * @returns The constructed render target, or null
 */
export declare function makeDataArrayRenderTarget(width: number, height: number, count: number, tiles: RasterTile[], max: number, renderer: THREE.WebGLRenderer): THREE.WebGLArrayRenderTarget | null;
