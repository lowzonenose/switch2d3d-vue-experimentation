declare namespace _default {
    function patchMaterialForLogDepthSupport(material: any): void;
    function unrollLoops(string: any, defines: any): any;
}
export default _default;
