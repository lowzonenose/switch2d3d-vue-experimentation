import * as THREE from 'three';
/**
 * Manages render target cache with deferred disposal for better memory
 * management. Tracks which render targets are currently in use and
 * disposes those that are no longer needed.
 */
export declare class RenderTargetCache {
    /**
     * Render targets queued for disposal.
     */
    private _pendingDisposal;
    /**
     * Render targets used in the current render cycle.
     */
    private _usedIds;
    /**
     * LRU cache of render targets, automatically discards least recently
     * used when max is exceeded.
     */
    private _cache;
    constructor(maxCacheSize?: number);
    /**
     * Perform cleanup of render targets that are not used in this render cycle.
     */
    cleanup(): void;
    /**
     * Track usage of a render target in the current render cycle.
     *
     * @param id - The identifier of the render target to track
     */
    markAsUsed(id: string): void;
    /**
     * Get a render target from cache or pending disposal.
     *
     * @param id - The identifier of the render target
     * @returns The render target or undefined if not found
     */
    get(id: string): THREE.WebGLArrayRenderTarget | undefined;
    /**
     * Add or update a render target in cache.
     *
     * @param id - The identifier of the render target
     * @param rt - The render target to cache
     */
    set(id: string, rt: THREE.WebGLArrayRenderTarget): void;
    /**
     * Dispose all render targets and clear the cache completely.
     */
    dispose(): void;
}
