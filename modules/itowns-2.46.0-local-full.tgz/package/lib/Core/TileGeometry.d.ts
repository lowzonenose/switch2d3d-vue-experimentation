import * as THREE from 'three';
import { GpuBufferAttributes, TileBuilder, TileBuilderParams } from '../Core/Prefab/TileBuilder';
import { Extent } from '@itowns/geographic';
import { LRUCache } from 'lru-cache';
import OBB from '../Renderer/OBB';
type PartialParams<Params extends TileBuilderParams, Keys extends keyof Params = 'extent' | 'level'> = Pick<Params, Keys> & Partial<Params>;
export declare class TileGeometry extends THREE.BufferGeometry {
    /** Oriented Bounding Box of the tile geometry. */
    OBB: OBB | null;
    /** Ground area covered by this tile geometry. */
    extent: Extent;
    /** Resolution of the tile geometry in segments per side. */
    segments: number;
    /**
     * [TileGeometry] instances are shared between tiles. Since a geometry
     * handles its own GPU resource, it needs a reference counter to dispose of
     * that resource only when it is discarded by every single owner of a
     * reference to the geometry.
     */
    private _refCount;
    constructor(builder: TileBuilder, params: PartialParams<TileBuilderParams, 'extent' | 'level' | 'segments'>, bufferAttributes?: GpuBufferAttributes);
    /**
     * Enables or disables skirt rendering.
     *
     * @param toggle - Whether to hide the skirt; true hides, false shows.
     */
    set hideSkirt(toggle: boolean);
    /**
     * Initialize reference count for this geometry if it is currently null.
     *
     * @param cacheTile - The [Cache] used to store this geometry.
     * @param key - The [south, level, epsg] key of this geometry.
     */
    initRefCount(cacheTile: LRUCache<string, this>, key: string): void;
    /**
     * Increase reference count.
     *
     * @throws {Error} if reference count has not been initialized.
     */
    increaseRefCount(): void;
    /**
     * The current reference count of this [TileGeometry] if it has been
     * initialized.
     * @returns
     */
    get refCount(): number | undefined;
    dispose(): void;
}
export {};
