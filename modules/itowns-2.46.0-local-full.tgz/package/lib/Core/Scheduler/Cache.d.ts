/**
 * Cache policies for flushing. Those policies can be used as the
 * `cacheLifeTime` property of a layer.
 */
export type CACHE_POLICIES = {
    /**
     * - The entry is never flushed.
     */
    INFINITE: number;
    /**
     * - Shortcut for texture resources. Time is 15 minutes.
     */
    TEXTURE: number;
    /**
     * - Shortcut for geometry resources. Time is 15 minutes.
     */
    GEOMETRY: number;
};
export namespace CACHE_POLICIES {
    let INFINITE: number;
    let TEXTURE: number;
    let GEOMETRY: number;
}
