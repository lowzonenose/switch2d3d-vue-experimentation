import PointCloudNode from '../Core/PointCloudNode';
declare abstract class LasNodeBase extends PointCloudNode {
    /** X position within the octree */
    x: number;
    /** Y position within the octree */
    y: number;
    /** Z position within the octree */
    z: number;
    constructor(depth: number, x: number, y: number, z: number, numPoints: number);
    get networkOptions(): RequestInit;
}
export default LasNodeBase;
