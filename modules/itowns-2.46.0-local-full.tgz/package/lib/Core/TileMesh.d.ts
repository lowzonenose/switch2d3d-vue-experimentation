import * as THREE from 'three';
import type { Extent } from '@itowns/geographic';
import type { TileGeometry } from '../Core/TileGeometry';
import type Tile from '../Core/Tile/Tile';
import OBB from '../Renderer/OBB';
import type { LayeredMaterial, LayeredMaterialParameters } from '../Renderer/LayeredMaterial';
import type LayerUpdateState from '../Layer/LayerUpdateState';
import { TileBuilder, TileBuilderParams } from '../Core/Prefab/TileBuilder';
export interface TileLayerLike {
    diffuse: THREE.Color;
    showOutline: boolean;
    isGlobeLayer: boolean;
    segments: number;
    disableSkirt: boolean;
    hideSkirt: boolean;
    tileMatrixSets: string[];
    materialOptions: LayeredMaterialParameters;
    builder: TileBuilder<TileBuilderParams>;
    castShadow: boolean;
    receiveShadow: boolean;
}
/**
 * A TileMesh is a THREE.Mesh with a geometricError and an OBB.
 * The objectId property of the layered material is assigned to the id of the
 * TileMesh.
 * @param geometry - The tile geometry
 * @param material - A THREE.Material compatible with THREE.Mesh
 * @param layer - The layer the tile is added to
 * @param extent - The tile extent
 * @param level - The tile level (default = 0)
 */
declare class TileMesh extends THREE.Mesh<TileGeometry, LayeredMaterial> {
    readonly isTileMesh: true;
    layer: TileLayerLike;
    extent: Extent;
    level: number;
    obb: OBB;
    boundingSphere: THREE.Sphere;
    layerUpdateState: Record<string, LayerUpdateState>;
    geoidHeight: number;
    link: Record<string, unknown>;
    horizonCullingPoint: THREE.Vector3 | undefined;
    horizonCullingPointElevationScaled: THREE.Vector3 | undefined;
    private _tms;
    constructor(geometry: TileGeometry, material: LayeredMaterial, layer: TileLayerLike, extent: Extent, level?: number);
    /**
     * If specified, updates the min and max elevation of the OBB
     * and updates accordingly the bounding sphere and the geometric error.
     *
     * @param elevation - Elevation parameters
     * @param elevation.min - The minimum elevation
     * @param elevation.max - The maximum elevation
     * @param elevation.scale - The scale of the elevation
     * @param elevation.geoidHeight - The geoid height
     */
    setBBoxZ(elevation: {
        min?: number;
        max?: number;
        scale?: number;
        geoidHeight?: number;
    }): void;
    getExtentsByProjection(tms: string): Tile[] | undefined;
    /**
     * Finds the common ancestor between this tile and another one. It goes
     * through parents on each side until one is found.
     *
     * @param tile - The tile to find common ancestor with
     * @returns The common ancestor between those two tiles, or undefined if
     * not found
     */
    findCommonAncestor(tile: TileMesh): TileMesh | undefined;
    /**
     * An optional callback that is executed immediately before a 3D object
     * is rendered.
     *
     * @param renderer - The renderer used to render textures.
     */
    onBeforeRender(renderer: THREE.WebGLRenderer): void;
}
export default TileMesh;
