import type { View } from '../Main';
import { EventDispatcher } from 'three';
import type c3DEngine from '../Renderer/c3DEngine';
import type Scheduler from './Scheduler/Scheduler';
export declare const RENDERING_PAUSED = 0;
export declare const RENDERING_SCHEDULED = 1;
/**
 * MainLoop's update events list that are fired using
 * {@link View#execFrameRequesters}.
 */
export declare const MAIN_LOOP_EVENTS: {
    /** Fired at the start of the update */
    UPDATE_START: "update_start";
    /** Fired before the camera update */
    BEFORE_CAMERA_UPDATE: "before_camera_update";
    /** Fired after the camera update */
    AFTER_CAMERA_UPDATE: "after_camera_update";
    /** Fired before the layer update */
    BEFORE_LAYER_UPDATE: "before_layer_update";
    /** Fired after the layer update */
    AFTER_LAYER_UPDATE: "after_layer_update";
    /** Fired before the render */
    BEFORE_RENDER: "before_render";
    /** Fired after the render */
    AFTER_RENDER: "after_render";
    /** Fired at the end of the update */
    UPDATE_END: "update_end";
};
interface MainLoopEvents {
    'command-queue-empty': object;
}
declare class MainLoop extends EventDispatcher<MainLoopEvents> {
    private _needsRedraw;
    private _updateLoopRestarted;
    private _lastTimestamp;
    renderingState: typeof RENDERING_PAUSED | typeof RENDERING_SCHEDULED;
    scheduler: Scheduler;
    gfxEngine: c3DEngine;
    constructor(scheduler: Scheduler, engine: c3DEngine);
    scheduleViewUpdate(view: View, forceRedraw: boolean): void;
    private _update;
    step(view: View, timestamp: number): void;
    private _renderView;
}
export default MainLoop;
