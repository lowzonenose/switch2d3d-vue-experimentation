import * as THREE from 'three';
import { TileGeometry } from '../../Core/TileGeometry';
import type { Extent } from '@itowns/geographic';
import { Coordinates } from '@itowns/geographic';
export interface GpuBufferAttributes {
    index: THREE.BufferAttribute | null;
    position: THREE.BufferAttribute;
    normal: THREE.BufferAttribute;
    uvs: THREE.BufferAttribute[];
}
/**
 * Reference to a tile's extent with rigid transformations.
 * Enables reuse of geometry, saving a bit of memory.
 */
export interface ShareableExtent {
    shareableExtent: Extent;
    quaternion: THREE.Quaternion;
    position: THREE.Vector3;
}
export interface TileBuilderPrepareParams {
    /** Whether to build the skirt. */
    disableSkirt: boolean;
    /** Whether to render the skirt. */
    hideSkirt: boolean;
    /** Number of segments (edge loops) inside tiles. */
    segments: number;
    /** Buffer for projected points. */
    extent: Extent;
    level: number;
}
export interface TileBuilderParams extends TileBuilderPrepareParams {
    center: THREE.Vector3;
    coordinates: Coordinates;
}
export interface TileBuilder<SpecializedParams extends TileBuilderParams = TileBuilderParams> {
    crs: string;
    /** Convert builder-agnostic params to specialized ones. */
    prepare(params: TileBuilderPrepareParams): SpecializedParams;
    /**
     * Computes final offset of the second texture set.
     * Only relevant in the case of more than one texture sets.
     */
    computeExtraOffset?(params: SpecializedParams): number;
    /** Get the center of the current tile as a 3D vector. */
    center(extent: Extent): THREE.Vector3;
    /** Converts an x/y tile-space position to its equivalent in 3D space. */
    vertexPosition(coordinates: Coordinates): THREE.Vector3;
    /** Gets the geodesic normal of the last processed vertex. */
    vertexNormal(): THREE.Vector3;
    /** Project horizontal texture coordinate to world space. */
    uProject(u: number, extent: Extent): number;
    /** Project vertical texture coordinate to world space. */
    vProject(v: number, extent: Extent): number;
    /**
     * Compute shareable extent to pool geometries together.
     * The geometry of tiles on the same latitude is the same with an added
     * rigid transform.
     */
    computeShareableExtent(extent: Extent): ShareableExtent;
}
export declare function prepareTileMesh(builder: TileBuilder, params: TileBuilderPrepareParams): {
    geometry: TileGeometry;
    quaternion: THREE.Quaternion;
    position: THREE.Vector3;
};
