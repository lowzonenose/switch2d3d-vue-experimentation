export namespace GLOBE_VIEW_EVENTS {
    let GLOBE_INITIALIZED: string;
    let LAYER_ADDED: string;
    let LAYER_REMOVED: string;
    let COLOR_LAYERS_ORDER_CHANGED: string;
}
export default GlobeView;
declare class GlobeView extends View {
    /**
     * Creates a view of a globe.
     *
     * @extends View
     *
     * @example <caption><b>Instance GlobeView.</b></caption>
     * var viewerDiv = document.getElementById('viewerDiv');
     * const placement = {
     *     coord: new itowns.Coordinates('EPSG:4326', 2.351323, 48.856712),
     *     range: 25000000,
     * }
     * var view = new itowns.GlobeView(viewerDiv, placement);
     *
     * @param {HTMLDivElement} viewerDiv - Where to attach the view and display it
     * in the DOM.
     * @param {CameraTransformOptions|Extent} placement - An object to place view
     * @param {object} [options] - See options of {@link View}.
     * @param {object} [options.controls] - See options of {@link GlobeControls}
     * @param {object} [options.webXR] - WebXR configuration - its presence alone
     * enable WebXR to switch on VR visualization.
     * @param {Function} [options.webXR.callback] - WebXR rendering callback.
     * @param {boolean} [options.webXR.controllers] - Enable the webXR controllers handling.
     * @param {boolean} [options.dynamicCameraNearFar=true] - The camera's near and far are automatically adjusted.
     * @param {number} [options.farFactor=0.3] - Controls the far plane distance at low altitudes.
     * Value between 0 and 1. Lower values reduce far distance near the ground. At higher altitudes,
     * far distance transitions to full horizon distance.
     * @param {number} [options.maxFarAltitude=80000] - the altitude at which the horizon is fully visible (meters).
     * @param {number} [options.minFarDistance=10000] - the minimum horizon distance (meters).
     * @param {boolean} [options.realisticLighting=false] - Enable realistic lighting.
     * It can later be switched by setting this.realisticLighting to true/false.
     * @param {boolean} [options.forceDaytime=true] - Keep the sun above the horizon
     * at the camera position regardless of the view date.
     * It can later be switched by setting `this.sunLightLayer.forceDaytime`.
     * The sun light can be toggled with `this.sunLightLayer.visible`.
     * @param {boolean} [options.shadows=false] - Enable shadow map rendering. Can be toggled
     * later via `this.shadows`.
     */
    constructor(viewerDiv: HTMLDivElement, placement?: CameraTransformOptions | Extent, options?: {
        controls?: object | undefined;
        webXR?: {
            callback?: Function | undefined;
            controllers?: boolean | undefined;
        } | undefined;
        dynamicCameraNearFar?: boolean | undefined;
        farFactor?: number | undefined;
        maxFarAltitude?: number | undefined;
        minFarDistance?: number | undefined;
        realisticLighting?: boolean | undefined;
        forceDaytime?: boolean | undefined;
        shadows?: boolean | undefined;
    });
    isGlobeView: boolean;
    altitude: number;
    DEFAULT_NEAR: number;
    cameraNear: number;
    DEFAULT_FAR: number;
    cameraFar: number;
    farFactor: number;
    maxFarAltitude: number;
    minFarDistance: number;
    tileLayer: GlobeLayer;
    dynamicCameraNearFar: boolean;
    horizonScaleFactor: number;
    horizonDistance: number | null;
    globeRadiusMax: number;
    controls: GlobeControls | undefined;
    webXR: WebXR | undefined;
    date: Date;
    sunLightLayer: SunLightLayer;
    skyController: SkyController;
    set shadows(value: boolean);
    /**
     * Enable or disable shadow rendering.
     * Does not affect shadows cast by user-defined lights.
     * @type {boolean}
     */
    get shadows(): boolean;
    updateAltitudeAndClipping(): void;
    /**
     * This factor scales down the visible horizon at low altitudes based on farFactor and maxFarAltitude.
     * farFactor sets its minimum at sea level and maxFarAltitude the altitude at which the horizon is fully visible.
     * @returns {number} Scale factor between farFactor and 1
     */
    computeHorizonScaleFactor(): number;
    computeHorizonDistance(): number;
    computeCameraNear(): number;
    computeCameraFar(): number | null;
    /**
     * Add layer in viewer.
     * The layer id must be unique.
     *
     * The `layer.whenReady` is a promise that resolves when
     * the layer is done. This promise is also returned by
     * `addLayer` allowing to chain call.
     *
     * The layer added is attached, by default to `GlobeLayer` (`GlobeView.tileLayer`).
     * If you want add a unattached layer use `View#addLayer` parent method.
     *
     * @param {LayerOptions|Layer|GeometryLayer} layer The layer to add in view.
     * @returns {Promise} a promise resolved with the new layer object when it is fully initialized or rejected if any error occurred.
     */
    addLayer(layer: LayerOptions | Layer | GeometryLayer): Promise<any>;
    getPixelsToDegrees(pixels: number | undefined, screenCoord: any): number;
    getPixelsToDegreesFromDistance(pixels?: number, distance?: number): number;
    getMetersToDegrees(meters?: number): number;
    set realisticLighting(value: boolean);
    get realisticLighting(): boolean;
}
import View from '../../Core/View';
import GlobeLayer from '../../Core/Prefab/Globe/GlobeLayer';
import GlobeControls from '../../Controls/GlobeControls';
import WebXR from '../../Renderer/WebXR';
import SunLightLayer from '../../Layer/SunLightLayer';
import SkyController from '../../Core/Prefab/Globe/SkyController';
