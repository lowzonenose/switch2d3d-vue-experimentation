import * as THREE from 'three';
import type { TileBuilder, TileBuilderPrepareParams } from '../../Core/Prefab/TileBuilder';
export declare function getBufferIndexSize(segments: number, noSkirt: boolean): number;
type Option<T> = T | undefined;
type IndexArray = Option<Uint8Array | Uint16Array | Uint32Array>;
export interface Buffers {
    index: IndexArray;
    position: Float32Array;
    normal: Float32Array;
    uvs: [Option<Float32Array>, Option<Float32Array>];
}
interface BufferCache {
    index: Exclude<IndexArray, undefined>;
    uv: Float32Array;
}
interface ComputeBuffersParams extends TileBuilderPrepareParams {
    center: THREE.Vector3;
}
/**
 * Compute buffers describing a tile according to a builder and its params.
 * @param builder
 * @param params
 * @param cache
 * @returns
 */
export declare function computeBuffers(builder: TileBuilder, params: ComputeBuffersParams, cache?: BufferCache): Buffers;
export {};
