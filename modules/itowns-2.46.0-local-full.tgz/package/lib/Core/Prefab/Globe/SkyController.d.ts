import SunLightLayer from '../../../Layer/SunLightLayer';
import RealisticSky from '../../../Core/Prefab/Globe/RealisticSky';
import SimpleSky, { SimpleSkyParameters } from '../../../Core/Prefab/Globe/SimpleSky';
import GlobeView from '../../../Core/Prefab/GlobeView';
import { AtmosphereParameters } from '@takram/three-atmosphere';
declare class SkyController {
    private readonly _view;
    private _activeSky;
    private _realisticSky;
    private _simpleSky;
    private readonly _sunLightLayer;
    private _realisticLighting;
    private _realisticParams?;
    private _simpleParams?;
    private _ambientLight;
    constructor(view: GlobeView, sunLightLayer: SunLightLayer, options?: {
        realisticLighting?: boolean;
        realisticSky?: AtmosphereParameters;
        simpleSky?: SimpleSkyParameters;
    });
    get realisticLighting(): boolean;
    set realisticLighting(value: boolean);
    update(): void;
    set enabled(value: boolean);
    get enabled(): boolean;
    dispose(): void;
    get realisticSky(): RealisticSky;
    get simpleSky(): SimpleSky;
    private updateAmbientLight;
}
export default SkyController;
