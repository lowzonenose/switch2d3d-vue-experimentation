import * as THREE from 'three';
import GlobeView from '../../../Core/Prefab/GlobeView';
/**
 * Screen-space atmospheric horizon band rendered as a full-screen quad.
 *
 * This helper draws a soft gradient near the geometric horizon to visually
 * blend ground fog into the sky.
 *
 * Notes:
 * - Based on `ellipsoidSizes`.
 * - It relies on scene fog color (`view.scene.fog`).
 * - It is rendered late (`renderOrder = 999`) as a transparent pass.
 */
declare class HorizonGradient {
    mesh: THREE.Mesh<THREE.PlaneGeometry, THREE.ShaderMaterial>;
    constructor(scene: THREE.Scene);
    update(view: GlobeView, fogSpreadValue: number): void;
    get visible(): boolean;
    set visible(visible: boolean);
}
export default HorizonGradient;
