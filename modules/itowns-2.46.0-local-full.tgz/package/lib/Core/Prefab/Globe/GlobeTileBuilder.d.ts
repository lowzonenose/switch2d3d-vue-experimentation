import * as THREE from 'three';
import { Coordinates, Extent } from '@itowns/geographic';
import { ShareableExtent, TileBuilder, TileBuilderParams } from '../TileBuilder';
/** Specialized parameters for the [GlobeTileBuilder]. */
export interface GlobeTileBuilderParams extends TileBuilderParams {
    /** Number of rows of tiles, essentially the resolution of the globe. */
    nbRow: number;
    /** Offset of the second texture set. */
    deltaUV1: number;
    /** Transformation to align a tile's normal to the Z axis. */
    quatNormalToZ: THREE.Quaternion;
}
/**
 * TileBuilder implementation for the purpose of generating globe (or more
 * precisely ellipsoidal) tile arrangements.
 */
export declare class GlobeTileBuilder implements TileBuilder<GlobeTileBuilderParams> {
    private static _crs;
    private static _computeExtraOffset;
    /**
     * Buffer holding information about the tile/vertex currently being
     * processed.
     */
    private _transform;
    computeExtraOffset?: (params: GlobeTileBuilderParams) => number;
    get crs(): string;
    constructor(options: {
        /** Number of unaligned texture sets. */
        uvCount: number;
    });
    prepare(params: TileBuilderParams): GlobeTileBuilderParams;
    center(extent: Extent): THREE.Vector3;
    vertexPosition(coordinates: Coordinates): THREE.Vector3;
    vertexNormal(): THREE.Vector3;
    uProject(u: number, extent: Extent): number;
    vProject(v: number, extent: Extent): number;
    computeShareableExtent(extent: Extent): ShareableExtent;
}
