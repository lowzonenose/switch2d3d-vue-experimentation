import * as THREE from 'three';
import { AerialPerspectiveEffect, SkyLightProbe } from '@takram/three-atmosphere';
import { EffectComposer, EffectPass, RenderPass } from 'postprocessing';
import GlobeView from '../../../Core/Prefab/GlobeView';
import SunLightLayer from '../../../Layer/SunLightLayer';
import ISkyStrategy from './ISkyStrategy';
export interface RealisticSkyParameters {
    rayleighScattering: THREE.Vector3;
    mieScattering: THREE.Vector3;
    mieExtinction: THREE.Vector3;
    miePhaseFunctionG: number;
}
declare class RealisticSky implements ISkyStrategy {
    sky: THREE.Mesh;
    skyLight: SkyLightProbe;
    aerialPerspective: AerialPerspectiveEffect;
    renderPass: RenderPass;
    effectPass: EffectPass;
    FXAAPass: EffectPass;
    scene: THREE.Scene;
    composer: EffectComposer;
    view: GlobeView;
    sunLightLayer: SunLightLayer;
    ready: boolean;
    constructor(view: GlobeView, sunLightLayer: SunLightLayer, params?: RealisticSkyParameters, skyLightIntensity?: number);
    update(): void;
    get enabled(): boolean;
    set enabled(on: boolean);
    dispose(): void;
    private _setState;
}
export default RealisticSky;
