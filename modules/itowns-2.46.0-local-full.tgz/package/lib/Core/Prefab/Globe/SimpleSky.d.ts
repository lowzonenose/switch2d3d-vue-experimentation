import * as THREE from 'three';
import HorizonGradient from '../../../Core/Prefab/Globe/HorizonGradient';
import GlobeView from '../../../Core/Prefab/GlobeView';
import ISkyStrategy from './ISkyStrategy';
export interface SimpleSkyParameters {
    fogSpread?: number;
    skyAltitude?: number;
    enabled?: boolean;
    spaceColor?: THREE.ColorRepresentation;
    skyColor?: THREE.ColorRepresentation;
    fogColor?: THREE.ColorRepresentation;
}
/**
 * Renders a simple sky representation with fog effects, atmospheric gradient, and color blending based on altitude,
 * for a globe view.
 */
declare class SimpleSky implements ISkyStrategy {
    view: GlobeView;
    fogSpread: number;
    skyAltitude: number;
    spaceColor: THREE.Color;
    skyColor: THREE.Color;
    fogColor: THREE.Color;
    horizonGradient: HorizonGradient;
    readonly ready: boolean;
    private _enabled;
    constructor(view: GlobeView, options: SimpleSkyParameters);
    get enabled(): boolean;
    set enabled(on: boolean);
    update(): void;
    updateFog(altitude: number): void;
    computeFogSpread(altitude: number): number;
    updateSkyColor(altitude: number): void;
    computeSkyColor(altitude: number): THREE.Color;
    updateAtmosphericGradient(altitude: number): void;
    dispose(): void;
}
export default SimpleSky;
