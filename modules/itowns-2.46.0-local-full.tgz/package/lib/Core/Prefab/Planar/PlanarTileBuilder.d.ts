import * as THREE from 'three';
import { Coordinates, Extent } from '@itowns/geographic';
import { ShareableExtent, TileBuilder, TileBuilderParams } from '../TileBuilder';
/** Specialized parameters for the [PlanarTileBuilder]. */
export interface PlanarTileBuilderParams extends TileBuilderParams {
    uvCount?: number;
    nbRow: number;
}
/**
 * TileBuilder implementation for the purpose of generating planar
 * tile arrangements.
 */
export declare class PlanarTileBuilder implements TileBuilder<PlanarTileBuilderParams> {
    private _uvCount;
    private _transform;
    private _crs;
    constructor(options: {
        projection?: string;
        crs: string;
        uvCount?: number;
    });
    get uvCount(): number;
    get crs(): string;
    prepare(params: TileBuilderParams): PlanarTileBuilderParams;
    center(extent: Extent): THREE.Vector3;
    vertexPosition(coordinates: Coordinates): THREE.Vector3;
    vertexNormal(): THREE.Vector3;
    uProject(u: number, extent: Extent): number;
    vProject(v: number, extent: Extent): number;
    computeShareableExtent(extent: Extent): ShareableExtent;
}
