export default PlanarView;
declare class PlanarView extends View {
    /**
     * @extends View
     *
     * @example <caption><b>Instance with placement on the ground.</b></caption>
     * var viewerDiv = document.getElementById('viewerDiv');
     * const extent = new Extent('EPSG:3946', 1837816.94334, 1847692.32501, 5170036.4587, 5178412.82698);
     * var view = new itowns.PlanarView(viewerDiv, extent, { placement: { heading: -49.6, range: 6200, tilt: 17 } });
     *
     * @param {HTMLDivElement} viewerDiv - Where to attach the view and display it
     * in the DOM.
     * @param {Extent} extent - The ground extent.
     * @param {object} [options] - See options of {@link View}.
     * @param {boolean} [options.noControls=false] - If true, no controls are associated to the view.
     * @param {object} [options.controls] - options for the {@link PlanarControls} associated to the view, if
     * `options.noControls` is false.
     * @param {CameraTransformOptions|Extent} [options.placement] - The
     * {@link CameraUtils~CameraTransformOptions} to apply to view's camera or the extent it must display at
     * initialization. By default, camera will display the view's extent (given in `extent` parameter).
     * @param {boolean} [options.dynamicCameraNearFar=true] - The camera's near and far are automatically adjusted.
     * @param {number} [options.farFactor=20] - Controls how far the camera can see.
     * The maximum view distance is this factor times the camera’s altitude (above sea level).
     * @param {number} [options.fogSpread=0.5] - Proportion of the visible depth range that contains fog.
     *  Between 0 and 1.
     */
    constructor(viewerDiv: HTMLDivElement, extent: Extent, options?: {
        noControls?: boolean | undefined;
        controls?: object | undefined;
        placement?: CameraTransformOptions | Extent;
        dynamicCameraNearFar?: boolean | undefined;
        farFactor?: number | undefined;
        fogSpread?: number | undefined;
    });
    isPlanarView: boolean;
    controls: PlanarControls | undefined;
    tileLayer: PlanarLayer;
    farFactor: number;
    fogSpread: number;
    addLayer(layer: any): Promise<any>;
}
import View from '../../Core/View';
import PlanarControls from '../../Controls/PlanarControls';
import PlanarLayer from './Planar/PlanarLayer';
