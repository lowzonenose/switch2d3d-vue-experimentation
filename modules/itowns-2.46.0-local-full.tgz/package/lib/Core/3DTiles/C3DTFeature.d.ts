export default C3DTFeature;
/**
 * C3DTFeature is a feature of a 3DTiles
 *
 * @class      C3DTFeature
 * @param {number} tileId - tileId
 * @param {number} batchId - batch id
 * @param {Array<{start:number,count:number}>} groups - groups in geometry.attributes matching batchId
 * @param {object} [userData] - some userData
 * @param {Object3D} object3d - object3d in which feature is present
 * @property {number} tileId - tile id
 * @property {Object3D} object3d - object3d in which feature is present
 * @property {number} batchId - batch id
 * @property {Array<{start:number,count:number}>} groups - groups in geometry.attributes matching batchId
 * @property {object} [userData] - some userData
 */
declare class C3DTFeature {
    constructor(tileId: any, batchId: any, groups: any, userData: any, object3d: any);
    /** @type {Object3D} */
    object3d: Object3D;
    /** @type {number} */
    batchId: number;
    /** @type {Array<{start:number,count:number}>} */
    groups: Array<{
        start: number;
        count: number;
    }>;
    /** @type {object} */
    userData: object;
    /** @type {number} */
    tileId: number;
    /**
     * Compute world box3 of this
     *
     * @param {Box3} target - target of the result
     * @returns {Box3}
     */
    computeWorldBox3(target?: Box3): Box3;
    /**
     * Gets the information from the tile batch table for this C3DTFeature batch id.
     * @returns {object} - batchTable info
     */
    getInfo(): object;
    #private;
}
import { Object3D } from 'three';
import { Box3 } from 'three';
