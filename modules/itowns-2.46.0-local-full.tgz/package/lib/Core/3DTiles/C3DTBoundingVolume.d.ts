export default C3DTBoundingVolume;
/**
 * [bounding volume](https://github.com/AnalyticalGraphicsInc/3d-tiles/blob/master/specification/schema/boundingVolume.schema.json)
 * Used to represent bounding volumes and viewer request volumes. The input bounding volume (from the dataset) can be a
 * box, a sphere or a region. Regions are transformed to spheres internally for simplification of parsing and to speed
 * up computations such as culling.
 * @property {C3DTilesTypes} type - Used by 3D Tiles extensions
 * (e.g. {@link C3DTBatchTableHierarchyExtension}) to know in which context
 * (i.e. for which 3D Tiles class) the parsing of the extension should be done.
 * @property {string} initialVolumeType - the initial volume type to be able to dissociate spheres
 * and regions if needed since both are converted to spheres (one of {@link C3DTilesBoundingVolumeTypes})
 * @property {THREE.Box3|THREE.Sphere} volume - The 3D bounding volume created. Can be a THREE.Box3 for bounding volumes
 * of types box or a THREE.Sphere for bounding volumes of type sphere or region.
 * @property {object} extensions - 3D Tiles extensions of the bounding volume
 * stored in the following format:
 * {extensioName1: extensionObject1, extensioName2: extensionObject2, ...}
 */
declare class C3DTBoundingVolume {
    constructor(json: any, tileMatrixInverse: any, registeredExtensions: any);
    type: string;
    initialVolumeType: string;
    volume: THREE.Box3 | THREE.Sphere;
    extensions: any;
    /**
     * Performs camera frustum culling on bounding volumes.
     * @param {Camera} camera - the camera to perform culling for
     * @param {THREE.Matrix4} tileMatrixWorld - the world matrix of the tile
     * @returns {boolean} true if the tile should be culled out (bounding volume not in camera frustum), false otherwise.
     */
    boundingVolumeCulling(camera: Camera, tileMatrixWorld: THREE.Matrix4): boolean;
    /**
     * Checks if the camera is inside the [viewer request volumes](https://github.com/CesiumGS/3d-tiles/tree/main/specification#viewer-request-volume).
     * @param {Camera} camera - the camera to perform culling for
     * @param {THREE.Matrix4} tileMatrixWorld - the world matrix of the tile
     * @returns {boolean} true if the camera is outside the viewer request volume, false otherwise.
     */
    viewerRequestVolumeCulling(camera: Camera, tileMatrixWorld: THREE.Matrix4): boolean;
}
import * as THREE from 'three';
