export default C3DTBatchTable;
/**
 * A 3D Tiles
 * [batch
 * table](https://github.com/AnalyticalGraphicsInc/3d-tiles/tree/master/specification/TileFormats/BatchTable).
 * @property {C3DTilesTypes} type - Used by 3D Tiles extensions
 * (e.g. {@link C3DTBatchTableHierarchyExtension}) to know in which context
 * (i.e. for which 3D Tiles class) the parsing of the extension should be done.
 * @property {number} batchLength - the length of the batch.
 * @property {object} content - the content of the batch table in the form:
 * {property1: values[], property2: values[], ...}.
 * @property {object} extensions - 3D Tiles extensions of the batch table
 * stored in the following format:
 * {extensioName1: extensionObject1, extensioName2: extensionObject2, ...}
 */
declare class C3DTBatchTable {
    /**
     * @param {ArrayBuffer} [buffer=new ArrayBuffer()] - batch table buffer to parse
     * @param {number} [jsonLength=0] - batch table json part length
     * @param {number} [binaryLength=0] - batch table binary part length
     * @param {number} [batchLength=0] - the length of the batch.
     * @param {object} [registeredExtensions] - extensions registered to the layer
     */
    constructor(buffer?: ArrayBuffer, jsonLength?: number, binaryLength?: number, batchLength?: number, registeredExtensions?: object, ...args: any[]);
    type: string;
    batchLength: number;
    extensions: any;
    content: any;
    /**
     * Creates and returns a javascript object holding the displayable
     * information from the batch table and from extensions of the batch table,
     * for a given feature (identified with its batchID).
     * @param {integer} batchID - id of the feature
     * @returns {object} - displayable information relative to the batch
     * table and its extensions. Object is formatted as follow:
     * {batchTable:
     *      {property1: value1
     *       property2: value2
     *       ...}
     *  extensions:
     *      {extension1:
     *          {property1: value1
     *           ...}
     *        extension2: {...}
     *        ...}
     * }
     */
    getInfoById(batchID: integer): object;
}
