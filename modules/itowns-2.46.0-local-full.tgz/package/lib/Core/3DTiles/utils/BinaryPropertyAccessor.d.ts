export default binaryPropertyAccessor;
/**
 * Parses a 3D Tiles binary property. Used for batch table and feature table parsing. See the 3D Tiles spec for more
 * information on how these values are encoded:
 * [3D Tiles spec](https://github.com/CesiumGS/3d-tiles/blob/main/specification/TileFormats/BatchTable/README.md#binary-body))
 * @param {ArrayBuffer} buffer The buffer to parse values from.
 * @param {number} batchLength number of objects in the batch (= number of elements to parse).
 * @param {number} byteOffset the offset in bytes into the buffer.
 * @param {string} componentType the type of component to parse (one of componentTypeBytesSize keys)
 * @param {string} type the type of element to parse (one of typeComponentsNumber keys)
 * @returns {Array} an array of values parsed from the buffer. An array of componentType if type is SCALAR. An array
 * of Threejs Vector2, Vector3 or Vector4 if type is VEC2, VEC3 or VEC4 respectively.
 */
declare function binaryPropertyAccessor(buffer: ArrayBuffer, batchLength: number, byteOffset: number, componentType: string, type: string): any[];
