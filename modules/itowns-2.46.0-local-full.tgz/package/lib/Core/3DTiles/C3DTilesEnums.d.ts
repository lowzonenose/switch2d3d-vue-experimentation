/**
 * C3DTilesTypes
 */
export type C3DTilesTypes = object;
export namespace C3DTilesTypes {
    let tileset: string;
    let batchtable: string;
    let boundingVolume: string;
}
export namespace C3DTilesBoundingVolumeTypes {
    let region: string;
    let box: string;
    let sphere: string;
}
