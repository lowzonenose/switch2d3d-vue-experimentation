import type CopcSource from '../Source/CopcSource';
import { Hierarchy } from 'copc';
import LasNodeBase from '../Core/LasNodeBase';
declare class CopcNode extends LasNodeBase {
    /**
     * Used to checkout whether this node is a CopcNode. Default is `true`.
     * You should not change this, as it is used internally for optimisation.
     */
    readonly isCopcNode: true;
    source: CopcSource;
    url: string;
    /** Octree's subtree */
    hierarchy: Hierarchy.Subtree;
    /**
     * The string id of the node, constituted of the four components:
     * `depth-x-y-z`.
     */
    voxelKey: string;
    /**
     * Offset from the beginning of the file of the node entry
     */
    private entryOffset;
    /** Size of the node entry */
    private entryLength;
    /**
     * Constructs a new instance of a COPC Octree node
     *
     * @param depth - Depth within the octree.
     * @param x - X position within the octree.
     * @param y - Y position within the octree.
     * @param z - Z position with the octree.
     * @param source - Data source (COPC) of the node.
     * Set to -1 when we don't have the information yet.
     * @param hierarchy
     */
    constructor(depth: number, x: number, y: number, z: number, source: CopcSource, hierarchy: Hierarchy.Subtree);
    fetcher(url: string, networkOptions: RequestInit): Promise<ArrayBuffer>;
    loadHierarchy(): Promise<Hierarchy.Subtree>;
    /**
     * Create a CopcNode from the provided subtree and add it as child
     * of the current node.
     * @param depth - Child node depth in the octree
     * @param x - Child node x position in the octree
     * @param y - Child node y position in the octree
     * @param z - Child node z position in the octree
     */
    findAndCreateChild(depth: number, x: number, y: number, z: number): void;
}
export default CopcNode;
