export function deprecatedColorLayerOptions(options: any): any;
export function deprecatedParsingOptionsToNewOne(options: any): any;
export function deprecatedFeature2MeshOptions(options: any): void;
export function deprecatedC3DEngineWebGLOptions(options: any): void;
declare const _default: {};
export default _default;
