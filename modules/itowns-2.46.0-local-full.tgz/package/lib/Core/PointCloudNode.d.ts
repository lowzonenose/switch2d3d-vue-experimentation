import * as THREE from 'three';
import { Box3 } from 'three';
import OBB from '../Renderer/OBB';
export interface PointCloudSource {
    /** The minimum distance between points at root level. */
    spacing: number;
    crs: string;
    zmin: number;
    zmax: number;
    fetcher: (url: string, options?: RequestInit) => Promise<ArrayBuffer>;
    parser: (data: ArrayBuffer, options: {
        in: PointCloudNode;
        out: {
            crs: string;
        };
    }) => THREE.BufferGeometry;
    networkOptions: RequestInit;
}
export declare function buildVoxelKey(depth: number, x: number, y: number, z: number): string;
declare abstract class PointCloudNode extends THREE.EventDispatcher {
    /** Data source of the node. */
    abstract source: PointCloudSource;
    depth: number;
    /**
     * The number of points in this node.
     * '-1' is the node has been loaded yet
     */
    numPoints: number;
    /** The children nodes of this node. */
    children: this[];
    parent: this | undefined;
    /** The node cubique obb. */
    voxelOBB: OBB;
    /** The cubique obb clamped to zmin and zmax. */
    clampOBB: OBB;
    /** Property used internally by PointCloud layer. */
    visible: boolean;
    /** The sse of the node set at an nitial value of -1. */
    sse: number;
    notVisibleSince: number | undefined;
    promise: Promise<unknown> | null;
    obj: THREE.Points & {
        matrixWorldInverse?: THREE.Matrix4;
    } | undefined;
    abstract url: string;
    abstract x: number;
    abstract y: number;
    abstract z: number;
    /**
     * The string id of the node, constituted of the four
     * components: `depth-x-y-z`.
     */
    abstract voxelKey: string;
    private _childrenCreated;
    constructor(depth: number, numPoints?: number);
    abstract get networkOptions(): RequestInit;
    abstract fetcher(url: string, networkOptions: RequestInit): Promise<ArrayBuffer>;
    abstract loadHierarchy(): Promise<unknown>;
    abstract findAndCreateChild(depth: number, x: number, y: number, z: number): void;
    get pointSpacing(): number;
    get hierarchyIsLoaded(): boolean;
    get id(): string;
    load(crsOut: string): Promise<THREE.BufferGeometry>;
    createChildren(): Promise<void>;
    add(node: this): void;
    setOBBes(): void;
    computeBBoxFromParent(): Box3;
    findCommonAncestor(node: this): this | undefined;
}
export default PointCloudNode;
