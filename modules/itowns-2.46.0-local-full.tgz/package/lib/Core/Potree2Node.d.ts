import type Potree2Source from '../Source/Potree2Source';
import { PotreeNodeBase } from '../Core/PotreeNodeBase';
export interface Potree2NodeHierarchy {
    numPoints: number;
    byteOffset: bigint;
    byteSize: bigint;
}
declare class Potree2Node extends PotreeNodeBase {
    source: Potree2Source;
    url: string;
    hierarchy: Record<string, Potree2NodeHierarchy>;
    voxelKey: string;
    private baseurl;
    private byteOffset;
    private byteSize;
    constructor(depth: number, x: number, y: number, z: number, source: Potree2Source, hierarchy: Record<string, Potree2NodeHierarchy>);
    get networkOptions(): RequestInit;
    loadHierarchy(): Promise<Record<string, Potree2NodeHierarchy>>;
    findAndCreateChild(depth: number, x: number, y: number, z: number): void;
}
export default Potree2Node;
