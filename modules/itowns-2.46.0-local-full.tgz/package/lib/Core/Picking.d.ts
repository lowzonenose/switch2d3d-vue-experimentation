declare namespace _default {
    function pickTilesAt(view: any, viewCoords: any, radius: any, layer: any, results?: any[]): any[];
    function pickPointsAt(view: any, viewCoords: any, radius: any, layer: any, result?: any[]): any[] | undefined;
    function pickObjectsAt(view: any, viewCoords: any, radius: any, object: any, target?: any[]): any[];
}
export default _default;
