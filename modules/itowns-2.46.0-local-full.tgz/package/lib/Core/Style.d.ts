export function readExpression(property: any, ctx: any): any;
/**
 * StyleContext stores metadata of one FeatureGeometry that are needed for its style computation:
 * type of feature and what is needed (fill, stroke or draw a point, etc.) as well as where to get its
 * properties and its coordinates (for base_altitude).
 *
 * @property {number}               zoom Current zoom to display the FeatureGeometry.
 * @property {object}               collection The FeatureCollection to which the FeatureGeometry is attached.
 * @property {object}               properties Properties of the FeatureGeometry.
 * @property {string}               type Geometry type of the feature. Can be `point`, `line`, or `polygon`.
 * @property {StyleOptions|Function}featureStyle StyleOptions object (or a function returning one) to get style
 *                                  information at feature and FeatureGeometry level from the data parsed.
 * @property {Coordinates}          coordinates The coordinates (in world space) of the last vertex (x, y, z) set with
 *                                  setLocalCoordinatesFromArray().
 * private properties:
 * @property {Coordinates}          worldCoord (private) Coordinates object to store coordinates in world space.
 * @property {Coordinates}          localCoordinates (private) Coordinates object to store coordinates in local space.
 * @property {boolean}              worldCoordsComputed (private) Have the world coordinates already been computed
 *                                      from the local coordinates?
 * @property {Feature}              feature  (private) The itowns feature of interest.
 * @property {FeatureGeometry}      geometry  (private) The FeatureGeometry to compute the style.
 */
export class StyleContext {
    setZoom(zoom: any): void;
    zoom: any;
    setFeature(f: any): void;
    setGeometry(g: any): void;
    /**
     * @param {object} c - The collection object.
     */
    setCollection(c: object): void;
    collection: object | undefined;
    setLocalCoordinatesFromArray(vertices: any, offset: any): Coordinates;
    get geometry(): {};
    get properties(): any;
    get type(): any;
    get featureStyle(): any;
    get coordinates(): Coordinates;
    #private;
}
export default Style;
import { Coordinates } from '@itowns/geographic';
/**
 * A Style is a class that defines the visual appearance of {@link
 * FeatureCollection} and {@link Feature}. It is taken into account when drawing
 * them in textures that will be placed onto tiles.
 *
 * As there are five basic elements present in `Features`, there are also five
 * main components in a `Style` object:
 * - `fill` is for all fillings and polygons
 * - `stroke` is for all lines and polygons edges
 * - `point` is for all points
 * - `text` contains all {@link Label} related things
 * - `icon` defines the appearance of icons attached to label.
 *
 * Many style property can be set to functions. When that is the case, the function's
 * return type must necessarily be the same as the types (other than function) of the property.
 * For instance, if the `fill.pattern` property is set to a function, this function must return
 * an `Image`, a `Canvas`, or `String`.
 * The first parameter of functions used to set `Style` properties is always an object containing
 * the properties of the features displayed with the current `Style` instance.
 *
 * @property {object} fill - Polygons and fillings style.
 * @property {string | Function | THREE.Color} fill.color - Defines the main color of the filling. Can be
 * any [valid color
 * string](https://developer.mozilla.org/en-US/docs/Web/CSS/color_value).
 * Default is no value, indicating that no filling needs to be done.
 * If the `Layer` is a `GeometryLayer` you can use `THREE.Color`.
 * @property {Image | Canvas | string | object | Function} [fill.pattern] - Defines a pattern to fill the
 * surface with. It can be an `Image` to use directly, an url to fetch the pattern or an object containing
 * the url of the image to fetch and the transformation to apply.
 * from. See [this example] (http://www.itowns-project.org/itowns/examples/#source_file_geojson_raster)
 * for how to use.
 * @property {Image | string} [fill.pattern.source] - The image or the url to fetch the pattern image
 * @property {object} [fill.pattern.cropValues] - The x, y, width and height (in pixel) of the sub image to use.
 * @property {THREE.Color} [fill.pattern.color] - Can be any [valid color string]
 * @property {number | Function} fill.opacity - The opacity of the color or of the
 * pattern. Can be between `0.0` and `1.0`. Default is `1.0`.
 * For a `GeometryLayer`, this opacity property isn't used.
 * @property {number | Function} fill.base_altitude - Only for {@link GeometryLayer}, defines altitude
 * for each coordinate.
 * If `base_altitude` is `undefined`, the original altitude is kept, and if it doesn't exist
 * then the altitude value is set to 0.
 * @property {number | Function} [fill.extrusion_height] - Only for {@link GeometryLayer} and if user sets it.
 * If defined, polygons will be extruded by the specified amount.
 * @property {boolean} [fill.levelled_roofs=false] - Only for {@link GeometryLayer} with extrusion.
 * When true, all roof vertices are placed at a uniform height equal to the polygon's minimum
 * base altitude plus the extrusion height, producing flat-topped extrusions even over uneven
 * terrain. Cannot be set to a function.
 * @property {object} stroke - Lines and polygons edges.
 * @property {string | Function | THREE.Color} stroke.color The color of the line. Can be any [valid
 * color string](https://developer.mozilla.org/en-US/docs/Web/CSS/color_value).
 * Default is no value, indicating that no stroke needs to be done.
 * If the `Layer` is a `GeometryLayer` you can use `THREE.Color`.
 * @property {number|Function} stroke.opacity - The opacity of the line. Can be between
 * `0.0` and `1.0`. Default is `1.0`.
 * For a `GeometryLayer`, this opacity property isn't used.
 * @property {string|Function} [stroke.line_cap] - The shape used at the ends of lines.
 * For extruded `GeometryLayer` lines, setting it to `round` adds half-sphere caps.
 * @property {number|Function} stroke.width - The width of the line. Default is `1.0`.
 * @property {number|Function} stroke.base_altitude - Only for {@link GeometryLayer}, defines altitude
 * for each coordinate.
 * If `base_altitude` is `undefined`, the original altitude is kept, and if it doesn't exist
 * then the altitude value is set to 0.
 * @property {number|Function} [stroke.extrusion_radius] - Only for {@link GeometryLayer} and if user sets it.
 * If defined, lines will be extruded as cylinders with the specified amount as a radius.
 *
 * @property {object} point - Point style.
 * @property {string|Function} point.color - The color of the point. Can be any [valid
 * color string](https://developer.mozilla.org/en-US/docs/Web/CSS/color_value).
 * Default is no value, indicating that no point will be shown.
 * @property {number|Function} point.radius - The radius of the point, in pixel. Default
 * is `2.0`.
 * @property {string|Function} point.line - The color of the border of the point. Can be
 * any [valid color
 * string](https://developer.mozilla.org/en-US/docs/Web/CSS/color_value).
 * Not supported for `GeometryLayer`.
 * @property {number|Function} point.width - The width of the border, in pixel. Default
 * is `0.0` (no border).
 * @property {number|Function} point.opacity - The opacity of the point. Can be between
 * `0.0` and `1.0`. Default is `1.0`.
 * Not supported for `GeometryLayer`.
 * @property {number|Function} point.base_altitude - Only for {@link GeometryLayer}, defines altitude
 * for each coordinate.
 * If `base_altitude` is `undefined`, the original altitude is kept, and if it doesn't exist
 * then the altitude value is set to 0.
 *
 * @property {object} model - To instanciate a unique 3D model at different point positions
 * @property {THREE.Object3D} model.object - The 3D model object to instantiate at each position
 * @property {object|Function} model.size - The wanted size of the instanced model in local dimension.
 * Should be (or returning) an object containing 3 properties: x, y and z.
 * @property {number|Function} model.heading - The heading (or azimuth) to orient the model in degree.
 * @property {number|Function} model.scale - The value to scale the model. (default value is 1).
 * @property {THREE.Vector3|Function} model.up - The vector pointing up. (default value is Vector3(0, 0, 1)).
 * @property {THREE.Vector3|Function} model.front - The vector pointing toward the front of the model. It
 * should be orthogonal to the 'up' vector. (default value is Vector3(0, 1, 0)).
 *
 * @property {object} text - All things {@link Label} related.
 * @property {string|Function} text.field - A string representing a property key of
 * a `FeatureGeometry` enclosed in brackets, that will be replaced by the value of the
 * property for each geometry. For example, if each geometry contains a `name` property,
 * `text.field` can be set to `{name}`. Default is no value, indicating that no
 * text will be displayed.
 *
 * It's also possible to create more complex expressions. For example, you can combine
 * text that will always be displayed (e.g. `foo`) and variable properties (e.g. `{bar}`)
 * like the following: `foo {bar}`. You can also use multiple variables in one field.
 * Let's say for instance that you have two properties latin name and local name of a
 * place, you can write something like `{name_latin} - {name_local}` which can result
 * in `Marrakesh - مراكش` for example.
 * @property {string|Function} text.color - The color of the text. Can be any [valid
 * color string](https://developer.mozilla.org/en-US/docs/Web/CSS/color_value).
 * Default is `#000000`.
 * @property {string|number[]|Function} text.anchor - The anchor of the text relative to its
 * position (see {@link Label} for the position). Can be one of the following values: `top`,
 * `left`, `bottom`, `right`, `center`, `top-left`, `top-right`, `bottom-left`
 * or `bottom-right`. Default is `center`.
 *
 * It can also be defined as an Array of two numbers. Each number defines an offset (in
 * fraction of the label width and height) between the label position and the top-left
 * corner of the text. The first value is the horizontal offset, and the second is the
 * vertical offset. For example, `[-0.5, -0.5]` will be equivalent to `center`.
 * @property {Array|Function} text.offset - The offset of the text, depending on its
 * anchor, in pixels. First value is from `left`, second is from `top`. Default
 * is `[0, 0]`.
 * @property {number|Function} text.padding - The padding outside the text, in pixels.
 * Default is `2`.
 * @property {number|Function} text.size - The size of the font, in pixels. Default is
 * `16`.
 * @property {number|Function} text.wrap - The maximum width, in pixels, before the text
 * is wrapped, because the string is too long. Default is `10`.
 * @property {number|Function} text.spacing - The spacing between the letters, in `em`.
 * Default is `0`.
 * @property {string|Function} text.transform - A value corresponding to the [CSS
 * property
 * `text-transform`](https://developer.mozilla.org/en-US/docs/Web/CSS/text-transform).
 * Default is `none`.
 * @property {string|Function} text.justify - A value corresponding to the [CSS property
 * `text-align`](https://developer.mozilla.org/en-US/docs/Web/CSS/text-align).
 * Default is `center`.
 * @property {number|Function} text.opacity - The opacity of the text. Can be between
 * `0.0` and `1.0`. Default is `1.0`.
 * @property {Array|Function} text.font - A list (as an array of string) of font family
 * names, prioritized in the order it is set. Default is `Open Sans Regular,
 * Arial Unicode MS Regular, sans-serif`.
 * @property {string|Function} text.haloColor - The color of the halo. Can be any [valid
 * color string](https://developer.mozilla.org/en-US/docs/Web/CSS/color_value).
 * Default is `#000000`.
 * @property {number|Function} text.haloWidth - The width of the halo, in pixels.
 * Default is `0`.
 * @property {number|Function} text.haloBlur - The blur value of the halo, in pixels.
 * Default is `0`.
 *
 * @property {object} icon - Defines the appearance of icons attached to label.
 * @property {string} icon.source - The url of the icons' image file.
 * @property {string} icon.id - The id of the icons' sub-image in a vector tile data set.
 * @property {string} icon.cropValues - the x, y, width and height (in pixel) of the sub image to use.
 * @property {string} icon.anchor - The anchor of the icon compared to the label position.
 * Can be `left`, `bottom`, `right`, `center`, `top-left`, `top-right`, `bottom-left`
 * or `bottom-right`. Default is `center`.
 * @property {number} icon.size - If the icon's image is passed with `icon.source` and/or
 * `icon.id`, its size when displayed on screen is multiplied by `icon.size`. Default is `1`.
 * @property {string|Function} icon.color - The color of the icon. Can be any [valid
 * color string](https://developer.mozilla.org/en-US/docs/Web/CSS/color_value).
 * It will change the color of the white pixels of the icon source image.
 * @property {number|Function} icon.opacity - The opacity of the icon. Can be between
 * `0.0` and `1.0`. Default is `1.0`.
 *
 * @example
 * const style = new itowns.Style({
 *      stroke: { color: 'red' },
 *      point: { color: 'white', line: 'red' },
 * });
 *
 * const source = new itowns.FileSource(...);
 *
 * const layer = new itowns.ColorLayer('foo', {
 *      source: source,
 *      style: style,
 * });
 *
 * view.addLayer(layer);
 *
 * @example <caption>Updating style properties. Currently only works for FeatureGeometryLayer and color and extrusionHeight properties.</caption>
 * // Update a single sub-property:
 * layer.style.fill.color = '#00cc00';
 *
 * // Update several sub-properties at once via the category setter.
 * // Only the provided keys are changed; other properties are kept intact.
 * layer.style.fill = { color: '#00cc00', opacity: 0.8 };
 *
 * // WARNING: do NOT use the spread operator to "copy" the current category:
 * //   layer.style.fill = { ...layer.style.fill, color: '#00cc00' };
 * // The spread evaluates every getter immediately, which executes dynamic
 * // properties (functions, expressions) without a feature context and will
 * // either crash or freeze their values.
 */
declare class Style extends EventDispatcher<any> {
    /**
     * @param {StyleOptions} [params={}] An object that contain any properties
     * (zoom, fill, stroke, point, text or/and icon)
     * and sub properties of a Style ({@link StyleOptions}).
     */
    constructor(params?: StyleOptions);
    isStyle: boolean;
    context: StyleContext;
    /**
     * Defines a category-level property with a setter that delegates to
     * individual sub-property setters.
     * This allows users to do e.g. `style.fill = { color: 'red' }` and have
     * only the specified sub-properties updated (and their change events
     * dispatched), while leaving the other sub-properties untouched.
     * @param {string} category - The category name (fill, stroke, point, text, icon, zoom).
     * @returns {object} The category object.
     * @private
     */
    private _defineCategoryProperty;
    /**
     * @param {object} params - Zoom style parameters.
       @private */
    private _initZoom;
    /**
     * @param {object} params - Fill style parameters.
       @private */
    private _initFill;
    _levelledRoofs: any;
    _extrusionHeight: any;
    /**
     * @param {object} params - Stroke style parameters.
       @private */
    private _initStroke;
    _extrusionRadius: any;
    /**
     * @param {object} params - Point style parameters.
       @private */
    private _initPoint;
    /**
     * @param {object} params - 3D model style parameters.
       @private */
    private _initModel;
    /**
     * @param {object} params - Text style parameters.
       @private */
    private _initText;
    /**
     * @param {object} params - Icon style parameters.
       @private */
    private _initIcon;
    setContext(ctx: any): void;
    /**
     * Applies the style.fill to a polygon of the texture canvas.
     * @param {CanvasRenderingContext2D} txtrCtx The Context 2D of the texture canvas.
     * @param {Path2D} polygon The current texture canvas polygon.
     * @param {number} invCtxScale The ratio to scale line width and radius circle.
     * @param {boolean} canBeFilled - true if feature.type == FEATURE_TYPES.POLYGON.
     */
    applyToCanvasPolygon(txtrCtx: CanvasRenderingContext2D, polygon: Path2D, invCtxScale: number, canBeFilled: boolean): void;
    _applyStrokeToPolygon(txtrCtx: any, invCtxScale: any, polygon: any): void;
    _applyFillToPolygon(txtrCtx: any, invCtxScale: any, polygon: any): Promise<void>;
    /**
     * Applies this style to a DOM element. Limited to the `text` and `icon`
     * properties of this style.
     *
     * @param {Element} domElement - The element to set the style to.
     *
     * @returns {undefined|Promise<HTMLImageElement>}
     *          for a text label: undefined.
     *          for an icon: a Promise resolving with the HTMLImageElement containing the image.
     */
    applyToHTML(domElement: Element, ...args: any[]): undefined | Promise<HTMLImageElement>;
    /**
     * Gets the values corresponding to the anchor of the text. It is
     * proportions, to use with a `translate()` and a `transform` property.
     *
     * @returns {number[]} Two percentage values, for x and y respectively.
     */
    getTextAnchorPosition(): number[];
    /**
     * Checks if the style has an extrusion height defined.
     * @returns {boolean} True if extrusion is enabled, false otherwise.
     */
    isExtruded(): boolean;
}
import { EventDispatcher } from 'three';
