import type PotreeSource from '../Source/PotreeSource';
import { PotreeNodeBase } from '../Core/PotreeNodeBase';
export interface PotreeNodeHierarchy {
    hierarchyKey: string;
    numPoints: number;
}
declare class PotreeNode extends PotreeNodeBase {
    source: PotreeSource;
    url: string;
    hierarchy: Record<string, PotreeNodeHierarchy>;
    voxelKey: string;
    private baseurl;
    hierarchyKey: string;
    constructor(depth: number, x: number, y: number, z: number, source: PotreeSource, hierarchy?: Record<string, PotreeNodeHierarchy>);
    get networkOptions(): RequestInit;
    fetcher(url: string, networkOptions?: RequestInit): Promise<ArrayBuffer>;
    loadHierarchy(): Promise<Record<string, PotreeNodeHierarchy>>;
    findAndCreateChild(depth: number, x: number, y: number, z: number): void;
}
export default PotreeNode;
