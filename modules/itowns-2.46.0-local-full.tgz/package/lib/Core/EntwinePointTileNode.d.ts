import type EntwinePointTileSource from '../Source/EntwinePointTileSource';
import LasNodeBase from '../Core/LasNodeBase';
declare class EntwinePointTileNode extends LasNodeBase {
    source: EntwinePointTileSource;
    url: string;
    hierarchy: Record<string, number>;
    /**
     * The string id of the node, constituted of the four components:
     * `depth-x-y-z`.
     */
    voxelKey: string;
    /**
     * Constructs a new instance of EntwinePointTileNode.
     *
     * @param depth - The depth of the node in the tree - see the
     * [Entwine documentation](https://entwine.io/entwine-point-tile.html#ept-data)
     * @param x - The x coordinate of the node in the tree - see the
     * [Entwine documentation](https://entwine.io/entwine-point-tile.html#ept-data)
     * @param y - The y coordinate of the node in the tree - see the
     * [Entwine documentation](https://entwine.io/entwine-point-tile.html#ept-data)
     * @param z - The z coordinate of the node in the tree - see the
     * [Entwine documentation](https://entwine.io/entwine-point-tile.html#ept-data)
     * @param source - Data source (Ept) of the node.
     * @param hierarchy
     */
    constructor(depth: number, x: number, y: number, z: number, source: EntwinePointTileSource, hierarchy?: Record<string, number>);
    fetcher(url: string, networkOptions: RequestInit): Promise<ArrayBuffer>;
    loadHierarchy(): Promise<Record<string, number>>;
    findAndCreateChild(depth: number, x: number, y: number, z: number): void;
}
export default EntwinePointTileNode;
