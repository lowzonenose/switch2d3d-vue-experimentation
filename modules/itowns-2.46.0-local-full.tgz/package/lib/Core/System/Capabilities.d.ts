declare namespace _default {
    function isLogDepthBufferSupported(): boolean;
    function getMaxTextureUnitsCount(): number;
    function getMaxTextureSize(): number;
    function isFloatTextureLinearFilteringSupported(): boolean;
    function updateCapabilities(renderer: any): void;
}
export default _default;
