import PointCloudNode from '../Core/PointCloudNode';
export interface NodeKeyInfo {
    depth: number;
    x: number;
    y: number;
    z: number;
}
export declare function getChildVoxelKey(nodeInfo: NodeKeyInfo, childIndex: number): {
    depth: number;
    x: number;
    y: number;
    z: number;
};
export declare abstract class PotreeNodeBase extends PointCloudNode {
    /** X position within the octree */
    x: number;
    /** Y position within the octree */
    y: number;
    /** Z position within the octree */
    z: number;
    constructor(depth: number, x: number, y: number, z: number, numPoints: number);
    fetcher(url: string, networkOptions?: RequestInit): Promise<ArrayBuffer>;
}
export default PotreeNodeBase;
