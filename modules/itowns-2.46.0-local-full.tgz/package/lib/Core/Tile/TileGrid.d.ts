import * as THREE from 'three';
import { Extent } from '@itowns/geographic';
export declare const globalDefaultExtentCRS: string[];
export declare const globalExtentTMS: Map<string, Extent>;
export declare const schemeTiles: Map<string, THREE.Vector2>;
export declare function getInfoTms(crs: string): {
    epsg: string;
    globalExtent: Extent;
    globalDimension: THREE.Vector2;
    sTs: THREE.Vector2;
    isInverted: boolean;
};
export declare function getCountTiles(crs: string, zoom: number): THREE.Vector2;
