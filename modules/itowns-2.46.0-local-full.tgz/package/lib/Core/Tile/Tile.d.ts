import * as THREE from 'three';
import { Extent } from '@itowns/geographic';
declare class Tile {
    readonly isTile: true;
    crs: string;
    zoom: number;
    row: number;
    col: number;
    /**
     * A tile is a geographical bounding rectangle uniquely defined by its zoom,
     * row and column.
     *
     * @param crs - projection of limit values.
     * @param zoom - `zoom` value. Default is 0.
     * @param row - `row` value. Default is 0.
     * @param col - `column` value. Default is 0.
     */
    constructor(crs: string, zoom?: number, row?: number, col?: number);
    /**
     * Returns a new tile with the same bounds and crs as this one.
     * @returns
     */
    clone(): Tile;
    /**
     * Converts this tile to the specified extent.
     * @param crs - target's projection.
     * @param target - The target to store the projected extent. If this not
     * provided a new extent will be created.
     * @returns
     */
    toExtent(crs?: string, target?: Extent): Extent;
    /**
     * Checks whether another tile is inside this tile.
     *
     * @param tile - the tile to check.
     * @returns
     */
    isInside(tile: Tile): boolean;
    /**
     * Returns the translation and scale to transform this tile to the input
     * tile.
     *
     * @param tile - the input tile.
     * @param target - copy the result to target.
     * @returns
     */
    offsetToParent(tile: Tile, target?: THREE.Vector4): THREE.Vector4;
    /**
     * Returns the parent tile at the given level.
     *
     * @param levelParent - the level of the parent tile.
     * @returns
     */
    tiledExtentParent(levelParent: number): Tile;
    /**
     * Sets zoom, row and column values.
     *
     * @param zoom - zoom value.
     * @param row - row value.
     * @param col - column value.
     * @returns
     */
    set(zoom?: number, row?: number, col?: number): this;
    /**
     * Copies the passed tile to this tile.
     * @param tile - tile to copy.
     * @returns
     */
    copy(tile: Tile): this;
    /**
     * Return values of tile in string, separated by the separator input.
     * @param separator - string separator
     * @returns
     */
    toString(separator?: string): string;
}
export declare function tiledCovering(e: Extent, tms: string): Tile[];
/**
 * Represents a set of limits for a Tile Matrix Set (TMS).
 */
interface TileLimit {
    /** Minimum tile (top-left in the matrix) */
    min: Tile;
    /** Maximum tile (bottom-right in the matrix) */
    max: Tile;
    /** Geographic extent covered by the tile range */
    extent: Extent;
}
interface TileLimitJson {
    maxTileRow: number;
    minTileRow: number;
    minTileCol: number;
    maxTileCol: number;
}
/**
 * Represents a set of limits for a Tile Matrix Set (TMS).
 *
 * This class stores tile boundaries per zoom level, along with
 * global extent information and intersection constraints.
 */
export declare class TileMatrixSetLimits {
    /**
     * Tile limits indexed by zoom level.
     * Each entry defines the min/max tiles and their corresponding extent.
     */
    limits: Record<number, TileLimit>;
    /** Coordinate reference system (CRS) of the tile matrix set */
    crs: string;
    /** Global extent (union) of all tile limits */
    extent: Extent;
    /** Common intersection extent across all tile limits */
    intersect: Extent;
    /** Zoom level range covered by the limits */
    zoom: {
        min: number;
        max: number;
    };
    /**
     * Creates a new TileMatrixSetLimits instance.
     *
     * @param crs - The coordinate reference system of the tile matrix set.
     */
    constructor(crs: string);
    /**
     * Builds a TileMatrixSetLimits instance from capabilities JSON.
     *
     * The input JSON is expected to contain tile limits per zoom level.
     * Each zoom level entry must define min/max tile rows and columns.
     *
     * @param json - Capabilities object describing tile matrix limits.
     * @param crs - The coordinate reference system.
     *
     * @returns A populated TileMatrixSetLimits instance.
     */
    static fromCapabilities(json: Record<number, TileLimitJson>, crs: string): TileMatrixSetLimits;
    /**
     * Tests whether a tile or extent is inside the defined limits.
     * If there are no limits at this zoom level,
     * the tile is always considered as inside
     *
     * - If a {@link Tile} is provided, checks whether it falls within the
     *   min/max bounds for its zoom level.
     * - If an {@link Extent} is provided, checks whether it intersects
     *   the common intersection extent of all limits.
     *
     * @param extentOrTile - The tile or extent to test.
     *
     * @returns `true` if inside the limits, `false` otherwise.
     */
    isInside(extentOrTile: Tile | Extent): boolean;
}
export default Tile;
