export default C3DTilesIonSource;
/**
 * An object defining the source connection to a 3DTiles asset of a [Cesium ion server](https://cesium.com/learn/ion/).
 *
 * @extends Source
 *
 * @property {boolean} isC3DTilesIonSource - Used to checkout whether this source is a C3DTilesIonSource. Default is
 * true. You should not change this, as it is used internally for optimisation.
 * @property {string} url - The URL of the tileset json.
 * @property {string} baseUrl - The base URL to access tiles.
 * @property {string} accessToken - The Cesium ion access token used to retrieve the resource.
 * @property {string} assetId - The id of the asset on Cesium ion.
 */
declare class C3DTilesIonSource {
    /**
     * Create a new Source for 3D Tiles data from Cesium ion.
     *
     * @extends Source
     *
     * @param {object} source An object that can contain all properties of a C3DTilesIonSource and {@link Source}.
     * Only `accessToken` and `assetId` are mandatory.
     */
    constructor(source: object);
    isC3DTilesIonSource: boolean;
    accessToken: any;
    assetId: any;
    whenReady: Promise<object>;
    url: any;
    baseUrl: any;
    attribution: any;
}
