import Source from '../Source/Source';
import { Potree2PointAttributes } from '../Core/Potree2PointAttributes';
interface Potree2Attribute {
    name: string;
    description: string;
    size: number;
    numElements: number;
    elementSize: number;
    type: keyof typeof typeNameAttributeMap;
    min: number[];
    max: number[];
}
interface Potree2Metadata {
    version: string;
    name: string;
    description: string;
    points: number;
    projection: string;
    hierarchy: {
        firstChunkSize: number;
        stepSize: number;
        depth: number;
    };
    offset: [number, number, number];
    scale: [number, number, number];
    spacing: number;
    boundingBox: {
        min: [number, number, number];
        max: [number, number, number];
    };
    encoding: 'BROTLI' | 'DEFAULT';
    attributes: Potree2Attribute[];
}
interface Potree2SourceParameters {
    /**
     * URL of the metadata.json file, or base URL of the pointcloud if `file` is
     * provided (deprecated).
     */
    url: string;
    /**
     * @deprecated Use `url` parameter with the full URL to the
     * metadata.json file instead.
     */
    file?: string;
    crs: string;
    metadata?: Potree2Metadata;
    networkOptions?: RequestInit;
}
declare const typeNameAttributeMap: {
    readonly double: {
        name: string;
        size: number;
    };
    readonly float: {
        name: string;
        size: number;
    };
    readonly int8: {
        name: string;
        size: number;
    };
    readonly uint8: {
        name: string;
        size: number;
    };
    readonly int16: {
        name: string;
        size: number;
    };
    readonly uint16: {
        name: string;
        size: number;
    };
    readonly int32: {
        name: string;
        size: number;
    };
    readonly uint32: {
        name: string;
        size: number;
    };
    readonly int64: {
        name: string;
        size: number;
    };
    readonly uint64: {
        name: string;
        size: number;
    };
};
/**
 * Potree2Source are object containing informations on how to fetch
 * potree 2.0 points cloud resources.
 */
declare class Potree2Source extends Source {
    extension: 'bin';
    baseurl: string;
    boundsConforming: [number, number, number, number, number, number];
    bounds: [number, number, number, number, number, number];
    metadata: Potree2Metadata;
    pointAttributes: Potree2PointAttributes;
    zmin: number;
    zmax: number;
    spacing: number;
    /**
     * @param source - An object that can contain all properties of a
     * Potree2Source
     *
     * This `metadata` file stores information about the potree cloud 2.0
     * in JSON format.
     * The structure is :
     * - __`version`__ - The metadata.json format may change over time.
     * The version number is necessary so that parsers know how to interpret
     * the data.
     * - __`name`__ - Point cloud name.
     * - __`description`__ - Point cloud description.
     * - __`points`__ - Total number of points.
     * - __`projection`__ - Point cloud geographic projection system.
     * - __`hierarchy`__ - Information about point cloud hierarchy
     *          (first chunk size, step size, octree depth).
     * - __`offset`__ - Position offset used to determine the global
     *          point position.
     * - __`scale`__ - Point cloud scale.
     * - __`spacing`__ - The minimum distance between points at root level.
     * - __`boundingBox`__ - Contains the minimum and maximum of the axis
     *          aligned bounding box. This bounding box is cubic and aligned
     *          to fit to the octree root.
     * - __`encoding`__ - Encoding type: BROTLI or DEFAULT (uncompressed).
     * - __`attributes`__ - Array of attributes (position,  intensity,
     *          return number, number of returns, classification,
     *          scan angle rank, user data, point source id, gps-time, rgb).
     * ```
     * {
     *     version: '2.0',
     *     name: "sample",
     *     description: "",
     *     points: 534909153,
     *     projection: "",
     *     hierarchy: {
     *         firstChunkSize: 1276,
     *         stepSize: 4,
     *         depth: 16
     *     },
     *     offset: [1339072.07, 7238866.339, 85.281],
     *     scale: [0.001, 0.001, 0.002],
     *     spacing: 24.476062500005355,
     *     boundingBox: {
     *         min: [1339072.07, 7238866.339, 85.281],
     *         max: [1342205.0060000008, 7241999.275, 3218.2170000006854]
     *     },
     *     encoding: "BROTLI",
     *     attributes: [
     *          {
     *              name: "position",
     *              description: "",
     *              size: 12,
     *              numElements: 3,
     *              elementSize: 4,
     *              type: "int32",
     *              min: [-0.74821299314498, -2.7804059982299, 2.5478212833404],
     *              max: [2.4514148223438, 1.4893437627414, 7.1957106576508]
     *          },
     *          {
     *              name: "intensity",
     *              description: "",
     *              size: 2,
     *              numElements: 1,
     *              elementSize: 2,
     *              type: "uint16",
     *              min: [0],
     *              max: [0]
     *          },{
     *              name: "return number",
     *              description: "",
     *              size: 1,
     *              numElements: 1,
     *              elementSize: 1,
     *              type: "uint8",
     *              min: [0],
     *              max: [0]
     *          },{
     *              name: "number of returns",
     *              description: "",
     *              size: 1,
     *              numElements: 1,
     *              elementSize: 1,
     *              type: "uint8",
     *              min: [0],
     *              max: [0]
     *          },{
     *              name: "classification",
     *              description: "",
     *              size: 1,
     *              numElements: 1,
     *              elementSize: 1,
     *              type: "uint8",
     *              min: [0],
     *              max: [0]
     *          },{
     *              name: "scan angle rank",
     *              description: "",
     *              size: 1,
     *              numElements: 1,
     *              elementSize: 1,
     *              type: "uint8",
     *              min: [0],
     *              max: [0]
     *          },{
     *              name: "user data",
     *              description: "",
     *              size: 1,
     *              numElements: 1,
     *              elementSize: 1,
     *              type: "uint8",
     *              min: [0],
     *              max: [0]
     *          },{
     *              name: "point source id",
     *              description: "",
     *              size: 2,
     *              numElements: 1,
     *              elementSize: 2,
     *              type: "uint16",
     *              min: [0],
     *              max: [0]
     *          },{
     *              name: "gps-time",
     *              description: "",
     *              size: 8,
     *              numElements: 1,
     *              elementSize: 8,
     *              type: "double",
     *              min: [0],
     *              max: [0]
     *          },{
     *              name: "rgb",
     *              description: "",
     *              size: 6,
     *              numElements: 3,
     *              elementSize: 2,
     *              type: "uint16",
     *              min: [5632, 5376, 4864],
     *              max: [65280, 65280, 65280]
     *          }
     *     ]
     * }
     * ```
     */
    constructor(source: Potree2SourceParameters);
}
export default Potree2Source;
