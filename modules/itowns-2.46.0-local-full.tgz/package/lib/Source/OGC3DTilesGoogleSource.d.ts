export default OGC3DTilesGoogleSource;
declare class OGC3DTilesGoogleSource extends OGC3DTilesSource {
    /**
     * An object defining the source connection to a 3D Tiles asset from [Google Tiles API](https://tile.googleapis.com).
     *
     * @extends OGC3DTilesSource
     *
     * @property {boolean} isOGC3DTilesGoogleSource - Used to check if this source is an OGC3DTilesGoogleSource. Set to true.
     * You should not change this, as it is used internally for optimisation.
     * @property {string} url - The URL to the tileset json.
     * @property {string} baseUrl - The base URL to access tiles.
     * @param {object} source An object that can contain all properties of an OGC3DTilesGoogleSource and {@link Source}.
     * @param {string} source.key Your google tiles map API access key
     */
    constructor(source: {
        key: string;
    });
    isOGC3DTilesGoogleSource: boolean;
    key: string;
}
import OGC3DTilesSource from './OGC3DTilesSource';
