/** @private */
export const supportedParsers: Map<string, (json: string, options?: ParsingOptions) => Promise<any>>;
export default Source;
/**
 * This interface describes parsing options.
 */
export type ParsingOptions = {
    /**
     * - data informations contained in the file.
     */
    in: Source;
    /**
     * - options indicates how the features should be built.
     */
    out: FeatureBuildingOptions | Layer;
};
/**
 * Sources are object containing informations on how to fetch resources, from a
 * set source.
 *
 * To extend a Source, it is necessary to implement two functions:
 * `urlFromExtent` and `extentInsideLimit`.
 *
 * @property {boolean} isSource - Used to checkout whether this source is a
 * Source. Default is true. You should not change this, as it is used internally
 * for optimisation.
 * @property {number} uid - Unique uid mainly used to store data linked to this
 * source into Cache.
 * @property {string} url - The url of the resources that are fetched.
 * @property {string} format - The format of the resources that are fetched.
 * @property {Function} fetcher - The method used to fetch the resources from
 * the source. iTowns provides some methods in {@link Fetcher}, but it can be
 * specified a custom one. This method should return a `Promise` containing the
 * fetched resource. If this property is set, it overrides the chosen fetcher
 * method with `format`.
 * @property {object} networkOptions - Fetch options (passed directly to
 * `fetch()`), see [the syntax for more information](
 * https://developer.mozilla.org/en-US/docs/Web/API/WindowOrWorkerGlobalScope/fetch#Syntax).
 * By default, set to `{ crossOrigin: 'anonymous' }`.
 * @property {string} crs - The crs projection of the resources.
 * @property {string} attribution - The intellectual property rights for the
 * resources.
 * @property {Extent} extent - The extent of the resources.
 * @property {Function} parser - The method used to parse the resources attached
 * to the layer. iTowns provides some parsers, visible in the `Parser/` folder.
 * If the method is custom, it should return a `Promise` containing the parsed
 * resource. If this property is set, it overrides the default selected parser
 * method with `source.format`. If `source.format` is also empty, no parsing
 * action is done.
 * <br><br>
 * When calling this method, two parameters are passed:
 * <ul>
 *  <li>the fetched data, i.e. the data to parse</li>
 *  <li>an {@link ParsingOptions}  containing severals properties, set when this method is
 *  called: it is specific to each call, so the value of each property can vary
 *  depending on the current fetched tile for example</li>
 * </ul>
 */
declare class Source {
    /**
     * @param {object} source - An object that can contain all properties of a
     * Source. Only the `url` property is mandatory.
     */
    constructor(source: object);
    crs: any;
    isSource: boolean;
    uid: number;
    zoom: {
        min: any;
        max: any;
    };
    url: any;
    format: any;
    fetcher: any;
    parser: any;
    isVectorSource: boolean;
    networkOptions: any;
    attribution: any;
    /** @type {Promise<any>} */
    whenReady: Promise<any>;
    _featuresCaches: {};
    extent: any;
    handlingError(err: any): void;
    /**
     * Generates an url from an extent. This url is a link to fetch the
     * resources inside the extent.
     *
     * @param {Extent} extent - Extent to convert in url.
     * @returns {string} The URL constructed from the extent.
     */
    urlFromExtent(extent: Extent): string;
    getDataKey(extent: any): string;
    /**
     * Load  data from cache or Fetch/Parse data.
     * The loaded data is a Feature or Texture.
     *
     * @param      {Extent}  extent   extent requested parsed data.
     * @param      {FeatureBuildingOptions|Layer}  out     The feature returned options
     * @returns     {FeatureCollection|Texture}  The parsed data.
     */
    loadData(extent: Extent, out: FeatureBuildingOptions | Layer): FeatureCollection | Texture;
    /**
     * Called when layer added.
     *
     * @param {object} options
     */
    onLayerAdded(options: object): void;
    /**
     * Called when layer removed.
     *
     * @param {options}  [options={}] options
     */
    onLayerRemoved(options?: any): void;
    /**
     * Determines whether this source has data intersecting the given extent.
     *
     * If the source has no defined extent, it is assumed to cover all areas and
     * this method always returns `true`. Otherwise, the source's extent is
     * tested for intersection with the provided extent.
     *
     * @param {Extent|Tile} extentOrTile - The extent or tile to test against.
     *
     * @returns {boolean} `true` if the source has data for the
     * given extent, `false` otherwise.
     */
    hasData(extentOrTile: Extent | Tile): boolean;
}
import { Extent } from '@itowns/geographic';
