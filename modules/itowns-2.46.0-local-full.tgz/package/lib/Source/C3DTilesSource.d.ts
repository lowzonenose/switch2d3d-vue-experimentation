export default C3DTilesSource;
/**
 * An object defining the source connection to a 3DTiles dataset from a web server.
 *
 * @extends Source
 *
 * @property {boolean} isC3DTilesSource - Used to checkout whether this source is a isC3DTilesSource. Default is
 * true. You should not change this, as it is used internally for optimisation.
 * @property {string} url - The URL of the tileset json.
 * @property {string} baseUrl - The base URL to access tiles.
 */
declare class C3DTilesSource extends Source {
    isC3DTilesSource: boolean;
    baseUrl: any;
    whenReady: Promise<object>;
}
import Source from '../Source/Source';
