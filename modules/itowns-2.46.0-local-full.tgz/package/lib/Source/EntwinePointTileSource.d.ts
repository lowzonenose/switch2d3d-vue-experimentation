import Source from '../Source/Source';
/**
 * @param colorDepth - Color depth (in bits).
 * Either 8 or 16 bits. By defaults it will be set to 8 bits for LAS 1.2 and
 * 16 bits for later versions (as mandatory by the specification).
 */
interface EntwinePointTileSourceParameters {
    /**
     * The URL of the directory containing the whole Entwine Point Tile
     * structure.
     */
    url: string;
    crs: string;
    colorDepth: number;
    networkOptions?: RequestInit;
}
/**
 * An object defining the source of Entwine Point Tile data. It fetches and
 * parses the main configuration file of Entwine Point Tile format,
 * [`ept.json`](https://entwine.io/entwine-point-tile.html#ept-json).
 */
declare class EntwinePointTileSource extends Source {
    /**
     * Used to checkout whether this source is a EntwinePointTileSource.
     * Default is true. You should not change this,
     * as it is used internally for optimisation.
     */
    readonly isEntwinePointTileSource: true;
    colorDepth: number;
    boundsConforming: [number, number, number, number, number, number];
    bounds: [number, number, number, number, number, number];
    span: number;
    zmin: number;
    zmax: number;
    spacing: number;
    extension: 'laz' | 'bin';
    /**
     * @param config - The configuration, see {@link Source} for
     * available values.
     */
    constructor(config: EntwinePointTileSourceParameters);
}
export default EntwinePointTileSource;
