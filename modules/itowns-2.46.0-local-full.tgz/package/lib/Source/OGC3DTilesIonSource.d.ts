export default OGC3DTilesIonSource;
declare class OGC3DTilesIonSource extends OGC3DTilesSource {
    /**
     * An object defining the source connection to a 3DTiles asset of a [Cesium ion server](https://cesium.com/learn/ion/).
     *
     * @extends Source
     *
     * @property {boolean} isOGC3DTilesIonSource - Used to check if this source is an OGC3DTilesIonSource. Set to true.
     * You should not change this, as it is used internally for optimisation.
     * @property {string} accessToken - The Cesium ion access token used to retrieve the resource.
     * @property {string} assetId - The id of the asset on Cesium ion.
     *
     * @param {object} source An object that can contain all properties of an OGC3DTilesIonSource and {@link Source}.
     * Only `accessToken` and `assetId` are mandatory.
     * @param {string} source.accessToken - The Cesium ion access token used to retrieve the resource.
     * @param {string} source.assetId - The id of the asset on Cesium ion.
     */
    constructor(source: {
        accessToken: string;
        assetId: string;
    });
    isOGC3DTilesIonSource: boolean;
    accessToken: string;
    assetId: string;
}
import OGC3DTilesSource from './OGC3DTilesSource';
