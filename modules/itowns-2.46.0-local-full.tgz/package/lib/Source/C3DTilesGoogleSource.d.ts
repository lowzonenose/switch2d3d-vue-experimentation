export default C3DTilesGoogleSource;
/**
 * An object defining the source connection to a 3DTiles asset from a [Google api](https://tile.googleapis.com).
 *
 * @extends C3DTilesSource
 *
 * @property {boolean} isC3DTilesGoogleSource - Used to checkout whether this source is a C3DTilesGoogleSource. Default is
 * true. You should not change this, as it is used internally for optimisation.
 * @property {string} url - The URL to the tileset json.
 * @property {string} baseUrl - The base URL to access tiles.
 */
declare class C3DTilesGoogleSource extends C3DTilesSource {
    /**
     * Create a new Source for 3D Tiles data from Google api (experimental).
     *
     * @extends C3DTilesSource
     *
     * @property {boolean} isC3DTilesGoogleSource - Used to checkout whether this source is a C3DTilesGoogleSource. Default is
     * true. You should not change this, as it is used internally for optimisation.
     * @param {object} source An object that can contain all properties of a C3DTilesGoogleSource and {@link Source}.
     * @param {string} source.key Your google tiles map API access key
     */
    constructor(source: {
        key: string;
    });
    isC3DTilesGoogleSource: boolean;
    baseUrl: string;
    key: string;
    sessionId: any;
    /**
     * Adds the key and session to the tile url (non-standard behaviour, that is specific to Google 3D tiles),
     * see https://github.com/CesiumGS/3d-tiles/issues/746
     * @param {string} url the tile url
     * @returns {string} the tile url with Google map tiles api key and session parameters added at the end of the url
     */
    getTileUrl(url: string): string;
}
import C3DTilesSource from './C3DTilesSource';
