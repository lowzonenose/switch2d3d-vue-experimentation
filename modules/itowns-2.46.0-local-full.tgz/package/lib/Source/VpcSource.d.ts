export default VpcSource;
/**
 * An object defining the source of Entwine Point Tile data. It fetches and
 * parses the main configuration file of Entwine Point Tile format,
 * [`ept.json`](https://entwine.io/entwine-point-tile.html#ept-json).
 *
 * @extends Source
 *
 * @property {boolean} isEntwinePointTileSource - Used to checkout whether this
 * source is a EntwinePointTileSource. Default is true. You should not change
 * this, as it is used internally for optimisation.
 * @property {string} url - The URL of the directory containing the whole
 * Entwine Point Tile structure.
 * @property {object[] | PointCloudSource[]} sources - Array of all the source described in the VPC.
 * initialized with mockSource that will be replace by COPC or EPT Source as soon as any data need
 * to be loaded.
 */
declare class VpcSource extends Source {
    /**
     * @param {object} config - The configuration, see {@link Source} for
     * available values.
     * @param {number} [config.colorDepth] - Color depth (in bits).
     * Either 8 or 16 bits. By defaults it will be set to 8 bits for LAS 1.2 and
     * 16 bits for later versions (as mandatory by the specification).
     */
    constructor(config: {
        colorDepth?: number | undefined;
    });
    isVpcSource: boolean;
    sources: any[];
    colorDepth: number | undefined;
    spacing: number;
    whenReady: Promise<this>;
    metadata: object;
    boundsConforming: number[];
    zmin: number;
    zmax: number;
    _promises: any[];
    urls: any;
}
import Source from '../Source/Source';
