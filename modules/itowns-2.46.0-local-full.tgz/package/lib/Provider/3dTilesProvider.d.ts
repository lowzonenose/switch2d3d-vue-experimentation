export function configureTile(tile: any, layer: any, metadata: any, parent: any): void;
declare namespace _default {
    export { executeCommand };
}
export default _default;
declare function executeCommand(command: any): Promise<THREE.Object3D<THREE.Object3DEventMap>>;
import * as THREE from 'three';
