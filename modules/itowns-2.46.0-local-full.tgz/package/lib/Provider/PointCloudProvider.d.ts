declare namespace _default {
    function executeCommand(command: any): any;
}
export default _default;
