export const TEXTURE_TILE_DIM: 256;
declare namespace _default {
    /**
     * Wrapper over fetch to get some text.
     *
     * @param {string} url - The URL of the resources to fetch.
     * @param {object} options - Fetch options (passed directly to `fetch()`),
     * see [the syntax for more information](
     * https://developer.mozilla.org/en-US/docs/Web/API/WindowOrWorkerGlobalScope/fetch#Syntax).
     *
     * @returns {Promise<string>} Promise containing the text.
     */
    export function text(url: string, options?: object): Promise<string>;
    /**
     * Little wrapper over fetch to get some JSON.
     *
     * @param {string} url - The URL of the resources to fetch.
     * @param {object} options - Fetch options (passed directly to `fetch()`),
     * see [the syntax for more information](
     * https://developer.mozilla.org/en-US/docs/Web/API/WindowOrWorkerGlobalScope/fetch#Syntax).
     *
     * @returns {Promise<object>} Promise containing the JSON object.
     */
    export function json(url: string, options?: object): Promise<object>;
    /**
     * Wrapper over fetch to get some XML.
     *
     * @param {string} url - The URL of the resources to fetch.
     * @param {object} options - Fetch options (passed directly to `fetch()`),
     * see [the syntax for more information](
     * https://developer.mozilla.org/en-US/docs/Web/API/WindowOrWorkerGlobalScope/fetch#Syntax).
     *
     * @returns {Promise<Document>} Promise containing the XML Document.
     */
    export function xml(url: string, options?: object): Promise<Document>;
    /**
     * Wrapper around [THREE.TextureLoader](https://threejs.org/docs/#api/en/loaders/TextureLoader).
     *
     * @param {string} url - The URL of the resources to fetch.
     * @param {object} options - Fetch options (passed directly to `fetch()`),
     * see [the syntax for more information](
     * https://developer.mozilla.org/en-US/docs/Web/API/WindowOrWorkerGlobalScope/fetch#Syntax).
     * Note that THREE.js docs mentions `withCredentials`, but it is not
     * actually used in [THREE.TextureLoader](https://threejs.org/docs/#api/en/loaders/TextureLoader).
     *
     * @returns {Promise<THREE.Texture>} Promise containing the
     * [THREE.Texture](https://threejs.org/docs/api/en/textures/Texture.html).
     */
    export function texture(url: string, options?: object): Promise<THREE.Texture>;
    export { arrayBuffer };
    /**
     * Wrapper over fetch to get some
     * [THREE.DataTexture](https://threejs.org/docs/#api/en/textures/DataTexture).
     *
     * @param {string} url - The URL of the resources to fetch.
     * @param {object} options - Fetch options (passed directly to `fetch()`),
     * see [the syntax for more information](
     * https://developer.mozilla.org/en-US/docs/Web/API/WindowOrWorkerGlobalScope/fetch#Syntax).
     *
     * @returns {Promise<THREE.DataTexture>} Promise containing the DataTexture.
     */
    export function textureFloat(url: string, options?: object): Promise<THREE.DataTexture>;
    export function geotiff(url: any): Promise<GeoTIFF.GeoTIFFImage>;
    /**
     * Wrapper over fetch to get a bunch of files sharing the same name, but
     * different extensions.
     *
     * @param {string} baseUrl - The shared URL of the resources to fetch.
     * @param {object} extensions - An object containing arrays. The keys of
     * each of this array are available fetch type, such as `text`, `json` or
     * even `arrayBuffer`. The arrays contains the extensions to append after
     * the `baseUrl` (see example below).
     * @param {object} options - Fetch options (passed directly to `fetch()`),
     * see [the syntax for more information](
     * https://developer.mozilla.org/en-US/docs/Web/API/WindowOrWorkerGlobalScope/fetch#Syntax).
     *
     * @returns {Promise[]} An array of promises, containing all the files,
     * organized by their extensions (see the example below).
     *
     * @example
     * itowns.Fetcher.multiple('http://geo.server/shapefile', {
     *     // will fetch:
     *     // - http://geo.server/shapefile.shp
     *     // - http://geo.server/shapefile.dbf
     *     // - http://geo.server/shapefile.shx
     *     // - http://geo.server/shapefile.prj
     *     arrayBuffer: ['shp', 'dbf', 'shx'],
     *     text: ['prj'],
     * }).then(function _(result) {
     *     // result looks like:
     *     result = {
     *         shp: ArrayBuffer
     *         dbf: ArrayBuffer
     *         shx: ArrayBuffer
     *         prj: string
     *     };
     * });
     */
    export function multiple(baseUrl: string, extensions: object, options?: object): Promise<any>[];
    export function get(format?: string): (url: string, options?: object) => Promise<THREE.Texture>;
}
export default _default;
declare function arrayBuffer(url: any, options?: {}): Promise<ArrayBuffer>;
import * as GeoTIFF from 'geotiff';
