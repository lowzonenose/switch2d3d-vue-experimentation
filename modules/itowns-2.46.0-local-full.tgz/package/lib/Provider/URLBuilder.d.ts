declare namespace _default {
    export { subDomains };
    export function xyz(coords: {
        row: number;
        col: number;
        zoom: number;
    }, source: {
        url: string;
        tileMatrixCallback: Function;
    }): string;
    export function bbox(bbox: {
        west: number;
        south: number;
        east: number;
        north: number;
    }, source: {
        crs: string;
        bboxDigits: number;
        url: string;
        axisOrder: string;
    }): string;
}
export default _default;
/**
 * @param {string} url
 * @returns {string}
 */
declare function subDomains(url: string): string;
