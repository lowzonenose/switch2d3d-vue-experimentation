declare namespace _default {
    function executeCommand(command: any): Promise<any[]>;
}
export default _default;
