export default LASLoader;
/**
 * - Partial LAS header.
 */
export type Header = {
    /**
     * - Type of point data
     * records contained by the buffer.
     */
    pointDataRecordFormat: number;
    /**
     * - Size (in bytes) of the
     * point data records. If the specified size is larger than implied by the
     * point data record format (see above) the remaining bytes are user-specfic
     * "extra bytes". Those are described by an Extra Bytes VLR.
     */
    pointDataRecordLength: number;
    /**
     * - Scale factors (an array `[xScale,
     * yScale, zScale]`) multiplied to the X, Y, Z point record values.
     */
    scale: number[];
    /**
     * - Offsets (an array `[xOffset,
     * xOffset, zOffset]`) added to the scaled X, Y, Z point record values.
     */
    offset: number[];
};
/**
 * @classdesc
 * Loader for LAS and LAZ (LASZip) point clouds. It uses the copc.js library and
 * the laz-perf decoder under the hood.
 *
 * The laz-perf web assembly module is lazily fetched at runtime when a parsing
 * request is initiated. Location of laz-perf wasm defaults to the unpkg
 * repository.
 */
declare class LASLoader {
    _wasmPath: string;
    _wasmPromise: any;
    _initDecoder(): any;
    _parseView(view: any, options: any): {
        attributes: {
            positions: Float32Array<ArrayBuffer>;
        };
        userData: {
            boundingBox: import("three").Box3JSON;
            position: import("three").Vector3Tuple;
            quaternion: [number, number, number, number];
        };
    };
    /**
     * Set LazPerf decoder path.
     * @param {string} path - path to `laz-perf.wasm` folder.
     */
    set lazPerf(path: string);
    /**
     * Parses a LAS or LAZ (LASZip) chunk. Note that this function is
     * **CPU-bound** and shall be parallelised in a dedicated worker.
     * @param {Uint8Array} data - File chunk data.
     * @param {object} options - Parsing options.
     * @param {Header} options.header - Partial LAS header.
     * @param {number} options.pointCount - Number of points encoded in this
     * data chunk.
     * @param {Las.ExtraBytes[]} [options.eb] - Extra bytes LAS VLRs
     * headers.
     * @param {8 | 16} [options.colorDepth] - Color depth encoding (in bits).
     * Either 8 or 16 bits. Defaults to 8 bits for LAS 1.2 and 16 bits for later
     * versions (as mandatory by the specification).
     * @returns {Promise<object>}
     */
    parseChunk(data: Uint8Array, options: {
        header: Header;
        pointCount: number;
        eb?: Las.ExtraBytes[] | undefined;
        colorDepth?: 8 | 16 | undefined;
    }): Promise<object>;
    /**
     * Parses a LAS or LAZ (LASZip) file. Note that this function is
     * **CPU-bound** and shall be parallelised in a dedicated worker.
     * @param {ArrayBuffer} data - Binary data to parse.
     * @param {object} [options] - Parsing options.
     * @param {8 | 16} [options.colorDepth] - Color depth encoding (in bits).
     * Either 8 or 16 bits. Defaults to 8 bits for LAS 1.2 and 16 bits for later
     * versions (as mandatory by the specification)
     * @returns {Promise<object>}
     */
    parseFile(data: ArrayBuffer, options?: {
        colorDepth?: 8 | 16 | undefined;
    }): Promise<object>;
}
import { Las } from 'copc';
