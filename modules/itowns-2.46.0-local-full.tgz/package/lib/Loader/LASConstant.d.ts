export const LASAttributes: ({
    name: string;
    bufferName: string;
    size: number;
    normalized?: undefined;
} | {
    name: string;
    bufferName: string;
    size: number;
    normalized: boolean;
} | {
    name: string;
    bufferName: string;
    size?: undefined;
    normalized?: undefined;
})[];
