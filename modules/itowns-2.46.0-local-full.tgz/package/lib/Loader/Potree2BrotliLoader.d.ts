export default function load(buffer: any, options: any): {
    attributeBuffers: {
        INDICES: {
            buffer: ArrayBuffer;
            attribute: PointAttribute;
        };
    };
    userData: {
        position: any;
        quaternion: any;
    };
};
import { PointAttribute } from '../Core/Potree2PointAttributes';
